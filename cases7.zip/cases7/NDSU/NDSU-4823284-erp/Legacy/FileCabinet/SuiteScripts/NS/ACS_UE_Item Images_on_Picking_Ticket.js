/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/ui/serverWidget', 'N/query', 'N/search'],

    (serverWidget, query, search) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            const logTitle = 'beforeLoad'
            try {
                if (scriptContext.type == scriptContext.UserEventType.PRINT) {
                    let currRec = scriptContext.newRecord;
                    let form = scriptContext.form;


                    let countLines = currRec.getLineCount({
                        sublistId: 'item'
                    });

                    let sublist = form.getSublist('item');

                    sublist.addField({
                        id: 'custpage_hidden_path_images',
                        label: 'Image path',
                        type: serverWidget.FieldType.IMAGE
                    }).updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.HIDDEN
                    });

                    let arrItemId = [];
                    let matrixItems = [];

                    let mapItems = {};

                    //get itemIds for sql query
                    for (let i = 0; i < countLines; i++) {
                        let matrixType = currRec.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'matrixtype',
                            line: i
                        });

                        let itemId = currRec.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'item',
                            line: i
                        });

                        if (matrixType == 'CHILD') {
                            matrixItems.push(itemId)

                        } else {
                            arrItemId.push(itemId);
                        }
                        mapItems[i] = itemId;
                    }
                    
                    let mapMatrixItems ={};        
                    if (matrixItems.length > 0) {
            
                        search.create({
                            type: search.Type.INVENTORY_ITEM,
                            filters:
                                [
                                    ["internalid", "anyof", matrixItems]
                                ],
                            columns: ['parent']
                        }).run().each(function (result) {
                            arrItemId.push(result.getValue('parent'));
                            mapMatrixItems[result.id] = result.getValue('parent')
                            return true;
                        });
                    }


                    if (arrItemId.length > 0) {
                        //get image IDs from 
                        let sql = `SELECT
                                    ItemImage.Item AS id,
                                    File.ID AS image
                                    FROM
                                    ItemImage
                                    INNER JOIN File ON
                                        ( File.Name = ItemImage.Name)
                                    INNER JOIN MediaItemFolder ON 
                                    (MediaItemFolder.id = File.Folder) 
                                     WHERE
                                    ItemImage.Item IN (${arrItemId.join(', ')})`
                        if (sql) {
                            let resultSet = query.runSuiteQL({
                                query: sql,
                                params: []
                            })

                            let resultsObj = resultSet.asMappedResults();                            

                            //array to map
                            let mapImages = resultsObj.reduce(function (map, obj) {
                                map[obj.id] = obj.image;
                                return map;
                            }, {});

                            //set each item image
                            for (let i = 0; i < countLines; i++) {
                                let itemId = mapItems[i];
                                if(mapMatrixItems[itemId]){
                                    itemId = mapMatrixItems[itemId]
                                }
                                let imageId = mapImages[itemId];

                                if (!!imageId) {
                                    currRec.setSublistValue({
                                        sublistId: 'item',
                                        line: i,
                                        fieldId: 'custpage_hidden_path_images',
                                        value: imageId
                                    })
                                }
                            }
                        }


                    }
                }
            } catch (error) {
                log.error(logTitle, error)
            }


        }


        return { beforeLoad }

    });
