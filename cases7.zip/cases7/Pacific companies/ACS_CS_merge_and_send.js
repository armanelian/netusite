/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * 
 *  Version    Date            Author              Remarks
 *  1.00       11/17/2025      Elian Arman         Case #
 * 
 */
define(['N/currentRecord', 'N/url'],

function(currentRecord, url) {

    function getFilesAndOpenSuitelet() {
            let fileIds = [];
            let rec = currentRecord.get()


            // Get file sublist
            let fileSublistLineCount = rec.getLineCount({
                sublistId: 'recmachcustrecord_files_sublist_invoice'
            });

            // Loop through file sublist
            for (let i = 0; i < fileSublistLineCount; i++) {
                rec.selectLine({
                    sublistId: 'recmachcustrecord_files_sublist_invoice',
                    line: i
                });

                // Get file Id and add to array
                let idValue = rec.getCurrentSublistValue({
                    sublistId: 'recmachcustrecord_files_sublist_invoice',
                    fieldId: 'custrecord_document'
                })

                fileIds.push(idValue);
            }
            log.debug('files', fileIds);
            // Load SuiteLet URL
            const suiteletUrl = url.resolveScript({
                scriptId: 'customscript_sl_merge_and_send',
                deploymentId: 'customdeploy_sl_merge_and_send',
                returnExternalUrl: false,
                params: {
                    'custscript_file_ids': fileIds.join(','),
                }
            });

            log.debug('suiteletUrl', suiteletUrl);

            window.open(suiteletUrl)
    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
       getFilesAndOpenSuitelet: getFilesAndOpenSuitelet,
        saveRecord: saveRecord
    };
    
});
