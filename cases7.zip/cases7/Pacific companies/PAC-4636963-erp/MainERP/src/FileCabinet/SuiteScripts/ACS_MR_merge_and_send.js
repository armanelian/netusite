/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * 
 *  Version    Date            Author                           Remarks
 *  1.00       07/10/2025      Elian Arman                      Case #6411439
 * 
 */
define(['N/search', 'N/email', 'N/render', 'N/xml', 'N/file', 'N/record', 'N/runtime'],

    (search, email, render, xml, file, record, runtime) => {

        const getInputData = (inputContext) => {
            let invoiceId = runtime.getCurrentScript().getParameter('custscript_mr_invoice_id');

            record.submitFields({
                type: record.Type.INVOICE,
                id: invoiceId,
                values: {
                    custbody_mr_response: "Processing"
                }
            });
            let files = search.create({
                type: "customrecord_files_sublist",
                filters:
                    [
                        ["custrecord_files_sublist_invoice", "anyof", invoiceId]
                    ],
                columns: ["custrecord_document"]
            });

            return files;
        }

        const map = (mapContext) => {
            const context = JSON.parse(mapContext.value);

            let invoiceId = runtime.getCurrentScript().getParameter('custscript_mr_invoice_id');
            try {
                let fileId = parseInt(context.values.custrecord_document.value);

                let fileObj = file.load({
                    id: fileId
                });

                let objFile = {};

                let url = fileObj.url;

                objFile[fileId] = url;


                fileObj.isOnline = true;
                fileObj.save();

                mapContext.write({
                    key: invoiceId,
                    value: objFile
                });

            } catch (error) {
                log.error('map', error)
            }
        }

        const reduce = (reduceContext) => {

            const files = reduceContext.values;
            const invoiceId = reduceContext.key;
            let summaryMessage;

            try {
                const pdfFile = render.transaction({
                    entityId: parseInt(invoiceId),
                    printMode: render.PrintMode.PDF,
                    type: record.Type.INVOICE
                });

                let invoicesFolder = runtime.getCurrentScript().getParameter('custscript_invoice_folder');

                let invoicePdfFile = file.create({
                    name: 'Invoice_' + invoiceId + '.pdf',
                    fileType: file.Type.PDF,
                    contents: pdfFile.getContents(),
                    folder: invoicesFolder,
                    isOnline: true
                });
                
                let invoiceFileId = invoicePdfFile.save();
                
                let transactionUrl = search.lookupFields({
                    type: "file",
                    id: invoiceFileId,
                    columns: ["url"]
                }).url;
                
                const templateXML = ['<?xml version="1.0"?>', '<pdfset>'];
                
                let transactionUrlXml = xml.escape({ xmlText: transactionUrl });

                templateXML.push("<pdf src='" + transactionUrlXml + "'/>");

                files.forEach((fileInfo) => {
                    const objFile = JSON.parse(fileInfo);
                    
                    let id = Object.keys(objFile)[0];
                    let url = objFile[id];
                    
                    const fileURLXML = xml.escape({ xmlText: url });
                    templateXML.push("<pdf src='" + fileURLXML + "'/>");
                });
                
                templateXML.push("</pdfset>");

                const templateRendered = render.xmlToPdf({
                    xmlString: templateXML.join('\n')
                });

                let customerId = search.lookupFields({
                    type: search.Type.INVOICE,
                    id: invoiceId,
                    columns: ["entity"]
                }).entity[0].value;

                let recipients = search.lookupFields({
                    type: search.Type.CUSTOMER,
                    id: customerId,
                    columns: ["custentity_acs_alternate_email"]
                }).custentity_acs_alternate_email;

                let invoiceFields = search.lookupFields({
                    type: search.Type.INVOICE,
                    id: invoiceId,
                    columns: ["tranid", "total"]
                });

                let sender = runtime.getCurrentUser().id;
                let subject = `Pacific Companies, Inc.: INVOICE #${invoiceFields.tranid}`;
                let body = `<p><span data-olk-copy-source="MessageBody">Hello,</span></p>
                            <p>Your invoice ${invoiceFields.tranid} for ${invoiceFields.total}<strong> </strong>is attached. Our terms are due upon receipt.<br />Feel free to contact us if you have any questions. We appreciate your business very much. Thank you.<br /><br /></p>
                            <p><span data-olk-copy-source="MessageBody">Sincerely,<br /></span>Drew Shah<br />Director of Finance<br />714-352-7605<br />Pacific Companies, Inc.<br />800-741-7629<br /><a title="https://urldefense.com/v3/__http://www.pacificcompanies.com__;!!ACWV5N9M2RV99hQ!PpteSLLfefr5x7cfAlJ7oQnh1BfpnZySpXXA4-r97tA4E115LHe8t8UPoAC9yk0a7E8trq9gd3nCfhlQFLKYfmMM7tk$" href="https://urldefense.com/v3/__http://www.pacificcompanies.com__;!!ACWV5N9M2RV99hQ!PpteSLLfefr5x7cfAlJ7oQnh1BfpnZySpXXA4-r97tA4E115LHe8t8UPoAC9yk0a7E8trq9gd3nCfhlQFLKYfmMM7tk$" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" data-linkindex="0">www.pacificcompanies.com</a></p>
                            <p> </p>`;

                email.send({
                    author: sender,
                    body: body,
                    recipients: recipients,
                    subject: subject,
                    attachments: [templateRendered],
                    relatedRecords: {
                        transactionId: invoiceId
                    }
                });

                summaryMessage = "Email Sent";


                files.forEach(fileInfo => {
                    const objFile = JSON.parse(fileInfo);
                    const id = Object.keys(objFile)[0];

                    let fileLoaded = file.load({
                        id: id
                    });

                    fileLoaded.isOnline = false;

                    fileLoaded.save();
                });

                file.delete({
                    id: invoiceFileId
                });


            } catch (error) {
                log.error('reduce', error);
                summaryMessage = error.message;
            }

            files.forEach(fileInfo => {
                const objFile = JSON.parse(fileInfo);
                const id = Object.keys(objFile)[0];

                let fileLoaded = file.load({
                    id: id
                });

                fileLoaded.isOnline = false;

                fileLoaded.save();
            });

            reduceContext.write({ key: invoiceId, value: summaryMessage });



        }

        const summarize = (summaryContext) => {
            let invoiceId;
            let message;

            summaryContext.output.iterator().each(function (key, value) {
                invoiceId = key;
                message = value;
            });

            record.submitFields({
                type: record.Type.INVOICE,
                id: invoiceId,
                values: {
                    custbody_mr_response: message
                }

            });

        }

        return { getInputData, map, reduce, summarize }

    });
