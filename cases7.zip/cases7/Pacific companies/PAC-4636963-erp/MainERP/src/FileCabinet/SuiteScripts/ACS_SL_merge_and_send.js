/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * 
 *  Version    Date            Author                           Remarks
 *  1.00       07/10/2025      Elian Arman                      Case #6411439
 * 
 */
define(['N/redirect', 'N/record', 'N/task', 'N/runtime'],

    (redirect, record, task, runtime) => {

        const onRequest = (scriptContext) => {

            let invoiceId = scriptContext.request.parameters.custscript_invoice_id;
            let scriptID = runtime.getCurrentScript().getParameter('custscript_mr_script_id');
            let deployId = runtime.getCurrentScript().getParameter('custscript_mr_deploy_id');


            let mrTask = task.create({
                taskType: task.TaskType.MAP_REDUCE,
                scriptId: scriptID,
                deploymentId: deployId,
                params: {
                    'custscript_mr_invoice_id': invoiceId
                }
            });

            record.submitFields({
                type: record.Type.INVOICE,
                id: invoiceId,
                values: {
                    custbody_mr_response: ""
                }
            });

            mrTask.submit();

            redirect.toRecord({
                type: record.Type.INVOICE,
                id: invoiceId,
                parameters: {
                    'custparam_script_run': true
                }
            });

        }

        return { onRequest }

    });
