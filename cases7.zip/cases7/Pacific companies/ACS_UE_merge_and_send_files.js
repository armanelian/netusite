/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author                           Remarks
 *  1.00       07/10/2025      Santiago Brikman, Elian Arman    Case #6411439
 * 
 */
define(['N/url', 'N/ui/message', 'N/runtime'],

    (url, message, runtime) => {
        const beforeLoad = (scriptContext) => {
            const { form, newRecord } = scriptContext;

            try {

                let suiteletScriptId = runtime.getCurrentScript().getParameter("custscript_suitelet_script_id");
                let suiteletDeployId = runtime.getCurrentScript().getParameter("custscript_suitelet_deploy_id");
                let scriptRun = scriptContext.request.parameters.custparam_script_run;
                let confirmation = newRecord.getValue('custbody_mr_response');


                if (scriptRun) {
                    if (confirmation === "Email Sent") {
                        form.addPageInitMessage({
                            type: message.Type.CONFIRMATION,
                            message: 'Email has been sent successfully.'
                        });
                    } else if (!confirmation || confirmation == 'Processing') {
                        form.addPageInitMessage({
                            type: message.Type.INFORMATION,
                            message: 'Email is being processed.'
                        });
                    } else {
                        form.addPageInitMessage({
                            type: message.Type.ERROR,
                            message: 'Email has not been sent due to the following error: ' + confirmation
                        });
                    }
                }

                // Load SuiteLet URL
                const suiteletUrl = url.resolveScript({
                    scriptId: suiteletScriptId,
                    deploymentId: suiteletDeployId,
                    returnExternalUrl: false,
                    params: {
                        'custscript_invoice_id': newRecord.id
                    }
                });

                // Add button with Suitelet execution
                form.addButton({
                    id: 'custpage_btn_merge_and_send',
                    label: 'Merge and Send',
                    functionName: 'window.open("' + suiteletUrl + '", "_self")'
                });
            }
            catch (error) {
                log.error(error);
            }

        }

        return { beforeLoad }

    });
