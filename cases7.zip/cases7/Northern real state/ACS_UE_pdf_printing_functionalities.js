/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       11/07/2025      Santiago Brikman    Case #6824514
 * 
 */
define(['N/runtime', 'N/file', 'N/record', 'N/ui/serverWidget', 'N/search'], (runtime, file, record, serverWidget, search) => {

  const beforeLoad = (scriptContext) => {
    if (scriptContext.type !== scriptContext.UserEventType.PRINT) return;

    try {
      const { newRecord, type, UserEventType } = scriptContext;
      const subsidiaryId = newRecord.getValue('subsidiary');
      const baseUrlParam = runtime.getCurrentScript().getParameter('custscript_acs_logo_base_url');
      const logoWidthParam = runtime.getCurrentScript().getParameter('custscript_acs_logo_width');
      const logoHeightParam = runtime.getCurrentScript().getParameter('custscript_acs_logo_height');

      if (![UserEventType.CREATE, UserEventType.EDIT].includes(type)) return;

      // let subsidiaryRecord = record.load({
      //   type: record.Type.SUBSIDIARY,
      //   id: subsidiaryId,
      // });

      const subFields = search.lookupFields({
        type: record.Type.SUBSIDIARY,
        id: subsidiaryId,
        columns: ["mainaddress_text", "logo"]
      });



      const subsidiaryAddress = subFields.mainaddress_text;

      const subsidiaryLogoFileId = subFields.logo;

      if (!subsidiaryLogoFileId) return;

      const domain = "https://" + url.resolveDomain({
        hostType: url.HostType.APPLICATION
      });

      let logoUrl = null;
      search.create({
        type: "file",
        filters:
          [
            ["internalidnumber", "equalto", subsidiaryLogoFileId]
          ],
        columns: ["url"]
      }).run().each(function (r){
         logoUrl = domain + r.getValue("url");
      });

      if(logoUrl){
        urlField.defaultValue = baseUrlParam + logoUrl;


      }


      const logoWidth = form.addField({
        id: 'custpage_logo_width',
        label: 'Logo Width',
        type: 'text'
      });
      logoWidth() = logoWidthParam;

      const logoHeight = form.addField({
        id: 'custpage_logo_height',
        label: 'Logo Height',
        type: 'text'
      });
      logoHeight.defaultValue = logoHeightParam;

      const subsidiaryAddressField = form.addField({
        id: 'custpage_subsidiary_address',
        label: 'Subsidiary Address',
        type: 'longtext'
      });

      subsidiaryAddressField.defaultValue = subsidiaryAddress;

      
      

    } catch (e) {
      log.error('Error | beforeLoad', e);
    }
  };

  return { beforeLoad };
});
