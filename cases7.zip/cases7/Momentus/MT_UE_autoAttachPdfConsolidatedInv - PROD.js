/**
*   Version    Date            Author              Remarks
*   1.00       February 2025   Julius L. Selda       Initial Version
*  
*@NApiVersion 2.1
*@NScriptType UserEventScript   
*/
define(['N/search', 'N/runtime', 'N/file'], function (search, runtime, file) {

    function beforeLoad(context) {
        try {
            var messageRecord = context.newRecord;
            // log.debug('messageRecord', messageRecord);

            log.debug('context.type', context.type);
            // log.debug('context.UserEventType.CREATE', context.UserEventType.CREATE);
            // log.debug('runtime.ContextType.USER_INTERFACE', runtime.ContextType.USER_INTERFACE);
            log.debug('runtime.executionContext', runtime.executionContext);

            // run only if in create on the user interface
            if (context.type != context.UserEventType.CREATE)
                return;
            if (runtime.executionContext != runtime.ContextType.USER_INTERFACE)
                return;

            // get the values on the url parametes to help see the composer source 
            var params = context.request.parameters;
            log.debug('params', JSON.stringify(params));

            var recid = '';

            if (!isEmpty(params.record)) {
                recid = params.record;
            }
            if (isEmpty(recid)) {
                log.debug('No record found');
                return;
            }

            // var rectype = '';
            if (recid) {
                var lookupResults = search.lookupFields({
                    type: 'customrecord_consolidated_invoice',
                    id: recid,
                    columns: ['recordtype', 'custrecord_consolidated_invoice_url']
                });

                log.debug('lookupResults', lookupResults);

                if (lookupResults.recordtype) {
                    const rectype = lookupResults.recordtype;
                    if (rectype == 'customrecord_consolidated_invoice') {
                        const fileId = extractId(lookupResults.custrecord_consolidated_invoice_url);
                        // log.debug('fileId', fileId);

                        var pdfFile = file.load({ id: fileId });
                        log.debug('pdfFile.id', pdfFile.id);
                        if (pdfFile.id) {
                            messageRecord.setSublistValue({
                                sublistId: 'mediaitem',
                                fieldId: 'mediaitem',
                                line: 0,
                                value: pdfFile.id
                            });
                        }
                    }
                }
            }
        } catch (error) {
            log.error('error', error);
        }
    }

    function beforeSubmit(context) {

    }

    function afterSubmit(context) {

    }

    function isEmpty(val) {
        if (typeof (val) == 'object') {
            for (var key in val) {
                if (val.hasOwnProperty(key))
                    return false;
            }
            return true;
        }
        else {
            return (val == null || val == '' || val == undefined);
        }
    }

    function extractId(url) {
        const match = url.match(/[?&]id=(\d+)/);
        return match ? match[1] : null;
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    }
});
