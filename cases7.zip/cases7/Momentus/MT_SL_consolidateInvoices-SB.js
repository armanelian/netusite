/**
*   Version     Date            Author              Remarks
*   1.0         November 2024   Julius L. Selda     Initial version
*.  2.0         24 Oct 2025     Santiago Nunez      Fixed tax amount and changed logic to avoid loads in a for loop
*.  2.1         13 Nov 2025     Santiago Nunez      Fixed subtotals, amount remaining and duplicate document numbers
*  
*@NApiVersion 2.1
*@NScriptType Suitelet
*/
define(['N/ui/serverWidget', 'N/search', 'N/render', 'N/email', 'N/file', 'N/record', 'N/runtime', 'N/url', 'N/redirect'],
    function (serverWidget, search, render, email, file, record, runtime, url, redirect) {
        const folderID = 923879;

        const advPdfTemplates = [{
            customform: "239", // Germany
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE_GERMANY"
        }, {
            customform: "240", // US
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE"
        }, {
            customform: "241", // Australia
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE_AUSTRALIA"
        }, {
            customform: "242", // France
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE_FRANCE"
        }, {
            customform: "243", // EMEA English
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE_EMEA"
        }, {
            customform: "244", // HK
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE_HONGKONG"
        }, {
            customform: "255", // Germany (Outside GM)
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE_GERMANY_OUTSIDE"
        }, {
            customform: "258", // WeTrack test
            templateId: "CUSTTMPL_CONSOLIDATEDINVOICE_PRIAVA"
        }];

        function onRequest(context) {
            //log.debug('context.request.method', context.request.method);

            try {
                if (context.request.method === 'GET') {
                    // Display the form for selecting customer and viewing invoices
                    let form = serverWidget.createForm({ title: 'Create Consolidated Invoices' });

                    // Customer Selection Field
                    let customerField = form.addField({
                        id: 'custpage_customer',
                        type: serverWidget.FieldType.SELECT,
                        label: 'Customer',
                        source: 'customer'
                    });
                    customerField.isMandatory = true;

                    // form.addSubmitButton({ label: 'Get Open Invoices' });
                    form.addButton({
                        id: 'custpage_get_invoices',
                        label: 'Get Open Invoices',
                        functionName: 'redirectToGet'
                    });

                    // Attach the client script
                    form.clientScriptModulePath = 'SuiteScripts/MT_CS_consolidateInvoices.js';

                    // If a customer has been selected, display open invoices
                    if (context.request.parameters.custpage_customer) {
                        let customerId = context.request.parameters.custpage_customer;
                        customerField.defaultValue = customerId;

                        //log.debug('customerId', customerId);

                        // Add sublist for displaying open invoices
                        let sublist = form.addSublist({
                            id: 'custpage_invoice_sublist',
                            type: serverWidget.SublistType.LIST,
                            label: 'Open Invoices'
                        });
                        sublist.addMarkAllButtons();

                        sublist.addField({
                            id: 'custpage_select',
                            type: serverWidget.FieldType.CHECKBOX,
                            label: 'Select'
                        });

                        sublist.addField({ id: 'custpage_id', type: serverWidget.FieldType.TEXT, label: 'Internal ID' })
                            .updateDisplayType({
                                displayType: serverWidget.FieldDisplayType.HIDDEN
                            });
                        sublist.addField({ id: 'custpage_invoice_number', type: serverWidget.FieldType.TEXT, label: 'Invoice #' });
                        sublist.addField({ id: 'custpage_invoice_date', type: serverWidget.FieldType.DATE, label: 'Date' });
                        sublist.addField({ id: 'custpage_currency', type: serverWidget.FieldType.TEXT, label: 'Currency' });
                        sublist.addField({ id: 'custpage_subsidiary', type: serverWidget.FieldType.TEXT, label: 'Subsidiary' });
                        sublist.addField({ id: 'custpage_subsidiary_id', type: serverWidget.FieldType.TEXT, label: 'Subsidiary ID' })
                            .updateDisplayType({
                                displayType: serverWidget.FieldDisplayType.HIDDEN
                            });
                        sublist.addField({ id: 'custpage_amount', type: serverWidget.FieldType.CURRENCY, label: 'Amount' });
                        // sublist.addField({ id: 'custpage_template', type: serverWidget.FieldType.TEXT, label: 'Invoice Template' });

                        let openInvoices = getOpenInvoices(customerId);
                        openInvoices.forEach(function (invoice, index) {
                            var recordURL = url.resolveRecord({
                                recordType: record.Type.INVOICE,
                                recordId: invoice.id,
                                isEditMode: false
                            });

                            sublist.setSublistValue({ id: 'custpage_id', line: index, value: invoice.id });

                            var invoiceNumber = `<a href="${recordURL}" target="_blank" class="dottedlink edititem">${invoice.invoiceNumber}</a>`
                            sublist.setSublistValue({ id: 'custpage_invoice_number', line: index, value: invoiceNumber });
                            sublist.setSublistValue({ id: 'custpage_invoice_date', line: index, value: invoice.date });
                            sublist.setSublistValue({ id: 'custpage_currency', line: index, value: invoice.currency });
                            sublist.setSublistValue({ id: 'custpage_subsidiary', line: index, value: invoice.subsidiary });
                            sublist.setSublistValue({ id: 'custpage_subsidiary_id', line: index, value: invoice.subsidiaryId });
                            sublist.setSublistValue({ id: 'custpage_amount', line: index, value: invoice.amount });
                            // sublist.setSublistValue({ id: 'custpage_template', line: index, value: invoice.template });
                        });

                        form.addSubmitButton({ label: 'Create Consolidated Invoice' });
                    }

                    context.response.writePage(form);

                } else {
                    // Handle POST request to create consolidated invoice
                    let customerId = context.request.parameters.custpage_customer;
                    let consolidatedInvoices = [];
                    let invoiceIds = [];
                    let selectedLines = context.request.getLineCount({ group: 'custpage_invoice_sublist' });

                    for (let i = 0; i < selectedLines; i++) {
                        var selected = context.request.getSublistValue({ group: 'custpage_invoice_sublist', name: 'custpage_select', line: i });
                        // //log.debug('custpage_select', selected);

                        if (selected === 'T') {
                            const id = context.request.getSublistValue({ group: 'custpage_invoice_sublist', name: 'custpage_id', line: i });
                            invoiceIds.push(id);
                            consolidatedInvoices.push({
                                id: id,
                                invoiceId: context.request.getSublistValue({ group: 'custpage_invoice_sublist', name: 'custpage_invoice_number', line: i }),
                                amount: context.request.getSublistValue({ group: 'custpage_invoice_sublist', name: 'custpage_amount', line: i }),
                                currency: context.request.getSublistValue({ group: 'custpage_invoice_sublist', name: 'custpage_currency', line: i }),
                                subsidiary: context.request.getSublistValue({ group: 'custpage_invoice_sublist', name: 'custpage_subsidiary', line: i }),
                                subsidiaryId: context.request.getSublistValue({ group: 'custpage_invoice_sublist', name: 'custpage_subsidiary_id', line: i }),
                            });
                        }
                    }

                    var message = 'Please select at least two invoices for consolidation.';

                    if (consolidatedInvoices.length > 1) {
                        //log.debug('consolidatedInvoices length', consolidatedInvoices.length);

                        var customerRecord = search.lookupFields({
                            type: search.Type.CUSTOMER,
                            id: customerId,
                            columns: ['email', 'entityid', 'companyname', 'address', 'vatregnumber']
                        });

                        //log.debug('customer', customerRecord);

                        // Unique consolidated invoice number
                        // let consolidatedInvoiceNumber = 'CINV' + new Date().getTime();
                        const cinvId = recordConsolidatedInvoiceCustomRecord(customerId);

                        var customRecordCinv = search.lookupFields({
                            type: 'customrecord_consolidated_invoice',
                            id: cinvId,
                            columns: ['internalid', 'name']
                        });

                        // consolidate data
                        // //log.debug('entity', customerRecord.entityid);
                        let consolidatedData = consolidateInvoices(consolidatedInvoices, customerRecord);

                        // generate the pdf
                        let { pdfFile, fileId } = generateConsolidatedPDF(consolidatedData, customRecordCinv.name, customerRecord);
                        // //log.debug('fileId', fileId);
                        // //log.debug('email', customerRecord.email);

                        const pdfAttachment = file.load({ id: fileId });

                        let pdfUrl = pdfAttachment.url;
                        pdfUrl = pdfUrl.replace(/&/g, '&amp;');

                        // get total amount 
                        const invoiceSearch = search.create({
                            type: search.Type.INVOICE,
                            filters: [
                                ['internalid', search.Operator.IS, invoiceIds],
                                'AND',
                                ['mainline', 'is', 'T']
                            ],
                            columns: [
                                search.createColumn({
                                    name: 'fxamount',
                                    summary: search.Summary.SUM,
                                }),
                                search.createColumn({
                                    name: 'daysoverdue',
                                    summary: search.Summary.GROUP,
                                })
                            ]
                        });
                        const invoiceSearchResult = invoiceSearch.run().getRange({ start: 0, end: 1 });
                        const invoiceSum = invoiceSearchResult[0] ? invoiceSearchResult[0].getValue({ name: 'fxamount', summary: search.Summary.SUM }) : 0;
                        //log.debug('invoiceSum', invoiceSum);

                        const daysoverdue = invoiceSearchResult[0] ? invoiceSearchResult[0].getValue({ name: 'daysoverdue', summary: search.Summary.GROUP }) : 0;
                        //log.debug('daysoverdue', daysoverdue);

                        record.submitFields({
                            type: 'customrecord_consolidated_invoice',
                            id: cinvId,
                            values: {
                                'custrecord_consolidated_invoice_url': pdfUrl,
                                'custrecord_consolidated_invoice_trandate': consolidatedData.trandate,
                                'custrecord_consolidated_invoice_amountre': invoiceSum,
                                'custrecord_consolidated_invoice_currency': consolidatedData.currencyId,
                                'custrecord_consolidated_invoice_status': consolidatedData.status,
                                'custrecord_consolidated_invoice_duedate': consolidatedData.duedate,
                                'custrecord_consolidated_invoice_daysover': daysoverdue,
                            }
                        });

                        // //log.debug('pdfUrl', pdfUrl);
                        //log.debug('consolidatedInvoiceNumber', customRecordCinv.name);

                        // update the invoices custom field
                        updateIndividualInvoices(consolidatedInvoices, cinvId);

                        message = `Consolidated invoice created (Consolidated Invoice #: ${customRecordCinv.name}).
                                    <br><br> <a href="${pdfUrl}" target="_blank">Download PDF</a>`;

                        // attach the pdf file to custom record
                        record.attach({
                            record: {
                                type: 'file',
                                id: fileId
                            },
                            to: {
                                type: 'customrecord_consolidated_invoice',
                                id: cinvId
                            }
                        });

                        // Redirect to Custom record
                        redirect.toRecord({
                            type: 'customrecord_consolidated_invoice',
                            id: cinvId
                        });
                    }

                    var form = serverWidget.createForm({
                        title: message,
                        hideNavBar: false
                    });

                    // Display the form
                    context.response.writePage(form);
                }
            } catch (error) {
                var errStr = 'Unexpected Error: ' + error.toString();
                log.error('ERROR', errStr);

                var form = serverWidget.createForm({
                    title: errStr,
                    hideNavBar: false
                });

                // Display the form
                context.response.writePage(form);
            }
        }

        function getOpenInvoices(customerId) {
            let openInvoices = [];

            let invoiceSearch = search.create({
                type: search.Type.INVOICE,
                filters: [
                    ['entity', search.Operator.IS, customerId],
                    'AND',
                    ['status', search.Operator.ANYOF, 'CustInvc:A'], // Open invoices
                    'AND',
                    ['mainline', search.Operator.IS, 'T']
                ],
                columns: [
                    search.createColumn({ name: 'tranid' }),
                    search.createColumn({ name: 'trandate' }),
                    search.createColumn({ name: 'currency' }),
                    search.createColumn({ name: 'subsidiary' }),
                    search.createColumn({ name: 'fxamount' }),
                    // search.createColumn({ name: 'custbody_invoice_template' })
                ]
            });

            invoiceSearch.run().each(function (result) {
                openInvoices.push({
                    id: result.id,
                    invoiceNumber: result.getValue({ name: 'tranid' }),
                    date: result.getValue({ name: 'trandate' }),
                    currency: result.getText({ name: 'currency' }),
                    subsidiary: result.getText({ name: 'subsidiary' }),
                    subsidiaryId: result.getValue({ name: 'subsidiary' }),
                    amount: result.getValue({ name: 'fxamount' }),
                    // template: result.getValue({ name: 'custbody_invoice_template' }) || 'Default'
                });
                return true;
            });

            return openInvoices;
        }

        const getAllResults = (srch) => {
            const results = srch.run();
            const searchResults = [];
            let searchid = 0;
            let resultsSlice = [];
            do {
                resultsSlice = results.getRange({ start: searchid, end: searchid + 1000 });
                resultsSlice.forEach(slice => {
                    searchResults.push(slice);
                    searchid++;
                });
            } while (resultsSlice.length == 1000);
            return searchResults;
        }

        function consolidateInvoices(invoices, customer) {
            const date = new Date();
            const formattedDate = `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}/${date.getFullYear()}`;

            let consolidatedData = {
                customer: customer.entityid + ' ' + customer.companyname,
                subsidiaryName: '',
                date: formattedDate,
                subTotal: 0,
                taxRate: 0,
                taxAmount: 0,
                totalAmount: 0,
                lineItems: [],
                currency: '',
                subsidiary: null,
                invoices: [],
                vatregnumber: customer.vatregnumber,
                endUserAddress: '',
                customform: '',
                discounttotal: 0,
                amountremaining: 0,
                currencyId: '',
                newSubtotal: 0,
                billaddress: '',
                trandate: null,
                status: '',
                duedate: null
            };

            const invoicesArray = [];
            const taxRateArray = [];
            const customformArray = [];

            let subsidiaryId = '';

            const invoiceSearch = search.load('customsearch_acs_consolidated_invoice_ss');
            const invoiceIds = invoices.map(invoice => invoice.id);

            const invoiceFilters = search.createFilter({
                name: 'internalid',
                operator: search.Operator.ANYOF,
                values: invoiceIds
            });
            invoiceSearch.filters.push(invoiceFilters);

            const invoicesResults = getAllResults(invoiceSearch);

            invoicesResults.forEach(function (invoice) {
                const amountremaining = Number(invoice.getValue('fxamountremaining')) || 0;
                consolidatedData.amountremaining += amountremaining;
                
                const mainline = invoice.getValue('mainline');
                if(mainline === '*') return;

                const billaddress = invoice.getValue('billaddress');
                if (billaddress) {
                    consolidatedData.billaddress = billaddress.replace(/\n/g, '<br />');
                }

                const customform = invoice.getValue('customform');
                if (customform) {
                    customformArray.push(customform);
                }

                const endUserAddress = invoice.getValue({
                    name: 'address',
                    join: 'CUSTBODY_MM_TRX_ENDUSER'
                })

                if (endUserAddress) consolidatedData.endUserAddress = endUserAddress;

                consolidatedData.status = invoice.getValue('statusref');
                consolidatedData.trandate = invoice.getValue('trandate');
                consolidatedData.duedate = invoice.getValue('duedate');

                const trandate = new Date(invoice.getValue('trandate'));

                const formattedTranDate = trandate.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit'
                });

                const duedate = new Date(invoice.getValue('duedate'));
                const formattedduedate = duedate.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit'
                });

                const discounttotal = Number(invoice.getValue('discountamount')) || 0;
                consolidatedData.discounttotal += parseFloat(discounttotal);

                

                const currencyId = invoice.getValue('currency');

                if (consolidatedData.currencyId == '' && currencyId) {
                    consolidatedData.currencyId = currencyId;
                }

                const otherrefnum = invoice.getValue('otherrefnum');
                const invoiceInArray = invoicesArray.find(invoice => invoice.otherrefnum === otherrefnum);
                if(!invoiceInArray){
                    const invoiceRec = {
                        trandate: formattedTranDate,
                        trandateUS: formatDateToMDYYYY(trandate),
                        trandateAu: formatDateToDDMMYYYY(trandate),
                        trandateGerman: formatDate(trandate),
                        total: invoice.getValue('total'),
                        duedate: formattedduedate,
                        duedateUS: formatDateToMDYYYY(duedate),
                        duedateAu: formatDateToDDMMYYYY(duedate),
                        duedateGerman: formatDate(duedate),
                        currency: invoice.getText('currency'),
                        currencyId: currencyId,
                        otherrefnum: otherrefnum,
                        discounttotal: discounttotal,
                        amountremaining: amountremaining
                    };
                    invoicesArray.push(invoiceRec);
                }

                consolidatedData.currency = invoice.getText('currency');
                consolidatedData.subsidiaryName = invoice.getText('subsidiary');
                subsidiaryId = invoice.getValue('subsidiary');

                const tax1amt = Number(invoice.getValue('taxamount')) || 0;
                const amount = Number(invoice.getValue('amount')) || 0;
                // const netamountnotax = invoice.getValue('netamountnotax');
                const fxamount = Number(invoice.getValue('fxamount')) || 0;
                const taxrate1 = (tax1amt * 100) / amount;
                const fxtax1amt = taxrate1 !== 0 ? (fxamount * taxrate1) / 100 : 0;

                if (taxrate1) {
                    taxRateArray.push(taxrate1);
                }

                consolidatedData.subTotal += fxamount;
                consolidatedData.taxAmount += fxtax1amt;

                const desc = invoice.getValue('memo');
                let lineItem = {
                    name: invoice.getText('item'),
                    description: desc.replace(/&/g, '&amp;').replace(/\n/g, '<br />'),
                    quantity: invoice.getValue('quantity'),
                    rate: invoice.getValue('rate'),
                    amount,
                    fxamount,
                    tax1amt: fxtax1amt,
                    taxrate1
                };
                consolidatedData.lineItems.push(lineItem);

                consolidatedData.totalAmount += (fxamount + fxtax1amt);
            });

            //log.debug('customformArray', customformArray);
            customformArray.forEach(function (customFormId) {
                if (consolidatedData.customform == '' && customFormId) {
                    consolidatedData.customform = customFormId;
                }
            });

            if (taxRateArray.length) {
                const totalRates = taxRateArray.reduce((acc, curr) => acc + curr, 0);
                consolidatedData.taxRate = (totalRates / taxRateArray.length).toFixed(2);
            }

            consolidatedData.invoices = reduceInvoiceData(invoicesArray);
            consolidatedData.newSubtotal = consolidatedData.subTotal + consolidatedData.discounttotal;
            consolidatedData.subsidiary = record.load({ type: record.Type.SUBSIDIARY, id: subsidiaryId });
            return consolidatedData;
        }

        function generateConsolidatedPDF(consolidatedData, consolidatedInvoiceNumber, customerRecord) {
            var renderer = render.create();

            // Select the appropriate template based on the form used in the invoice
            let templateId = 'CUSTTMPL_CONSOLIDATEDINVOICE';
            const templateObj = advPdfTemplates.find(template => template.customform === consolidatedData.customform);
            if (templateObj) {
                templateId = templateObj.templateId;
            }

            renderer.setTemplateByScriptId(templateId);

            renderer.addCustomDataSource({
                format: render.DataSource.JSON,
                alias: "data",
                data: JSON.stringify({
                    consolidatedInvoiceNumber: consolidatedInvoiceNumber,
                    date: consolidatedData.date,
                    customer: consolidatedData.customer,
                    address: customerRecord.address.replace(/\n/g, '<br />'),
                    subsidiaryName: consolidatedData.subsidiaryName,
                    currency: consolidatedData.currency,
                    subTotal: consolidatedData.subTotal,
                    taxAmount: (consolidatedData.taxAmount ? consolidatedData.taxAmount : 0.00),
                    taxRate: consolidatedData.taxRate,
                    totalAmount: consolidatedData.totalAmount,
                    lineItems: consolidatedData.lineItems,
                    endUserAddress: consolidatedData.endUserAddress,
                    invoices: consolidatedData.invoices,
                    vatregnumber: consolidatedData.vatregnumber,
                    discounttotal: consolidatedData.discounttotal,
                    amountremaining: consolidatedData.amountremaining,
                    currencyId: consolidatedData.currencyId,
                    newSubtotal: consolidatedData.newSubtotal,
                    billaddress: consolidatedData.billaddress
                })
            });

            const logoFile = file.load({ id: consolidatedData.subsidiary.getValue('logo') });

            let logoUrl = logoFile.url;
            logoUrl = logoUrl.replace(/&/g, '&amp;');

            renderer.addCustomDataSource({
                format: render.DataSource.OBJECT,
                alias: "subsidiary",
                data: {
                    custrecord_usi_sub_remit: consolidatedData.subsidiary.getValue('custrecord_usi_sub_remit'),
                    email: consolidatedData.subsidiary.getValue('email'),
                    mainaddress_text: consolidatedData.subsidiary.getValue('mainaddress_text'),
                    logo: logoUrl
                }
            });

            var pdf = renderer.renderAsPdf({
                id: 'test_pdf'
            });
            pdf.name = 'Consolidated_Invoice_' + consolidatedInvoiceNumber + '.pdf';
            pdf.folder = folderID;
            var fileId = pdf.save();
            return { pdf, fileId };
        }

        function updateIndividualInvoices(invoices, cinvId) {
            try {
                invoices.forEach(function (invoice) {
                    record.submitFields({
                        type: record.Type.INVOICE,
                        id: invoice.id,
                        values: {
                            'custbody_consolidated_invoice': 'T',
                            'custbody_consolidated_invoice_tranid': cinvId,
                            'custbody_usi_trx_excludeemail': 'T'
                        }
                    });
                });
            } catch (e) {
                log.error('Error Saving Record', e);
            }
        }

        function recordConsolidatedInvoiceCustomRecord(custID) {
            try {
                var cinvRecord = record.create({
                    type: 'customrecord_consolidated_invoice',
                    isDynamic: true
                });

                // cinvRecord.setValue({ fieldId: 'custrecord_consolidated_invoice_url', value: pdfURL });
                cinvRecord.setValue({ fieldId: 'custrecord_consolidated_invoice_customer', value: custID });
                const id = cinvRecord.save();

                //log.debug('Consolidated Invoice Custom Record Successfully saved!', id);
                return id;
            } catch (e) {
                log.error('Error Saving Record', e);
            }
        }

        function reduceInvoiceData(invoices) {
            const grouped = {};

            invoices.forEach(invoice => {
                const key = `${invoice.trandate}-${invoice.duedate}-${invoice.currency}`;

                if (!grouped[key]) {
                    // Initialize the group
                    grouped[key] = {
                        trandate: invoice.trandate,
                        duedate: invoice.duedate,
                        trandateGerman: invoice.trandateGerman,
                        trandateUS: invoice.trandateUS,
                        trandateAu: invoice.trandateAu,
                        duedateGerman: invoice.duedateGerman,
                        duedateUS: invoice.duedateUS,
                        duedateAu: invoice.duedateAu,
                        currency: invoice.currency,
                        total: invoice.total,
                        otherrefnum: invoice.otherrefnum
                    };
                } else {
                    // Update the existing group
                    grouped[key].total = (parseFloat(grouped[key].total) + parseFloat(invoice.total)).toFixed(2);
                    // grouped[key].otherrefnum += `, ${invoice.otherrefnum}`;
                    grouped[key].otherrefnum = grouped[key].otherrefnum ? `${grouped[key].otherrefnum}, ${invoice.otherrefnum}` : invoice.otherrefnum;
                }
            });

            // Convert the grouped object back to an array
            return Object.values(grouped);
        }

        /**
         * Function to format date as dd.MM.yyyy
         * @param date - The date object to format
         * @returns Formatted date string in dd.MM.yyyy format
         */
        function formatDate(date) {
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
            const year = date.getFullYear();
            return `${day}.${month}.${year}`;
        };

        function formatDateToMDYYYY(input) {
            const date = new Date(input);
            if (isNaN(date)) throw new Error('Invalid date input');

            const month = date.getMonth() + 1; // Months are zero-indexed
            const day = date.getDate();
            const year = date.getFullYear();

            return `${month}/${day}/${year}`;
        };

        function formatDateToDDMMYYYY(date) {
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
            const year = date.getFullYear();
            return `${day}/${month}/${year}`;
        };

        return {
            onRequest: onRequest
        };
    });
