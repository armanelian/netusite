function customizeGlImpact(transactionRecord, standardLines, customLines, book)
 {
    try{
        //var transactionRecord = nlapiLoadRecord(record.getRecordType(),record.getId());
        //3765: 00-401-Assy | Machine, Genmega TRT w/ Router
        //5360:	00-405-Assy | Genmega, TRT w/Router, 4-Drawer
        //1138:	18-103-Assy-CFX-DFI | Logic Module, DFI R1505, CFX
        //1141:	18-103-Assy-POG-DFI | Kit Logic Module DFI R1505 POG
        //3825: 18-103-Assy-POG-DFI-HOTSWAP | Logic Module, DFI, HotSwap, R1505, POG
        //1147:	18-106-Assy-POG | Logic Module, A320, MSI, POG

        var a_itemChanged = [5722,5723,5828,1137,1138,5840,1139,1140,3826,1141,3825];

        var recordType = transactionRecord.getRecordType()
        
        var recordId = transactionRecord.getId()

        if (recordType === "itemfulfillment") {
            var createdFromType = nlapiLookupField("itemfulfillment", recordId, "createdfrom.type");
            nlapiLogExecution('DEBUG', 'createdFromType:', createdFromType);
            if (createdFromType == "TrnfrOrd") return;
        }

        var context = nlapiGetContext();
        var makeDepartmentsMandatory = context.getPreference('deptmandatory');
        var allowPerLineDepartments = context.getPreference('deptsperline');
        
        var entityId = transactionRecord.getFieldValue('entity');
        //nlapiLogExecution('DEBUG', 'entityId:', entityId);
        var tranDate = transactionRecord.getFieldValue('trandate');
        tranDate = nlapiStringToDate(tranDate);
        //tranDate = new Date(tranDate.getFullYear,tranDate.getMonth()+1,tranDate.getMonth()+1)
        nlapiLogExecution('DEBUG', 'tranDate:', tranDate);
        var glStartDate = new Date(2024,6,29,0,0,0);
        //glStartDate = nlapiDateToString(glStartDate);
        // = nlapiStringToDate(glStartDate);
        //nlapiLogExecution('DEBUG', 'glStartDate:', glStartDate);

        if(tranDate.getTime()>=glStartDate.getTime()){
            var a_itemIncomeAccount = [];
            var a_itemCOGSAccount = [];
            var a_itemNewIncomeAccount = [];
            var a_itemNewCOGSAccount = [];
            var a_lastPoPrice = [];
            var assemblyitemSearch = nlapiSearchRecord("item",null,
                    [           
                    ["internalid","anyof",a_itemChanged]
                    ], 
                    [
                    new nlobjSearchColumn("internalid"), 
                    new nlobjSearchColumn("incomeaccount"), 
                    new nlobjSearchColumn("expenseaccount"), 
                    new nlobjSearchColumn("custitemcustitempa_mr_reclassincomeacc"), 
                    new nlobjSearchColumn("custitemcustitempa_mr_reclasscos"),
                    new nlobjSearchColumn("lastpurchaseprice")
                    ]
                );
            
            for(var i=0;i<assemblyitemSearch.length;i++){
                var itemInternalId = assemblyitemSearch[i].getId();
                //nlapiLogExecution('DEBUG', 'itemInternalId: ', itemInternalId);
                var itemIncomeAccount = assemblyitemSearch[i].getValue("incomeaccount");
                var itemCOGSAccount = assemblyitemSearch[i].getValue("expenseaccount");
                var itemNewIncomeAccount = assemblyitemSearch[i].getValue("custitemcustitempa_mr_reclassincomeacc");
                var itemNewCOGSAccount = assemblyitemSearch[i].getValue("custitemcustitempa_mr_reclasscos");
                var lastPOprice =  assemblyitemSearch[i].getValue("lastpurchaseprice");
                a_itemIncomeAccount[itemInternalId] = itemIncomeAccount;
                a_itemCOGSAccount[itemInternalId]   = itemCOGSAccount;
                a_itemNewIncomeAccount[itemInternalId] = itemNewIncomeAccount;
                a_itemNewCOGSAccount[itemInternalId]   = itemNewCOGSAccount;
                a_lastPoPrice[itemInternalId] = lastPOprice;
            }

            var itemGLData = [];
            var itemCnt = transactionRecord.getLineItemCount('item');
            for(var i=1;i<=itemCnt;i++){
                var itemId = transactionRecord.getLineItemValue('item','item',i);
                //nlapiLogExecution('DEBUG', 'itemId: ', itemId);
                var itemDescription = transactionRecord.getLineItemValue('item','description',i);
                var itemAmount = transactionRecord.getLineItemValue('item','amount',i);
                var isApplied = transactionRecord.getLineItemValue('item','apply',i);
                //nlapiLogExecution('DEBUG', 'isApplied: ', isApplied);
                if((parseFloat(itemAmount)>0.00 && (recordType == 'salesorder' || recordType == 'invoice')) || (recordType =='itemfulfillment'))
                {
                    var itemDepartment = transactionRecord.getLineItemValue('item','department',i);
                    var itemClass = transactionRecord.getLineItemValue('item','class',i);
                    var itemLocation = transactionRecord.getLineItemValue('item','location',i);

                    var itemQunatity = transactionRecord.getLineItemValue('item','quantity',i);
                    nlapiLogExecution('DEBUG', 'itemQunatity: ', itemQunatity);
                    if(a_itemChanged.indexOf(parseInt(itemId))>= 0){
                        itemGLData.push({
                            itemId : itemId,
                            itemDescription: itemDescription,
                            itemAmount : itemAmount,
                            itemDepartment:itemDepartment,
                            itemClass:itemClass,
                            itemLocation:itemLocation,
                            itemIncomeAccount:a_itemIncomeAccount[itemId],
                            itemCOGSAccount:a_itemCOGSAccount[itemId],
                            itemNewIncomeAccount:a_itemNewIncomeAccount[itemId],
                            itemNewCOGSAccount:a_itemNewCOGSAccount[itemId],
                            itemQunatity : itemQunatity,
                            lastPOprice:a_lastPoPrice[itemId]
                        });
                    }
                }
            }
            nlapiLogExecution('DEBUG', 'itemGLData: ', JSON.stringify(itemGLData));
            if(itemGLData.length>0)
            {        
                for(var i=0;i<itemGLData.length;i++){                    
                                            
                    //Add Debit Line ==============================
                    var newDebitLine = customLines.addNewLine();
                    if(recordType == 'salesorder' || recordType == 'invoice'){
                        newDebitLine.setDebitAmount(parseFloat(itemGLData[i].itemAmount));
                        newDebitLine.setAccountId(parseInt(itemGLData[i].itemIncomeAccount));
                    }
                    else{
                        //item fulfillment
                        newDebitLine.setCreditAmount(parseFloat(itemGLData[i].lastPOprice) * parseFloat(itemGLData[i].itemQunatity));
                        newDebitLine.setAccountId(parseInt(itemGLData[i].itemCOGSAccount));
                    }                 
                    newDebitLine.setEntityId(standardLines.getLine(0).getEntityId());

                    //if (makeDepartmentsMandatory || allowPerLineDepartments)
                    {
                        // can also optionally set department
                        if(itemGLData[i].itemDepartment){
                            nlapiLogExecution('DEBUG', 'itemDepartment: ', itemGLData[i].itemDepartment);
                            newDebitLine.setDepartmentId(parseInt(itemGLData[i].itemDepartment));

                        }
                    }

                    if(itemGLData[i].itemClass){
                            nlapiLogExecution('DEBUG', 'itemClass: ', itemGLData[i].itemClass);

                        newDebitLine.setClassId(parseInt(itemGLData[i].itemClass));

                    }

                    if(itemGLData[i].itemLocation){
                            nlapiLogExecution('DEBUG', 'itemLocation: ', itemGLData[i].itemLocation);

                        newDebitLine.setLocationId(parseInt(itemGLData[i].itemLocation));
                    }

                    if(itemGLData[i].itemDescription){

                        newDebitLine.setMemo(itemDescription);

                    }

                    //Add Credit Line ========================
                    var newLine = customLines.addNewLine();
                    if(recordType == 'salesorder' || recordType == 'invoice'){
                        newLine.setCreditAmount(parseFloat(itemGLData[i].itemAmount));
                        nlapiLogExecution('DEBUG', 'itemNewIncomeAccount: ', itemGLData[i].itemNewIncomeAccount);

                        newLine.setAccountId(parseInt(itemGLData[i].itemNewIncomeAccount));
                    }            
                    else{
                        //item fulfillment
                        newLine.setDebitAmount(parseFloat(itemGLData[i].lastPOprice) * parseFloat(itemGLData[i].itemQunatity));
                        nlapiLogExecution('DEBUG', 'itemNewCOGSAccount: ', itemGLData[i].itemNewCOGSAccount);

                        newLine.setAccountId(parseInt(itemGLData[i].itemNewCOGSAccount));
                    }  
                    newLine.setEntityId(standardLines.getLine(0).getEntityId());

                    //if (makeDepartmentsMandatory || allowPerLineDepartments)
                    {
                        // can also optionally set department
                        if(itemGLData[i].itemDepartment){
                            
                            nlapiLogExecution('DEBUG', 'itemDepartment: ', itemGLData[i].itemDepartment);

                            newLine.setDepartmentId(parseInt(itemGLData[i].itemDepartment));

                        }

                    }

                    if(itemGLData[i].itemClass)
                        newLine.setClassId(parseInt(itemGLData[i].itemClass));

                    if(itemGLData[i].itemLocation)
                        newLine.setLocationId(parseInt(itemGLData[i].itemLocation));

                    if(itemGLData[i].itemDescription)
                    newLine.setMemo(itemDescription);                                

                }      
            }
        }
    }
    catch(e){
        nlapiLogExecution('DEBUG', 'Exception: ', e);
    }
 
 }