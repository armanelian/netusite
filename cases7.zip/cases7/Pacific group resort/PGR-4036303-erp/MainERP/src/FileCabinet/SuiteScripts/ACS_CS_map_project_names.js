/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * 
 *  Version    Date            Author              Remarks
 *  1.00       05/08/2025      Elian Arman         Case #6333950
 * 
 */
define(['N/search'],

function(search) {
    
    function fieldChanged(scriptContext) {

        const logTitle = 'fieldChanged';
        try{
            const { fieldId, currentRecord } = scriptContext;

            if(fieldId == 'custbody3'){
                let capexCheckbox = currentRecord.getValue('custbody2');
                let projectId = currentRecord.getValue('custbody3');

                if(capexCheckbox){
                    let projectName;
                    search.create({
                        type: 'customrecord_map_project_id_with_name',
                        filters: {
                            name: 'custrecord_mapping_project_id',
                            operator: 'anyof',
                            values: projectId
                        },
                        columns: ['custrecord_mapping_project_name'],
                    }).run().each(function (result) {
                        projectName = result.getText('custrecord_mapping_project_name');
                        return true;
                    });
                    
                    if(projectName) currentRecord.setText('custbody_project_name', projectName);
                }
                
            }
        }catch(error){
            console.log(error);
        }
    }

    function saveRecord(scriptContext) {
        const { currentRecord } = scriptContext;
    
        let capexCheckbox = currentRecord.getValue('custbody2');
        let projectIDField = currentRecord.getValue('custbody3');

        if(capexCheckbox && !projectIDField){
            alert('Please enter a value for Project ID');
            return false;
        } 

        return true;

    }

    return {
        fieldChanged: fieldChanged,
        saveRecord: saveRecord
    };
    
});
