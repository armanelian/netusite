/**
 * @NApiVersion 2.1
 * @NScriptType WorkflowActionScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       10/07/2025      Elian Arman         Case #6535847
 * 
 */
define(['N/email', 'N/runtime', 'N/render', 'N/search', 'N/file'],

    (email, runtime, render, search, file) => {
        const onAction = (scriptContext) => {
            try {
                const { newRecord } = scriptContext;
                const emailTemplateId = runtime.getCurrentScript().getParameter("custscript_email_template");
                const recipients = runtime.getCurrentScript().getParameter("custscript_recipients") ? runtime.getCurrentScript().getParameter("custscript_recipients") : runtime.getCurrentUser().id;
                const bccEmail = runtime.getCurrentScript().getParameter("custscript_bcc") ? [runtime.getCurrentScript().getParameter("custscript_bcc")] : [];
                const ccEmail = runtime.getCurrentScript().getParameter("custscript_cc") ? [runtime.getCurrentScript().getParameter("custscript_cc")] : [];

                let lineCount = newRecord.getLineCount({ sublistId: 'mediaitem' });

                let emailTemplate = render.mergeEmail({
                    templateId: emailTemplateId,
                    transactionId: newRecord.id
                });

                let filesId = getAttachmentsFromSearch(newRecord.id);
                let filesArray = [];
                
                filesId.forEach(id => {
                    let objFile = file.load({ id: id });
                    filesArray.push(objFile);
                }); 

                const pdfFile = render.transaction({
                    entityId: newRecord.id,
                    printMode: render.PrintMode.PDF,
                    type: newRecord.type
                });

                filesArray.push(pdfFile);

                log.debug('recipients', recipients);
                log.debug('subject', emailTemplate.subject);
                log.debug('body', emailTemplate.body);
                log.debug('cc', ccEmail);
                log.debug('bcc', bccEmail);

                let sender = runtime.getCurrentUser().id;

                email.send({
                    author: sender,
                    body: emailTemplate.body,
                    recipients: recipients,
                    subject: emailTemplate.subject,
                    attachments: filesArray,
                    bcc: bccEmail,
                    cc: ccEmail,
                    relatedRecords: {
                        transactionId: newRecord.id
                    }
                });

            } catch (error) {
                log.error('onAction', error);
            }
        }
        const getAttachmentsFromSearch = (transactionId) => {
            const attachments = [];
            try {
                const transactionAttachmentsSearch = search.create({
                    type: "transaction",
                    filters: [
                        ["mainline", "is", "T"],
                        "AND",
                        ["internalid", "anyof", transactionId]
                    ],
                    columns: [
                        search.createColumn({
                            name: "internalid",
                            join: "file",
                            label: "Internal ID"
                        })
                    ]
                });
                const results = transactionAttachmentsSearch.run().getRange({
                    start: 0,
                    end: 1000
                });
                results.forEach(result => {
                    const fileId = result.getValue({
                        name: "internalid",
                        join: "file"
                    });
                    if (fileId) attachments.push(Number(fileId));
                });
            } catch (error) {
                log.error(`Unable to fetch attachments for transaction ${transactionId}`, error);
            }
            return attachments;
        };
        return { onAction };
    });
