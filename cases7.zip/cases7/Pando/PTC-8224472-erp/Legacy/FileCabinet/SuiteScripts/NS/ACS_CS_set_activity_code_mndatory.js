/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * 
 *  Version    Date            Author              Remarks
 *  1.00       04/23/2025      Elian Arman         Case #6301878
 *  2.00       07/25/2025      Elian Arman         Case #6301878 - Changing activity code validation due to item groups
 * 
 */
define([],

    function () {

        function validateLine(scriptContext) {
            const logTitle = 'validateLine';
            try {
                if(scriptContext.sublistId == 'item'){

                    let currRec = scriptContext.currentRecord;
                    
                    let itemType = currRec.getCurrentSublistValue({
                        sublistId: 'item', 
                        fieldId: 'itemtype'
                    });

                    let activityCode = currRec.getCurrentSublistValue({
                        sublistId: 'item', 
                        fieldId: 'cseg_paactivitycode'
                    });

                    if(!activityCode && itemType != 'EndGroup' && itemType != 'Group') {
                        alert('Please enter an Activity Code.');
                        return false;
                    }
                }
                
                return true;
            } catch (error) {
                log.error(logTitle, error);
            }
        }

        function saveRecord(scriptContext) {
            const logTitle = 'saveRecord';
            try {

                    let currRec = scriptContext.currentRecord;
                    let countSub = currRec.getLineCount('item');
                    for(let i = 0; i < countSub; i++){
                        currRec.selectLine({
                            sublistId: 'item',
                            line: i
                        });

                        let itemType = currRec.getCurrentSublistValue({
                            sublistId: 'item',
                            fieldId: 'itemtype'
                        });

                        let activityCode = currRec.getCurrentSublistValue({
                            sublistId: 'item',
                            fieldId: 'cseg_paactivitycode'
                        });

                        if(!activityCode && itemType != 'EndGroup' && itemType != 'Group') {
                            alert('Please enter an Activity Code for line ' + i );

                            return false;
                        }
                    }
                
                return true;
            } catch (error) {
                log.error(logTitle, error);
            }
        }

        return {
            validateLine: validateLine,
            saveRecord: saveRecord
        };

    });
