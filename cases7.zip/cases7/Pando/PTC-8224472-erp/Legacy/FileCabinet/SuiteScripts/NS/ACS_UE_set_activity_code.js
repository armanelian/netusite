/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       04/23/2025      Elian Arman         Case #6301878
 *  1.01       07/28/2025      Elian Arman         Adding copy context
 * 
 */
define(['N/search'],

    (search) => {

        const beforeSubmit = (scriptContext) => {
            const logTitle = 'beforeSubmit';
            try {
                if (scriptContext.type == 'create' || scriptContext.type == 'edit' || scriptContext.type == "copy") {

                    let newRec = scriptContext.newRecord;

                    let listCount = newRec.getLineCount('expense');

                    let accountList = [];

                    for (let i = 0; i < listCount; i++) {

                        let account = newRec.getSublistValue({
                            sublistId: 'expense',
                            fieldId: 'account',
                            line: i
                        });
                        
                        accountList.push(account);
                    }

                    let mapActivities = {};

                    search.create({
                        type: "customrecord_mapping_activity_code",
                        filters:
                            [
                                ["custrecord_account", "anyof", accountList]
                            ],
                        columns: ["custrecord_account", "custrecord_activity_code"]
                    }).run().each(function (result) {
                        account = result.getValue('custrecord_account');

                        mapActivities[account] = result.getValue('custrecord_activity_code');
                    });

                    for (let i = 0; i < listCount; i++) {
                        account = newRec.getSublistValue({
                            sublistId: 'expense',
                            fieldId: 'account',
                            line: i
                        });

                        if (mapActivities[account]) {
                            newRec.setSublistValue({
                                sublistId: 'expense',
                                fieldId: 'cseg_paactivitycode',
                                line: i,
                                value: mapActivities[account]
                            });

                            log.audit('Record Saved', 'TYPE: ' + newRec.type + ' - ID: ' + newRec.id);

                        }
                    }
                }
            } catch (error) {
                log.error(logTitle, error);
            }


        }


        return { beforeSubmit }

    });
