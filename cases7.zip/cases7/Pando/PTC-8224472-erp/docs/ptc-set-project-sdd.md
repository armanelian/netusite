![](media/netsuite-logo.png)

Copyright© 2025, Oracle and/or its affiliates.

Any reproduction or distribution of any part of this document without the prior written permission of Oracle NetSuite is strictly prohibited.

The information included in this document is confidential and proprietary information of Oracle NetSuite. (2025 Feb 13)

# 1. Set Project

## 1.1. Leading Practice

### 1.1.1. Flow Diagram

![](media/set-project-flow.png)

### 1.1.2. Custom Objects

Custom Fields
|Field Name|Internal ID|Type|List/Record|Description|
|----------|-----------|----|-----------|-----------|
|Project|custbody_ns_project|List/Record|Project|Stores the Project to be copied to all Sales Order lines.|

## 1.2. Order to Cash

### 1.2.1. Manage Sales Orders

This process is used to copy the Project from a header-level custom field onto the Sales Order lines.

The process will start when a Sales Order is created:
- The user will set the Project in a header-level custom field.
- The user will save the Sales Order.
- The script will get the Project from the custom field and copy its value to all Sales Order lines.

The process ends.

## 1.3. Alternate Flows

**Alt**: If the Project is not populated, the script will do nothing.
**Alt**: If the Sales Order is related to a Subscription, the script will do nothing.

## 1.4. Test Cases

- Create a Sales Order with a Project.
- Create a Sales Order without a Project.
- Create a Sales Order with a Subscription.

## 1.5. Assumptions

- Users will be responsible for setting the Project at the header-level.
- The script will be deployed to the Sales Order record only.
- When Invoices are generated, the Project will be sourced from the originating Sales Order.
