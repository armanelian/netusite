/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       04/14/2025      Elian Arman         Case #6115991
 * 
 */
define(['N/runtime'],

    (runtime) => {

        const beforeSubmit = (scriptContext) => {
            const logTitle = 'beforeSubmit';
            try{
                if(scriptContext.type == 'create' || scriptContext.type == 'edit'){

                    let newRec = scriptContext.newRecord;
                    
                    let entityID = runtime.getCurrentScript().getParameter('custscript_entity_id');
                    if(!entityID) entityID = 'entity';
                    let entity = newRec.getText(entityID);
                    
                    let sublistId = runtime.getCurrentScript().getParameter('custscript_sublist_id');
                    let listCount = newRec.getLineCount(sublistId);
                
                    for (let i = 0; i < listCount; i++) {
        
                        if (!entity) {
                            let lineEntity = newRec.getSublistValue({
                                sublistId: sublistId,
                                fieldId: 'entity_display',
                                line: i
                            });
        
                            newRec.setSublistValue({
                                sublistId: sublistId,
                                fieldId: 'custcol_acs_name',
                                line: i,
                                value: lineEntity
                            });        
                        } else {
                            newRec.setSublistValue({
                                sublistId: sublistId,
                                fieldId: 'custcol_acs_name',
                                line: i,
                                value: entity
                            });
                        }
                    }
                }

            }catch(error){
                log.error(logTitle, error);
            }
            

        }

        return { beforeSubmit }

    });
