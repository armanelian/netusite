/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       04/14/2025      Elian Arman         Case #6115991
 * 
 */
define(['N/search', 'N/record'],

    (search, record) => {

        const getInputData = (inputContext) => {
            const logTitle = 'getInputData';
            try {
                let transactions = search.create({
                    type: "transaction",
                    filters:
                        [
                            ["type", "anyof", "Journal", "Check", "PurchOrd", "VendAuth", "VPrep", "VendBill", "CardChrg", "CustPymt", "CustInvc", "AdvJRNL", "CardRfnd"],      
                            "AND", 
                            ["accountingperiod.closed","is","F"]
                        ],
                    columns: []
                });

                return transactions;

            } catch (error) {
                log.error(logTitle, error);
            }
        }

        const reduce = (reduceContext) => {
            const logTitle = 'reduce';
            try {
                const contextValues = JSON.parse(reduceContext.values[0]);

                let recordId = contextValues.id;
                let type = contextValues.recordType;

                let rec = record.load({
                    type: type,
                    id: recordId
                });

                let recIdSaved = rec.save();

                log.audit('Record Saved', 'TYPE: ' + type + ' - ID: ' + recIdSaved);

            } catch (error) {
                log.error(logTitle, error);
            }
        }


        const summarize = (summaryContext) => {

        }

        return { getInputData, reduce, summarize }

    });
