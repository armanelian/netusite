/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * 
 *  Version    Date            Author              Remarks
 *  1.00       04/23/2025      Elian Arman         Case #6301878
 * 
 */
define([],

function() {

    function pageInit(scriptContext) {
        
        const logTitle = 'pageInit';
        try{
            let currRec = scriptContext.currentRecord;
            let itemSub = currRec.getSublist({
                sublistId: 'item'
            });
            let activityCol = itemSub.getColumn({
                fieldId: 'cseg_paactivitycode'
            });
    
            activityCol.isMandatory = true;
        }catch(error){
            log.error(logTitle, error);
        }
    }

    return {
        pageInit: pageInit,
    };
    
});
