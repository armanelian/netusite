/**
 *@NApiVersion 2.1
 *@NScriptType ClientScript
 *
 * OLA_CS_OrderEntry.js 
 * 
 * Client Script for cash sales and sales orders
 * 
 *  Version Date        Author          Remarks
 *  1.00    08/12/2020  eric.barro      Initial deployment
 *  1.10    08/14/2020  eric.barro      Deployed to production
 *  1.20    09/26/2020  eric.barro      Added case pack qty check
 *  1.30    01/14/2021  eric.barro      Added check for COM orders
 *  1.40    06/29/2021  eric.barro      Fixed issue with missing shipping contact email address
 *  1.50    07/01/2021  eric.barro      Fixed issue with overwriting class,location,shipping contact email when in edit mode
 *  1.60    07/09/2021  miriam.armada   Added Pallet Calculator back
 *  1.70    07/22/2021  eric.barro      Added validation for GST tax code
 *  1.80    09/10/2021  eric.barro      Removed unused objects and modules
 *  1.90    01/13/2022  miriam.armada   added auto coding for 855s functionality
 *  2.00    05/25/2022  eric.barro      Removed unused objects and functions; added GLN address lookup
 *  2.10    06/12/2022  eric.barro      Added sidebar panel for price level prices
 *  3.00    03/27/2023  eric.barro      Added messaging for EDI status from SPS Fulfillment Reports
 *  3.10    06/14/2023  miriam.armada   update Pallet messaging 
 *  3.20    08/29/2023  miriam.armada   clean 
 *  3.30    08/31/2023  miriam.armada   update freight carrier logic
 *  3.40    02/20/2025  esau.ocrospoma  Add alert quantity and case pack line
 *  3.50    04/03/2025  eric.barro      Added Tax Inclusive Pricing from customer
*/

define (
    [
        'N/currentRecord',
        'N/record',
        'N/runtime',
        'N/ui/message',
        'SuiteScripts/Library/OLA_Lib_Data',
        'SuiteScripts/Library/OLA_Lib_ClientHelpers',
        'SuiteScripts/Web Resources/js/common/sweetalert2.all.js',
    ],
function(
    currentRecord, 
    record, 
    runtime, 
    message,
    appData,
    appClient,
    Swal) {

    var mode;
    // config;
    var addressScore;
    const ALERT_TYPE = { ERROR: 'error', WARNING: 'warning', SUCCESS: 'success' }
    const ALERT_TITLE = { error: 'OOPS!', warning: 'WARNING!', success: 'SUCESS!' }

    //evaluateFormAction();

    //NOTE: pageInit fires only on create or edit never on view
    function pageInit(context) {
        //console.log('pageInit fired...');
        mode = context.mode;
        //console.log('mode @pageInit: ' + mode);
        var thisRecord = context.currentRecord;
        var poAckSent = thisRecord.getValue('custbody_ola_po_ack_sent');
        if (poAckSent == 'T' || poAckSent == true) {
            hideControls();
        }
        var config = appClient.getAppConfig();
        initializeControlAttributes();
        if (mode == 'create') {
            addCustomerDefaults();
        }
        appClient.initializeScripts(config);
    }
    
    function fieldChanged(context) {
        //set up an array for the list of fieldIds to trap
        var targetFields = [
            'entity',
            'class'
        ];
        if (targetFields.indexOf(context.fieldId) >= 0) {
            //console.log('fieldid: ' + context.fieldId);
            switch(context.fieldId) {
                case 'entity':
                    addCustomerDefaults();
                    saveVASCodes();
                    break;
                case 'class':
                    updateCompOrders(context);
                    break;
            }
        }
        // addition miria.armada pallet calculator
        var thisRecord = context.currentRecord;
        var fieldName = context.fieldId;
        var sublistName = context.sublistId;
        var line = context.line;
        //var op = context.operation;

        if (sublistName == 'item' && fieldName == 'quantity') {
            try {
                var qty = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantity'
                });

                var unitsPallet = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ola_qty_per_pallet'
                });
                //console.log('qty: ' + qty + ' units per pallet: ' + unitsPallet);

                if (Number(unitsPallet) > 0) {
                    var palletsLine = qty / unitsPallet;

                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ola_pallets_line',
                        value: palletsLine,
                        ignoreFieldChange: false
                    });
                }
                //Add message to qty/casepack
                var item = thisRecord.getCurrentSublistText({
                    sublistId: 'item',
                    fieldId: 'item'
                });
                var casepack = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ola_casepack_size'
                });
                const modulus = Number(casepack) > 0 ? qty % casepack: 0;
                if(modulus != 0){
                    showSwal(ALERT_TYPE.WARNING, 'Requested line: '+ (line+1) +', item: '+item+', quantity '+ qty +' must be in case pack quantity ' + casepack);
                    //showMessage('WARNING! Requested item quantity '+ qty +' must be in case pack quantity ' + casepack , 'warning');
                    //alert('WARNING! Requested item quantity '+ qty +' must be in case pack quantity ' + casepack)
                }
            } 
            catch (ex) {
                //console.log('error on line pallet calculation' + ex);
            }
        }
        // end addition miriam.armada pallet calculation

        // start 855 logic
        if (sublistName == 'item' && fieldName == 'custcol_sps_itemstatuscode1') {
            try {
                var spsLineCode = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_sps_itemstatuscode1'
                });
                //console.log('sps statuscode:' + spsLineCode);

                if (spsLineCode == '2') {
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_gen_noteinformationfield',
                        value: 'IP: Price Change / Correction',
                        ignoreFieldChange: true
                    });
                }
                if (spsLineCode == '3') {
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_gen_noteinformationfield',
                        value: 'IQ: Quantity Changed',
                        ignoreFieldChange: true
                    });
                }
                else {
                    return;
                }
            }
            catch (ex) {
                console.log('855 Status' + ex);
            }
        }

        // update date
        if (fieldName == 'shipdate') {
            var shipDate = thisRecord.getValue({
                fieldId: 'shipdate'
            });
            try {
                var lineCount = thisRecord.getLineCount({
                    sublistId: 'item'
                });
                for (var i = 0; i < lineCount; i++) {
                    thisRecord.selectLine({
                        sublistId: 'item',
                        line: i
                    });
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'expectedshipdate',
                        value: shipDate,
                        ignoreFieldChange: true,
                    });
                    /*thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_itemstatuscode1',
                        value: '4',
                        ignoreFieldChange: true,
                    });
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_gen_noteinformationfield',
                        value: 'DR: Date Changed',
                        ignoreFieldChange: true,
                    });*/
                    thisRecord.commitLine({
                        sublistId: 'item'
                    });
                }
            } 
            catch (ex) {
                console.log('855 Status' + ex);
            }
        }
        // end 855 logic
        var priceMismatch = false;
        if (sublistName == 'item' && fieldName == 'price') {
            var priceLevel = thisRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'price'
            });
            var customerId = thisRecord.getValue('entity');
            var customerData = getCustomerData(customerId);
            //console.log('price', priceLevel + ' ? ' + customerData.PriceLevel);
            if (priceLevel !== customerData.PriceLevel) {
               // alert('WARNING! Customer Price Level conflict. Price Level should be ' +  customerData.PriceLevel);
                thisRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ola_price_mismatch',
                    value: true
                });
                priceMismatch = true;
            }
            else {
                thisRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ola_price_mismatch',
                    value: false
                });
            }
            if (priceMismatch) {
                thisRecord.setValue('custbody_ola_price_change_hold', true);
            }
        }
    }

    //fires when sublist is changed
    function sublistChanged(context) {
        var thisRecord = context.currentRecord;
        var fieldName = context.fieldId; // added by miriam.armada pallet calculator
        var sublistName = context.sublistId;
        var op = context.operation;

        var shippingCountry = thisRecord.getValue('shipcountry');
        var incoTerms = thisRecord.getValue('custbody_incoterms');
        var orderType = thisRecord.getValue('custbody_ola_pickticket_suffix');

        if (sublistName === 'item') {
            // addition miriam.armada 06/14/2021 - pallet calculator
            try {
                //grab pallets value from lines 
                var lineCount = thisRecord.getLineCount({
                    sublistId: 'item'
                });

                console.log("total number of lines: " + lineCount);
                var totalPallets = 0
                var spsLineCodes = [];

                for (var i = 0; i < lineCount; i++) {
                    var palletQty = thisRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ola_pallets_line',
                        line: i
                    }) || 0;

                    var spsCode = thisRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_itemstatuscode1',
                        line:i
                    });

                    if (spsCode != '1') {
                        spsLineCodes.push(spsCode);
                    }
                    //only validate tax code if the following is true
                    //shipping country = Australia
                    //incoterms = DAP or DDP
                    //pick ticket suffix is not COM
                    if (shippingCountry == 'AU' && (incoTerms == '3' || incoTerms == '1') && orderType !== '6') {
                        var taxCode = thisRecord.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'taxcode',
                            line: i
                        }) || '';

                        if (taxCode !== '932') {
                            showMessage('WARNING! AUD GST is the recommended tax code', 'warning');
                            //alert('WARNING! AUD GST is the recommended tax code for this order');
                        }
                    }
                    //console.log("pallet qty per line " + palletQty);
                    // console.log("line#" + i);
                    totalPallets += palletQty;
                    //console.log("adding total pallets" + totalPallets);
                }
                // console.log("updating values")

                if (spsLineCodes.length > 0) {
                    thisRecord.setValue({
                        fieldId:'custbody_sps_acknowledgement_type',
                        value:'2'
                    });
                }
                
                thisRecord.setValue({
                    fieldId: 'custbody_ola_pallet_total',
                    value: totalPallets.toFixed(2),
                });

                if (Number(totalPallets) >= 33) {
                    showMessage("Total Pallets in order are equal or greater than 33, please confirm warehouse limitation on pick ticket size", 'warning');
                    //alert("WARNING! Total Pallets in order are equal or greater than 33, please confirm warehouse limitation on pick ticket size", 'warning');
                    return;
                }
            } 
            catch (ex) {
                console.log('error on total pallet calculation ' + ex);
            }
            // end addition miriam.armada 06/14/2021
        }
    }

    //fires when sublist line is changed
    function validateLine(context) {
        const AVATAX = '615';
        const NON_TAXABLE = '-7';
        var thisRecord = context.currentRecord;
        var customerId = thisRecord.getValue('entity');
        
        var sublistName = context.sublistId;
        if (sublistName === 'item') {
           var itemId = thisRecord.getCurrentSublistValue({
               sublistId: 'item', 
               fieldId: 'item'
            });
            //NOTE: This should be a configuration field and not hard-coded 
            //09/10/2021 etb
            if (itemId == '711') { //20142893
               showMessage('This item ' + itemId + ' cannot be included in a sales order! Please make sure to remove this item from the sales order before saving.', 'error');
               alert('WARNING! This item ' + itemId + ' cannot be included in a sales order! Please make sure to remove this item from the sales order before saving.');
            }
            var casePackQty = thisRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'custcol_ola_casepack_size'
            });
            var itemQty = thisRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'quantity'
            });
            var lineTaxCode = thisRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'taxcode'
            });
            console.log(itemId + '->' + itemQty + ' ? ' + casePackQty + ' taxcode ' + lineTaxCode);
           
            var customerPartNumber = getCustomerPartNumber(customerId, itemId);
            if (customerPartNumber != '') {
               var bpn = thisRecord.getCurrentSublistValue({
                   sublistId: 'item',
                   fieldId: 'custcol_sps_bpn'
               });
               if (bpn == '') {
                   //update the value of the BPN 
                   //no need to commit the line because the user will click Add or OK
                   thisRecord.setCurrentSublistValue({
                       sublistId: 'item',
                       fieldId: 'custcol_sps_bpn',
                       value: customerPartNumber
                   });
               }
            }
         
            var isClosed = thisRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'isclosed'
            });
            if (isClosed) {
                thisRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_sps_itemstatuscode1',
                    value: 6
                });
                var qtyAvail = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantityavailable'
                });
                var qtyRequested = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantity'
                });
                var itemScheduleQty1 = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_sps_itemscheduleqty1'
                });
                if (itemScheduleQty1 === '') {
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_itemscheduleqty1',
                        value: qtyRequested
                    });
                }
                thisRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_sps_gen_noteinformationfield',
                    value: Number(qtyRequested) > Number(qtyAvail) ? 'Out of stock' : 'Cancelled'
                });
                
            }
            else {
                var itemScheduleQty1 = thisRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_sps_itemscheduleqty1'
                });
                if (itemScheduleQty1 === '') {
                    var qtyRequested = thisRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'quantity'
                    });
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_itemscheduleqty1',
                        value: qtyRequested
                    });
                }
                /*
                console.log('validateLine mode: ' + mode);
                if (mode === 'create')  {
                    
                    console.log('lineTaxCode ' + lineTaxCode);
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'taxcode',
                        value: NON_TAXABLE
                    });
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'taxrate',
                        value: 0
                    });
                    thisRecord.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'mandatorytaxcode',
                        value: false
                    });
                    thisRecord.commitLine('item');
                    var lineTaxCode = thisRecord.getCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'taxcode'
                    });
                    console.log('lineTaxCode after commitLine' + lineTaxCode);
                }
                */
            }
        }
        return true;
    }

    //event that handles initialization when user clicks on sublist row
    function lineInit(context) {
        const AVATAX = '615';
        const NON_TAXABLE = '-7';
        var currentRecord = context.currentRecord;
        var sublistName = context.sublistId;
        
        if (sublistName === 'item') {
            var lineCount = currentRecord.getLineCount({
                sublistId: 'item'
            })
            var itemid = currentRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'item'
            });
            var itemname = currentRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'item_display'
            });
            //console.log('item: ' + itemid);
            /*
            console.log('lineInit mode: ' + mode);
            if (mode === 'create')  {
                currentRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'taxcode',
                    value: NON_TAXABLE
                });
                currentRecord.commitLine('item');
            }
            */
        }
    }

    function saveRecord(context) {
        const AVATAX_CANADA = '13787';
        var currentRecord = context.currentRecord;
        var transactionClass = currentRecord.getText('class');
        var transactionLocation = currentRecord.getText('location');
        var priceMismatchReasonCode = currentRecord.getValue('custbody_ola_price_mismatch_reasoncode');
        var priceMismatchReason = currentRecord.getValue('custbody_ola_price_mismatch_reason');
        var priceMismatch = currentRecord.getValue('custbody_ola_price_change_hold');
        var shippingCountry = currentRecord.getValue('shipcountry');
        var lineCount = currentRecord.getLineCount('item');
      
        saveVASCodes();
        var poNumber = currentRecord.getValue('otherrefnum');
        //console.log(poNumber);
        if (poNumber.length > 22) {
            showMessage('PO Number value exceeds 22 characters. Data will be truncated!', 'warning');
            currentRecord.setValue('otherrefnum', poNumber.substring(0, 22));
            return false;
        }
        if (transactionLocation === '' && transactionClass !== 'Media/Press') {
            showMessage('Default Fulfillment Location is not set up on the customer record.','error');
        }
        if (priceMismatch == true && (priceMismatchReasonCode === '' || priceMismatchReason === '')) {
            showMessage('WARNING! This order has a price mismatch.','warning');
            //set the price mismatch reason and reason code
            //currentRecord.setValue('custbody_ola_price_mismatch_reasoncode', 7); //Custom Price
            //currentRecord.setValue('custbody_ola_price_mismatch_reason', runtime.getCurrentUser().name + ': Price Mismatch');
            //NOTE: don't prevent the record from being saved.
            //return false;
        }
        for (var i = 0; i < lineCount; i++) {
            console.log('shippignCountry ' + shippingCountry);
            if (shippingCountry === 'CA') {
                currentRecord.selectLine({
                    sublistId: 'item',
                    line: i
                });
                currentRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'taxcode',
                    value: AVATAX_CANADA
                });
            }
        }
        return true;
    }

    /*--------start of custom client-side functions----------*/
    function getCustomerPartNumber(customer, item) {
        var searchId = 'customsearch_ola_item_crossref_lookup';
        var searchType = 'customrecord_sps_cxref';
        var searchFiltersObj = [
            {'name':'custrecord_sps_cxref_item', 'operator':'anyof', 'values':  item },
            {'name':'custrecord_sps_cxref_customer', 'operator':'anyof', 'values': customer}
        ];
        var keyColumn = 'Item';
        var encodeValue = false;
        var valuesOnly = true;
        var useLabels = true;
        var results = appData.getDataFromExistingSearch(searchType, searchId, searchFiltersObj, keyColumn, encodeValue, valuesOnly, useLabels)                
        var customerPartNumber = '';
        for (var i = 0; i < results.length; i++) {
            var result = results[i];
            for (var key in result) {
                var row = result[key];
                customerPartNumber = row.CustomerPartNumber;
            }
        }
        return customerPartNumber;
    }

    function validateFieldLength(context, maxFieldLength) {
        var thisRecord = context.currentRecord;
        var thisField = thisRecord.getValue(context.fieldId);
       // console.log(thisField + ' ' + maxFieldLength);
        if (thisField.length > maxFieldLength) {
            showMessage('Value exceeds ' + maxFieldLength + ' characters. Data will be truncated!', 'warning');
            thisField.setValue(thisField.substring(0, 22));
        }
    }

    function updateCompOrders(context) {
        var thisRecord = context.currentRecord;
        var transactionClass = thisRecord.getText('class');
        //set pick ticket suffix to COM when class = Media/Press
        if (transactionClass === 'Media/Press') {
            thisRecord.setValue('custbody_ola_pickticket_suffix', 6);
        }
    }

    function displayStatus(dayspending) {
        if (parseInt(dayspending) > 0) {
             appClient.displayStatus(dayspending);
        }
    }

    function displayPriceWarning() {
        if (jQuery('.uir-record-status')) {
            var status = jQuery('.uir-record-status').html();
            if (status.indexOf('Pending') != -1 || status.indexOf('Deposited') != -1) {
                jQuery('.uir-record-status').append(' <span style="color:red;"><< WARNING! Price Level Mismatch >></span>');
            }
        }
    }

    function displayEDIStatus(errorMsg) {
        if (jQuery('.uir-record-status')) {
            var status = jQuery('.uir-record-status').html();
            if (status.indexOf('Pending') != -1 || status.indexOf('Deposited') != -1) {
                jQuery('.uir-record-status').append(' <span style="color:red;"><< ' + errorMsg + ' >></span>');
            }
        }
    }

    function initializeControlAttributes() {
        console.log('intiializeControlAttributes...');
        var required_color = '#F9CBDE';
        var optional_color = '#f7d7ab'

        jQuery('#entity_display').css('background-color', required_color);
        jQuery('#inpt_custbody_incoterms6').css('background-color', required_color);
        jQuery('#inpt_class5').css('background-color', required_color);
        jQuery('#inpt_location6').css('background-color', required_color);
        jQuery('#inpt_custbody_incoterms8').css('background-color', required_color);
        jQuery('#inpt_shipaddresslist22').css('background-color', required_color);
        jQuery('#inpt_custbody_ola_pickticket_suffix7').css('background-color', required_color);

        jQuery('#custbody_ola_earliest_shipdate').css('background-color', required_color);
        jQuery('#shipdate').css('background-color', required_color);
        jQuery('#custbody_ola_cust_canceldate').css('background-color', required_color);

        jQuery('#otherrefnum').css('background-color', optional_color);
        jQuery('#custbody_ola_cust_department').css('background-color', optional_color);
        jQuery('#custbody_ola_shipping_email').css('background-color', required_color);
        jQuery('#custbody_ola_ship_freight_carrier').css('background-color', optional_color);
    }

    function hideControls(context) {
        var btnPoAck = document.getElementById('custpage_po_ack');
        var thisRecord = context.currentRecord;
        var createdBy = thisRecord.getValue('recordcreatedby');
        //check if not created by SPS Commerce
        if (createdBy !== '400904') {   
            //hide the button
            btnPoAck.style.visibility = hidden;
            btnPoAck.style.display = none;
        }
    }

    /*----start of utility functions----*/
    function addCustomerDefaults() {
        var thisRecord = currentRecord.get();
        var customerId = thisRecord.getValue('entity');
        var emailAddress = thisRecord.getValue('email');
        //console.log('customer: ' + customerId);
        if (customerId != "") {
            var customerData = getCustomerData(customerId);
            //auto-populate the class and location fields on the cash sales/sales order forms
            if (Object.keys(customerData).length > 0) {
                console.log(runtime.getCurrentUser().name);
                //check first if there are values before updating
                if (customerData.DefaultClass !== '') {
                    thisRecord.setValue('class', customerData.DefaultClass);
                }
                if (customerData.DefaultLocation !== '') {
                    thisRecord.setValue('location', customerData.DefaultLocation);
                }
                var incoterms = thisRecord.getValue('custbody_incoterms');
                if (incoterms === '') {
                    thisRecord.setValue('custbody_incoterms', customerData.IncoTerms);
                }
                //if (customerData.EmailAddress !== '' && (emailAddress === '' || emailAddress == null)) {
                    thisRecord.setValue('custbody_ola_shipping_email', customerData.EmailAddress);
                //}
                if (customerData.VATOverride) {
                    thisRecord.setValue('custbody_ava_taxoverride', true);
                }
                if (customerData.DeptLookup == true) {
                    var storeGLN = thisRecord.getValue('custbody_sps_department');
                    if (storeGLN === '' || storeGLN === null) {
                        storeGLN = thisRecord.getValue('custbody_sps_bt_addresslocationnumber');
                    }
                    var addressId = getAddressGLN(customerId, storeGLN);
                    thisRecord.setValue('custbody_ola_cust_department', addressId);
                }

                var carrier = thisRecord.getValue('custbody_ola_ship_freight_carrier');
                
                if (carrier =='' && customerData.FreightCarrier !== '') {
                    thisRecord.setValue('custbody_ola_ship_freight_carrier', customerData.FreightCarrier);
                }
            }
            //log.debug('customerData', customerData);
            //console.log('Customer defaults set...');
        }
        //console.log('Customer defaults not set...');
    }

    //fixes issue with multi-select field on save so that they "stick"
    function saveVASCodes() {
        var thisRecord = currentRecord.get();
        var customerId = thisRecord.getValue('entity');
        //console.log('customer: ' + customerId);
        var customerData = getCustomerData(customerId);
        if (customerData.VASCodes.length > 0 || customerData.VASCodes != undefined) {
            //VAS Activity Codes are multi-select separated by a delimiter
            var vCodes = '';
            //loop through the multi-select field
            for (var i = 0; i < customerData.VASCodes.length; i++) {
                var vCode = customerData.VASCodes[i];
                vCodes += vCode + '\u0005';
            }
            //console.log(vCodes);
            //update the field with the delimited string values from the array
            thisRecord.setValue('custbody_ola_vas_activity_code', vCodes);
        }
        var pickTicketSuffix = thisRecord.getValue('custbody_ola_pickticket_suffix');
        if (pickTicketSuffix === '') {
            thisRecord.setValue('custbody_ola_pickticket_suffix', customerData.OrderType);
        }
        //console.log('VAS Codes set...');
        //console.log(customerData.VASCodes);
    }

    //get customer information by loading the record
    function getCustomerData(customerid) {
        try {
            var data = {};
            var rec = record.load({
                type: 'customer',
                id: customerid
            });
            if (rec) {
                data = {
                    CustomerID: customerid,
                    Customer: rec.getValue('entityid'),
                    DefaultClass :  rec.getValue('custentity_ola_default_class'),
                    DefaultLocation : rec.getValue('custentity_ola_default_fulfill_location'),
                    IncoTerms : rec.getValue('custentity_ola_incoterms'),
                    VASCodes : rec.getValue('custentity_ola_cust_vas_code') || ' ',
                    OrderType : rec.getValue('custentity_ola_cust_order_type') || ' ',
                    EmailAddress : rec.getValue('email'),
                    ConfEmailAddress: rec.getText('custentity_add_if_email') || 'ediorders@olaplex.com',
                    VATOverride : rec.getValue('custentity_ola_vat_tax_override'),
                    EDIEnabled: rec.getValue('custentity_ola_edi_capable'),
                    AddressFileComplete: rec.getValue('custentity_ola_address_file'),
                    DeptLookup: rec.getValue('custentity_ola_cust_dept_lookup'),
                    PriceLevel: rec.getValue('pricelevel'),
                    FreightCarrier: rec.getValue('custentity_ola_def_freight_carrier'),
                    TaxInclusivePricing: rec.getValue('custentity_ola_tax_inclusive_pricing')
                }
            }
            return data;
        }
        catch (ex) {
            console.log(ex);
        }
    }

    function getAddressGLN(customerId, storeGLN) {
        var searchId = 'customsearch_ola_cust_gln_lookup';
        var searchType = 'customer';
        var searchFiltersObj = [
            { 'name': 'internalid', 'operator': 'anyof', 'values': customerId },
            { 'name': 'custrecord_ola_addr_reference_id', 'operator': 'is', 'values': storeGLN }
        ];
        var keyColumn = 'CustomerID';
        var encodeValue = false;
        var valuesOnly = true;
        var useLabels = true;
        var results = appData.getDataFromExistingSearch(searchType, searchId, searchFiltersObj, keyColumn, encodeValue, valuesOnly, useLabels)
        var addressLabel = '';
        for (var i = 0; i < results.length; i++) {
            var result = results[i];
            for (var key in result) {
                var row = result[key];
                addressLabel = row.AddressLabel;
            }
        }
        return addressLabel;
    }

    function showMessage(msg, type) {
        var msgType = message.Type.INFORMATION;
        switch(type) {
            case 'confirm':
                msgType = message.Type.CONFIRMATION;
                break;
            case 'error':
                msgType = message.Type.ERROR;
                break;
            case 'warning':
                msgType = message.Type.WARNING;
                break;
        }
        message.create({
            title: getGreeting() + ' -- ' + getUserName(),
            message: msg,
            type: msgType
        }).show(6500);
    }

    function getUserName() {
        var userName = runtime.getCurrentUser().name;
        //console.log(userName);
        //parse the username based on the delimite (comma)
        if (userName.indexOf(',') != -1) {
            var thisUser = userName.split(',');
            var retVal = thisUser[1] + ' ' + thisUser[0];
        }
        else {
            var retVal = userName;
        }
        return retVal;
    }

    function getGreeting() {
        var myDate = new Date();
        var hrs = myDate.getHours();
    
        var greeting;
    
        if (Number(hrs) < 12)
            greeting = 'Good Morning';
        else if (Number(hrs) >= 12 && Number(hrs) <= 17)
            greeting = 'Good Afternoon';
        else if (Number(hrs) >= 17 && Number(hrs) <= 24)
            greeting = 'Good Evening';

        return greeting;
    }

    /*----address matching code-----*/
    function matchAddress(thisRecord) {
        //var thisRecord = JSON.parse(thisRecordObj);
        var shipaddresslist = 0;
        var salesOrderNumber = thisRecord.getValue('tranid');
        var customerId = thisRecord.getValue('entity');
        var orderAddress = getOrderAddress(thisRecord);
        //return an array of existing customer addresses to be used for comparison
        var customerAddresses = getCustomerAddresses(customerId);
        var addressesToCompare = compareAddresses(customerAddresses, orderAddress);
       // console.log('addressToCompare ' + addressesToCompare);
        if (addressesToCompare.length > 0) {
            shipaddresslist = addressesToCompare[0].UseAddressId;
            if (shipaddresslist > 0) {
                thisRecord.setValue('shipaddresslist', shipaddresslist);
            }
            var msg = 'Ship Address: <b>' + 
                addressesToCompare[0].UseToMatch + 
                '</b><br/>Possible Match: <b>' + 
                addressesToCompare[0].UseAddressId + '-' +
                addressesToCompare[0].UseThisAddress + 
                '</b><br/>Percentage Match: <b>' + addressesToCompare[0].PercentageMatch + '</b>';
                //No need to send notification for address matches 03/27/2021 etb
            //sendNotification(msg, 'Address match for order ' + salesOrderNumber);
        }
        else {
            shipaddresslist = addCustomerAddress(customerId, orderAddress);
            if (shipaddresslist > 0) {
                thisRecord.setValue('shipaddresslist', shipaddresslist);
            }
            shipaddresslist = 'no match';
            var msg = 'Ship Address: <b>' + 
                orderAddress[0].Address + 
                '</b><br/><b>No Customer Addresses Match.</b>';
            sendNotification(msg, 'Address mismatch for order ' + salesOrderNumber);
        }
        thisRecord.setValue('custbody_ola_xtn_shipaddr_id', shipaddresslist);
    }

    function getCustomerAddresses(customerId) {
        const funcName = '@getCustomerAddresses';
        try {
            if (customerId != '') {
                var custObj = record.load({
                    type: record.Type.CUSTOMER,
                    id: customerId,
                    isDynamic: true
                });
                var addressLineCount = custObj.getLineCount('addressbook');
                var customerAddresses = [];
                if (addressLineCount > 0) {
                    for (var i = 0; i < addressLineCount; i++) {
                        custObj.selectLine({
                            sublistId: 'addressbook',
                            line: i
                        });
                        var customerAddressId = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'addressid'
                        });
                        var customerAddressLabel = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'label'
                        });
                        var customerAddressText = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'addrtext_initialvalue'
                        });
                        var customerAddressee = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'addressee_initialvalue'
                        });
                        var customerAddressCountry = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'country_initialvalue'
                        });
                        var customerAddressCity = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'city_initialvalue'
                        });
                        var customerAddress1 = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'addr1_initialvalue'
                        });
                        var customerAddress2 = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'addr2_initialvalue'
                        });
                        var customerZip = custObj.getCurrentSublistValue({
                            sublistId: 'addressbook', 
                            fieldId: 'zip_initialvalue'
                        });
                        var customerAddress = {
                            Street: customerAddress1,
                            Address2: customerAddress2,
                            City: customerAddressCity,
                            Zip: customerZip,
                            Country: customerAddressCountry,
                            Label: customerAddressLabel,
                            Addressee: customerAddressee,
                            Address: customerAddressText,
                            AddressId: customerAddressId
                        };
                        customerAddresses.push(customerAddress);
                    }
                }
            }
        }
        catch (ex) {
            console.log(ex);
        }
        finally {
            return customerAddresses;
        }
    }

    function getOrderAddress(thisRecord) {
        var orderAddress = [];
        var addressSubRecord = thisRecord.getSubrecord({fieldId: 'shippingaddress'});
        var country = addressSubRecord.getValue({
            fieldId: 'country'
        });
        var city = addressSubRecord.getValue({
            fieldId: 'city'
        });
        var address = addressSubRecord.getValue({
            fieldId: 'addr1'
        });
        var address2 = addressSubRecord.getValue({
            fieldId: 'addr2'
        });
        var state = addressSubRecord.getValue({
            fieldId: 'state'
        });
        var zip = addressSubRecord.getValue({
            fieldId: 'zip'
        });
        var addressee = addressSubRecord.getValue({
            fieldId: 'addressee'
        });
        var addressText = thisRecord.getValue('shippingaddress_text');
        if (zip.indexOf('-') != -1) {
            var zipSplits = zip.split('-');
            if (zipSplits.length > 0) {
                var orderShipZip = zipSplits[0];
            }
        }
        else {
            var orderShipZip = zip;
        } 
        orderAddress.push({
            Addressee: addressee,
            Street: address,
            Address2: address2,
            City: city,
            State: state,
            Zip: orderShipZip,
            Country: country,
            Address: addressText
        });
        return orderAddress;
    }

    function compareAddresses(customerAddresses, orderAddress) {
        const funcName = '@compareAddresses';
        try {
            var addressesToCompare = [];
            //loop through customerAddresses and compare with orderAddress
            for (var i = 0; i < customerAddresses.length; i++) {
                var customerAddress = customerAddresses[i];
                //country must match first
                if (customerAddress.Country.toUpperCase() == orderAddress[0].Country.toUpperCase()) {
                    var cityScore = getScore(customerAddress.City, orderAddress[0].City);
                    //reset global score comparison
                    addressScore = 0;
                    //and then zip must match next
                    if (customerAddress.Zip.indexOf('-') != -1) {
                        var splitZip = customerAddress.Zip.split('-');
                        //for US zip codes we just want the first 5 digits
                        if (splitZip[0].length == 5) {
                            var addressZip = splitZip[0].replace(/ /g, '');
                        }
                        else {
                            //this is for non-US zip codes which might have dashes
                            var addressZip = customerAddress.Zip.replace(/ /g, '');
                        }
                    }
                    else {
                        var addressZip = customerAddress.Zip.replace(/ /g, '');
                    }

                    if (addressZip == orderAddress[0].Zip.replace(/ /g,'')) {
                        var customerAddressCompare = customerAddress.Street.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "") +
                            customerAddress.City.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "");
                        
                        var orderAddressCompare = orderAddress[0].Street.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "") +
                           orderAddress[0].City.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "");

                        var cityStreetScore = getScore(customerAddressCompare.toUpperCase(), orderAddressCompare.toUpperCase());
                        //get length of orderaddressCompare
                        if (orderAddressCompare.length > customerAddressCompare.length) {
                            var expectedScore = orderAddressCompare.length;
                        }
                        else {
                            var expectedScore = customerAddressCompare.length;
                        }
                        
                        //get the percentage of matching characters
                        if (cityStreetScore == 0) {
                            var percentageMatch = 1;
                        }
                        else {
                            if (Number(expectedScore) > Number(cityStreetScore)) {
                                var percentageMatch = (Number(expectedScore) - Number(cityStreetScore)) / Number(expectedScore);
                            }
                            else {
                                var percentageMatch = Number(expectedScore) / Number(cityStreetScore);
                            }
                        }
                        //cityStreetScore = 0 means it's a perfect match
                        //percentageMatch must be greater than 50%
                        if ((cityStreetScore <= Number(expectedScore)/2)
                            || (Number(percentageMatch) >= .50 && Number(percentageMatch <= 1))) {
                            //reset global score comparison
                            addressScore = 0;
                            //get a weighted score for the street
                            var score = getScore(customerAddress.Street, orderAddress[0].Street);
                            var nearestMatches = getNearestMatches(score, customerAddress, orderAddress[0]);
                            nearestMatches.PercentageMatch = percentageMatch * 100;
                            addressesToCompare.push(nearestMatches);
                            addressScore = 0;
                            break;
                        }
                    }
                }
            }
        }
        catch (ex) {
            console.log(ex);
        }
        return addressesToCompare;
    }

    function getNearestMatches(score, customerStreetAddress, orderStreetAddress) {
        var useThisAddress = '';
        var matchWith = '';
        if (addressScore == 0) {
            //seed it first
            addressScore = score;
        }
        if (score <= addressScore) {
            useThisAddress = customerStreetAddress.Address;
            matchWith = orderStreetAddress.Address;
        }
        return retObj = {
            UseAddressId : customerStreetAddress.AddressId,
            UseThisAddress : useThisAddress,
            UseToMatch : matchWith
        };
    }

    function getScore(s1, s2) {
        s1 = s1.toLowerCase();
        s2 = s2.toLowerCase();
        var costs = new Array();
        for (var i = 0; i <= s1.length; i++) {
          var lastValue = i;
          for (var j = 0; j <= s2.length; j++) {
            if (i == 0)
              costs[j] = j;
            else {
              if (j > 0) {
                var newValue = costs[j - 1];
                if (s1.charAt(i - 1) != s2.charAt(j - 1))
                  newValue = Math.min(Math.min(newValue, lastValue),
                    costs[j]) + 1;
                costs[j - 1] = lastValue;
                lastValue = newValue;
              }
            }
          }
          if (i > 0)
            costs[s2.length] = lastValue;
        }
        return costs[s2.length];
    }

    function  loadPriceLevelPanel(customerId, customerName) {
        document.getElementById("mypanel").style.width = "350px";
        appClient.loadPriceLevelPanel(customerId, customerName);
    }

    function loadCustomerAllocation(customerID, customerName, location) {
        document.getElementById("mypanel").style.width = "350px";
        appClient.loadCustomerAllocation(customerID, customerName, location);
    }

    function evaluateFormAction() {
        var btnApprove = document.getElementById('approve');
        if (btnApprove != null) {
            btnApprove.attributes.onclick.value = '';
            btnApprove.addEventListener('click', function() {
                getPriceMismatchReason();
            });
        }
    }

    function getPriceMismatchReason() {
        //load the XML representation of the order and return an array of objects
        //log.debug('getPriceMismatchReason fired...');
        var thisRecord = appClient.getXMLData();
        var fields = [
            'custbody_ola_price_mismatch_reason',
            'custbody_ola_price_mismatch_reasoncode',
            'custbody_ola_price_change_hold'
        ];
        //get the field and the value it is set to by parsing the XML
        var xmlData = appClient.parseXMLData(thisRecord, fields);
        var priceMismatchReason = xmlData[0].custbody_ola_price_mismatch_reason;
        var priceMismatchReasonCode = xmlData[1].custbody_ola_price_mismatch_reasoncode;
        var priceMismatch = xmlData[2].custbody_ola_price_change_hold;
        var id = appClient.getUrlParameter('id', location.href);
        if (priceMismatch == 'T' && (priceMismatchReason === '' || priceMismatchReasonCode === '')) {
            showMessage('WARNING! You have not selected a valid reason for the price mismatch.', 'error');
        }
        else {
            cancel_approve_order(id, 'so', 'approve');
            return true;
        }
    }
    const getTitlPopup = (icon) => {
        return ALERT_TITLE[icon];
    }

    const showSwal = (icon, message) => {
        Swal.fire({
             icon: icon,
             title: getTitlPopup(icon),
             text: message
        });
    }
    
    
    return {
        pageInit                    :   pageInit,
        lineInit                    :   lineInit,
        fieldChanged                :   fieldChanged,
        saveRecord                  :   saveRecord,
        sublistChanged              :   sublistChanged,
        validateLine                :   validateLine,
        displayStatus               :   displayStatus,
        initializeControlAttributes :   initializeControlAttributes,
        matchAddress                :   matchAddress,
        displayPriceWarning         :   displayPriceWarning,
        loadPriceLevelPanel         :   loadPriceLevelPanel,
        loadCustomerAllocation      :   loadCustomerAllocation,
        displayEDIStatus            :   displayEDIStatus
    }
});