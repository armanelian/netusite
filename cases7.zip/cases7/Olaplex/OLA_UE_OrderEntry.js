/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 * 
 * OLA_UE_OrderEntry.js
 * 
 * Version	Date		Author		Remarks
 * 1.00		08/12/2020	eric.barro	Initial deployment
 * 1.10     02/24/2021  eric.barro  Added code to handle customer addresses created by SPS Commerce
 * 1.20     07/13/2021  eric.barro  Added code to make sure taxrate1 on the item line is set to zero when
 *                                  Tax Override is checked
 * 1.30     09/10/2021  eric.barro  Removed unused objects and modules
 * 1.40     03/28/2022  eric.barro  Deployed to Prod as per CM1248
 * 2.00     05/30/2022  eric.barro  Added validation for price level mismatches on order lines
 * 2.10     06/14/2022  eric.barro  Added messaging for Approve button when there is a price mismatch
 * 2.20     06/17/2022  eric.barro  Fixed issue with Address Ref ID from Store GLN in customer address book
 * 2.30     06/27/2022  eric.barro  Fixed Address GLN and Price Mismatch messaging and PO Ack error
 * 3.00     08/25/2022  eric.barro  Added logic to prevent charging tax to B2B Canada Orders with incoterms FCA EXW DAP
 * 4.00     03/27/2023  eric.barro  Added messaging for EDI status from SPS Fulfillment Reports
 * 4.01     06/27/2023  miriam.armada Review Price Validation Logic
 * 4.02     02/01/2024  eric.barro  Added logic to prevent EDI-specific address validation for COMP orders
 * 5.00     08/04/2024  eric.barro  Fixed Tax Code logic
 * 5.10     11/04/2024  esau.o      Validate and update shiptorate when is empty or null
 * 5.20     02/20/2025  esau.o      Init message quantity and case pack line
 * 5.30     02/29/2025  esau.o      Add unlocode based on incoterms
 * 5.40     04/14/2025  esau.o      Added GLN logic for customers
 * 5.50     07/16/2025  eric.barro  Added Tax Inclusive Pricing field from customer and set it on transaction
 * 5.60     07/25/2025  esau.o      Added UNLOCODE null validation
 * 
 */

define(
    [
        'N/runtime',
        'N/record',
        'N/file',
        'N/ui/serverWidget',
        'N/email',
        'N/ui/message',
        'SuiteScripts/Common/OLA_DataObjects',
        'SuiteScripts/Library/OLA_Lib_DateTime',
        'N/currency',
        'N/search',
    ],

    function (runtime, record, file, ui, email, message, appData, appDate, currency, search) {

        const SPS_COMMERCE = '409004';
        var ORDERS_FOLDER = '512050';

        //REVIEW: Cannot improve performance
        /*----start of standard functions for User event scripts-----*/
        function beforeLoad(context) {
            const funcName = '@beforeLoad';
            //log.audit(funcName + ' Type: ' + context.type);
            if (runtime.executionContext == runtime.ContextType.USER_INTERFACE) {
                //REVIEWED
                displayTransactionCurrency(context);
                //REVIEWED
                displayStatusDays(context);
                //REVIEWED
                initializeClient(context);
                //REVIEWED
                initializePopup(context);
                //REVIEWED
                displayQtyCasePackMessage(context);
            }
            var thisRecord = context.newRecord;
            if (thisRecord.getValue('entity') != '') {
                 //REVIEWED
                getCustomerDefaults(context);
            }
        }


        function beforeSubmit(context) {
            //TO DO: Add parameters
            const funcName = '@beforeSubmit';
            const NUORDER_DISCOUNT = '5504';
            const COMP_ORDER = '6';
            const AVATAX_CANADA = '13787';  //Canada Tax Group
            var err = 0;
            if (runtime.envType === 'SANDBOX') {
                ORDERS_FOLDER = '1480004';
            }
            try {
                err = 1;
                log.audit(funcName + ' runtime.executionContext', runtime.executionContext);
                var thisRecord = context.newRecord;
                var mode = context.type;
                var customerDefaults = getCustomerDefaults(context);
                log.audit(funcName + ' customerDefaults', customerDefaults);
                if (runtime.executionContext == runtime.ContextType.USER_INTERFACE) {
                    err = 2;
                    if (thisRecord.getValue('tranid').indexOf('SO') != -1) {
                        getPaymentTerms(context);

                        var fileName = 'SO_' + thisRecord.getValue('id') + '.txt';
                        var fileObj = file.create({
                            name: fileName,
                            fileType: file.Type.PLAINTEXT,
                            contents: JSON.stringify(thisRecord),
                            folder: ORDERS_FOLDER
                        });
                        var fileId = fileObj.save();
                        //log.audit('saved file as ' + fileId + ' filename ' + fileName);
                    }
                    err = 3;
                    //update region dropdown based on shipping country
                    var shippingCountry = thisRecord.getValue('shipcountry');
                    if (shippingCountry) {
                        var region = appData.getShippingCountryRegion(shippingCountry);
                        //log.audit('Region: ' + region);
                        if (region) {
                            err = 4;
                            thisRecord.setValue('custbody_ola_shipping_region', region);
                        }
                    }
                }
                err = 5;
                if (runtime.executionContext == runtime.ContextType.WEBSERVICES ||
                    runtime.executionContext == runtime.ContextType.MAP_REDUCE) {

                    var shippingCountry = thisRecord.getValue('shipcountry');
                    var orderNumber = thisRecord.getValue('tranid');
                    log.audit(funcName + ' shipCountry for tranid ' + orderNumber + ' => ' + shippingCountry);
                    var lineCount = thisRecord.getLineCount('item');
                    log.audit(funcName + ' customer taxcode', customerDefaults.Customer + ' ' + customerDefaults.TaxCode);
                    err = 6;
                    for (var i = 0; i < lineCount; i++) {
                        err = 7;
                        var lineTaxCode = thisRecord.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'taxcode',
                            line: i
                        });
                        if (lineTaxCode === null || lineTaxCode === '' || lineTaxCode === '-7') {
                            if (shippingCountry === 'CA') {
                                log.audit(funcName + ' shipping to ' + shippingCountry + ' for ' + customerDefaults.Customer, 'Updating line ' + i + ' taxcode ' + AVATAX_CANADA);
                                thisRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'taxcode',
                                    value: AVATAX_CANADA,
                                    line: i
                                });
                            }
                            else {
                                log.audit(funcName + ' ' + customerDefaults.Customer, 'Updating line ' + i + ' taxcode ' + customerDefaults.TaxCode);
                                thisRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'taxcode',
                                    value: customerDefaults.TaxCode,
                                    line: i
                                });
                            }
                        }
                        else {
                            //override taxcode if this customer's default taxCode = AVATAX and the order is shipping to Canada
                            if (shippingCountry === 'CA') {
                                log.audit(funcName + ' shipping to ' + shippingCountry + ' for ' + customerDefaults.Customer, 'Updating line ' + i + ' override taxcode ' + AVATAX_CANADA);
                                thisRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'taxcode',
                                    value: AVATAX_CANADA,
                                    line: i
                                });
                            }
                            log.audit(funcName + ' ' + customerDefaults.Customer, 'Line' + i + ' taxcode ' + customerDefaults.TaxCode);
                        }
                    }
                }

                //6 = COM order type for COMP orders
                //log.audit('Is COMP order? Order Type: ' + customerDefaults.OrderType);
                //log.audit('user: ' + runtime.getCurrentUser().name);
                //only run the address validation process if Address File is not Complete (4)
                err = 8;
                if (customerDefaults.OrderType === COMP_ORDER) {
                    log.audit('COMP Order, skipping EDI address validation...');
                }
                else {
                    err = 9;
                    //log.audit('user: ' + runtime.getCurrentUser().name);
                    //only run the address validation process if Address File is not Complete (4)

                    /*----------------start of EDI-specific address validation code------------------*/
                    if (customerDefaults && customerDefaults.AddressFileComplete !== '4' && customerDefaults.AddressFileComplete !== '109' && customerDefaults.AddressFileComplete !== '5') {
                        if ((runtime.executionContext == runtime.ContextType.WEBSERVICES && customerDefaults.EDICapable) ||
                            (runtime.executionContext == runtime.ContextType.USER_INTERFACE && customerDefaults.EDICapable)) {
                            err = 10;
                            var shipaddresslist = 0;
                            //unlocode step
                            var destinationUnlocode = "";
                            var orderNumber = thisRecord.getValue('tranid');

                            var customerId = thisRecord.getValue('entity');
                            var orderAddress = getOrderAddress(thisRecord);
                            //return an array of existing customer addresses to be used for comparison
                            var customerAddresses = getCustomerAddresses(customerId);
                            var addressesToCompare = compareAddresses(customerAddresses, orderAddress);

                            log.audit('stepping through address validation...');
                            const addressObj = {
                                OrderAddress: orderAddress,
                                CustomerAddress: customerAddresses,
                                AddressToCompare: addressesToCompare
                            }
                            log.audit('addressObj', addressObj);
                            err = 11;
                            //log.audit('addressToCompare', addressesToCompare);
                            if (addressesToCompare.length > 0) {
                                shipaddresslist = addressesToCompare[0].UseAddressId;
                                if (shipaddresslist > 0) {
                                    //log.audit('****setting shipaddresslist value', shipaddresslist);
                                    thisRecord.setValue('shipaddresslist', shipaddresslist);
                                }
                                //unlocode step
                                destinationUnlocode = addressesToCompare[0].CustomerAddressUnlocode;
                                if (destinationUnlocode) {
                                    thisRecord.setValue("custbody_ola_dest_unlocode", destinationUnlocode);
                                }
                                var msg = 'Ship Address: <b>' +
                                    addressesToCompare[0].UseToMatch +
                                    '</b><br/>Possible Match: <b>' +
                                    addressesToCompare[0].UseAddressId + '-' +
                                    addressesToCompare[0].UseThisAddress +
                                    '</b><br/>Percentage Match: <b>' + addressesToCompare[0].PercentageMatch + '</b>';
                                //sendNotification(msg, 'Address match for order ' + salesOrderNumber);
                            }
                            else {
                                err = 12;
                                shipaddresslist = addCustomerAddress(customerId, orderAddress[0]);
                                if (shipaddresslist > 0) {
                                    thisRecord.setValue('shipaddresslist', shipaddresslist);
                                }
                                var msg = 'Ship Address: <b>' +
                                    orderAddress[0].Address +
                                    '</b><br/><b>No Customer Addresses Match.</b>';
                                sendNotification(msg, 'Address mismatch for order ' + orderNumber);
                            }
                        }
                        if (shipaddresslist > 0) {
                            //log.audit('****setting shipaddr_id value', shipaddresslist);
                            thisRecord.setValue('custbody_ola_xtn_shipaddr_id', shipaddresslist);
                        }
                    }
                    else {
                        var shipaddresslist = thisRecord.getValue('shipaddresslist');
                        thisRecord.setValue('custbody_ola_xtn_shipaddr_id', shipaddresslist);
                    }
                }
                var today = new Date();
                //log.audit(funcName + ' Month:', Number(today.getMonth()) + 1);
                err = 13;
                if (runtime.executionContext == runtime.ContextType.USER_INTERFACE ||
                    runtime.executionContext == runtime.ContextType.WEBSERVICES) {
                    validatePriceLevels(thisRecord, customerDefaults);
                }
                //code to handle nuorder discount rate since the native NS fields are not working
                //with REST webservices. nuorder needs to pass it via the custom body field
                //so we have to use the UE to populate the native fields
                err = 14;
                if (runtime.executionContext == runtime.ContextType.REST_WEBSERVICES) {
                    var nuOrderDiscountRate = thisRecord.getValue('custbody_ola_nuorder_discount_rate');
                    log.audit('NuOrder Discount Rate', nuOrderDiscountRate);
                    if (nuOrderDiscountRate !== '') {
                        err = 15;
                        thisRecord.setValue('discountitem', NUORDER_DISCOUNT);
                        if (nuOrderDiscountRate.indexOf('%') !== -1) {
                            thisRecord.setText('discountrate', '-' + nuOrderDiscountRate);
                        }
                        else {
                            thisRecord.setValue('discountrate', -1 * Number(nuOrderDiscountRate));
                        }
                    }
                }
                else {
                    err = 16;
                    if (runtime.executionContext == runtime.ContextType.USER_INTERFACE) {
                        var dRate = thisRecord.getValue('discountrate');
                        var discountRate = thisRecord.getText('discountrate');
                        log.audit('dRate ' + dRate, 'discountRate ' + discountRate);
                        var nuOrderDiscountRate = thisRecord.getValue('custbody_ola_nuorder_discount_rate');
                        //log.audit(discountRate + ' vs ' + nuOrderDiscountRate);
                        if (discountRate !== nuOrderDiscountRate) {
                            thisRecord.setValue('custbody_ola_nuorder_discount_rate', discountRate.replace('-', ''));
                        }
                    }
                }
                // ND-1344 set the unlocode based on incoterms
                log.audit("runtime.executionContext", runtime.executionContext);

                if (
                    [
                        runtime.ContextType.USER_INTERFACE,
                        runtime.ContextType.REST_WEBSERVICES,
                        runtime.ContextType.CSV_IMPORT,
                        runtime.ContextType.MAP_REDUCE,
                        runtime.ContextType.RESTLET,
                        runtime.ContextType.SCHEDULED,
                        runtime.ContextType.SUITELET,
                        runtime.ContextType.USEREVENT,
                        runtime.ContextType.WEBSERVICES,
                    ].indexOf(runtime.executionContext) != -1
                ) {
                    var incotermsValue = thisRecord.getValue("custbody_incoterms");
                    var transactionUnlocodeSource = null;
                    var incotermsReverseLookup = {
                        1: "DDP",
                        3: "DAP",
                        4: "EXW",
                        5: "DDU",
                        6: "FCA",
                        7: "FOB",
                        8: "PPD",
                        9: "CPU",
                        10: "CPT",
                        11: "CIF",
                        12: "CFR",
                    };
                    log.audit("incotermsReverseLookup[incotermsValue], incotermsValue", [
                        incotermsReverseLookup[incotermsValue],
                        incotermsValue,
                    ]);

                    // set the transaction unlocode source field ID based on the incoterms value
                    switch (incotermsReverseLookup[incotermsValue]) {
                        case "FCA":
                        case "EXW":
                        case "CPU":
                            transactionUnlocodeSource = "custbody_ola_origin_unlocode";
                            break;
                        case "DDP":
                        case "DDU":
                        case "PPD":
                            transactionUnlocodeSource = "custbody_ola_dest_unlocode";
                            break;
                        case "DAP":
                        case "CFR":
                        case "CIF":
                        case "CPT":
                            transactionUnlocodeSource = "custbody_ola_pod_unlocode";
                            break;
                        case "FOB":
                            transactionUnlocodeSource = "custbody_ola_pol_unlocode";
                            break;
                    }

                    var shipToAddressSubRecord = thisRecord.getSubrecord({
                        fieldId: 'shippingaddress'
                    });
                    var shipToAddressUnlocode = shipToAddressSubRecord.getValue('custrecord_ola_unlocode');
                    log.audit('shipToAddressUnlocode', shipToAddressUnlocode);

                    var existingValue = thisRecord.getValue("custbody_ola_dest_unlocode");

                    if (!existingValue) {
                        thisRecord.setValue("custbody_ola_dest_unlocode", shipToAddressUnlocode);
                    } else {
                        log.audit("Existing Value", existingValue);
                    }

                    var locationUnlocodeFields = search.lookupFields({
                        type: search.Type.LOCATION,
                        id: thisRecord.getValue('location'),
                        columns: 'custrecord_ola_loc_unlocode'
                    });

                    log.audit('transactionUnlocodeSource, locationUnlocodeFields', [transactionUnlocodeSource, locationUnlocodeFields]);
                    // false is in these two blocks because they may be unnecessary, tbd
                    if (locationUnlocodeFields && locationUnlocodeFields['custrecord_ola_loc_unlocode']) {
                        thisRecord.setValue('custbody_ola_origin_unlocode', locationUnlocodeFields['custrecord_ola_loc_unlocode'])
                    }

                   //var transactionUnlocodeValue = thisRecord.getValue(transactionUnlocodeSource) || transactionUnlocodeSource;
                   var transactionUnlocodeValue = thisRecord.getValue(transactionUnlocodeSource);
                   log.audit("transactionUnlocodeSource, transactionUnlocodeValue", [
                       transactionUnlocodeSource,
                       transactionUnlocodeValue,
                   ]);
                   if(transactionUnlocodeValue){
                       thisRecord.setValue("custbody_ola_trx_unlocode", transactionUnlocodeValue);
                   }
                    //GLN logic
                    var customerId = thisRecord.getValue('entity');
                    var SPSAddressGLN = thisRecord.getValue('custbody_ola_sps_add_gln')
                    if (customerDefaults.CustomerGLN) {
                        var addressId = appData.getAddressGLNGeneral(customerId, SPSAddressGLN);
                        if (addressId) {
                            var customerAddresses = getCustomerAddresses(customerId);
                            log.audit('customerAddresses', customerAddresses)
                            var addressbook = customerAddresses.find(e => e.AddressBookId == addressId)
                            if (addressbook) {
                                thisRecord.setValue('shipaddresslist', addressbook.AddressId);
                            }
                        } else {
                            thisRecord.setValue('custbody_ola_shipping_notes', 'No GLN address founded');
                        }
                    }
                }
                if (mode == "create") {
                    updateShipToRate(thisRecord);
                } else if (mode == "edit") {
                    if (isNullOrEmpty(thisRecord.getValue('custbody_ola_shipto_exchangerate'))) {
                        updateShipToRate(thisRecord);
                    }
                }
            }
            catch (ex) {
                log.error(funcName + ': Error: @err=' + err + ' ' + ex.message);
            }
        }

        function afterSubmit(context) {
            const funcName = '@afterSubmit';
            const AVATAX = 615;
            const AVATAX_CANADA = '13787';  //Canada Tax Group
            const NOTAX = -7;
            const AVATAX_GST = '13785';
            const AVATAX_PST = '13786';
            const CANADA_COMP = '18755';
            var taxCode = AVATAX;
            var err = 0;
            try {
                var currRec = context.newRecord;
                log.audit('afterSubmit triggered...');
                if (runtime.executionContext == runtime.ContextType.USER_INTERFACE ||
                    runtime.executionContext == runtime.ContextType.WEBSERVICES) {
                    err = 1;
                    var currRecId = currRec.getValue({ fieldId: 'id' });
                    var currType = currRec.getValue({ fieldId: 'type' });
                    err = 2;
                    var customerDefaults = getCustomerDefaults(context);
                    var today = new Date();
                    err = 3;
                    validatePriceLevels(currRec, customerDefaults);

                    //log.audit('currType', currType);
                    if (currRecId != '' && currType == 'salesord') {
                        log.audit('Loading sales order ' + currRecId);
                        var thisRecord = record.load({
                            type: 'salesorder',
                            id: currRecId,
                        });
                        //put all UI processing here
                        err = 4;
                        var shippingCountry = thisRecord.getValue('shipcountry');
                        var orderNumber = thisRecord.getValue('tranid');
                        //only process if tax code is not Not Taxable
                        log.audit(funcName + ' salesOrder taxCode = ' + taxCode + ' ' + orderNumber);
                        if (taxCode !== NOTAX) {    //was -8
                            var overRideTax = thisRecord.getValue('custbody_ava_taxoverride');
                            var lineCount = thisRecord.getLineCount('item');
                            var totalPallets = 0;
                            if (overRideTax) {
                                //get total amount
                                err = 5;
                                var totalAmount = parseFloat(thisRecord.getValue('total'));
                                err = 6;
                                var taxTotal = parseFloat(thisRecord.getValue('taxtotal'));
                                err = 7;
                                var newTotal = parseFloat(totalAmount) - parseFloat(taxTotal);
                                err = 8;
                                thisRecord.setValue('taxtotal', 0);
                                thisRecord.setValue('taxamountoverride', 0);
                                thisRecord.setValue('subtotal', newTotal.toFixed(2));
                                thisRecord.setValue('total', newTotal.toFixed(2));
                                thisRecord.setValue('custbody_ava_taxinclude', false);
                                thisRecord.setValue('custpage_ava_deftax', '-Not Taxable-');

                                var pallets = 0;

                                for (var i = 0; i < lineCount; i++) {
                                    var lineTaxCode = thisRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'taxcode',
                                        line: i
                                    });
                                    if (lineTaxCode === null || lineTaxCode === '') {
                                        log.audit(funcName + ' taxoverride ' + customerDefaults.Customer, 'Updating line ' + i + ' taxcode ' + customerDefaults.TaxCode);
                                        thisRecord.setSublistValue({
                                            sublistId: 'item',
                                            fieldId: 'taxcode',
                                            value: customerDefaults.TaxCode,    //AVATAX, //was '-7', changed to AVATAX
                                            line: i
                                        });
                                        thisRecord.setSublistValue({
                                            sublistId: 'item',
                                            fieldId: 'taxrate1',
                                            value: 0,
                                            line: i
                                        });
                                    }

                                    if (Number(pallets) === 0) {
                                        var palletsCalculated = calculatePallets(i, thisRecord);
                                        totalPallets += palletsCalculated;
                                    }
                                    err = 9;
                                }
                                if (Number(totalPallets) > 0) {
                                    thisRecord.setValue('custbody_ola_pallet_total', totalPallets.toFixed(2));
                                }
                            }
                            else {
                                err = 10;
                                thisRecord.setValue('custpage_ava_document', true);
                                thisRecord.setValue('custpage_ava_taxcodestatus', '1');
                                thisRecord.setValue('custbody_ava_suspendtaxcall', false);
                                //if (Number(pallets) === 0) {
                                err = 11;
                                for (var i = 0; i < lineCount; i++) {
                                    var palletsCalculated = calculatePallets(i, thisRecord);
                                    totalPallets += palletsCalculated;
                                    var lineTaxCode = thisRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'taxcode',
                                        line: i
                                    });
                                    if (lineTaxCode === null || lineTaxCode === '') {
                                        if (shippingCountry === 'CA') {
                                            log.audit(funcName + ' shipping to ' + shippingCountry + ' for ' + customerDefaults.Customer, 'Updating line ' + i + ' taxcode ' + AVATAX_CANADA);
                                            thisRecord.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'taxcode',
                                                value: AVATAX_CANADA,
                                                line: i
                                            });
                                        }
                                        else {
                                            log.audit(funcName + ' ' + customerDefaults.Customer, 'Updating line ' + i + ' taxcode ' + customerDefaults.TaxCode);
                                            thisRecord.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'taxcode',
                                                value: customerDefaults.TaxCode,
                                                line: i
                                            });
                                        }
                                    }
                                }
                                thisRecord.setValue('custbody_ola_pallet_total', totalPallets.toFixed(2));
                            }
                            thisRecord.save();
                        }
                        else {
                            err = 12;
                            var todaysDate = new Date();
                            var startDate = new Date('08/29/2022');
                            startDate.setHours(0, 0, 0, 0);
                            if (todaysDate < startDate) {
                                //DO NOT EXECUTE CODE BELOW before 8/29/2022
                                //log.audit('Order Date before Start Date', 'Order Date: ' + orderDate + ' Start Date: ' + startDate);
                                return;
                            }
                            else {
                                err = 13;
                                //check if B2B order and country = CA and incoterms is FCA, EXW, DAP
                                var shippingCountry = thisRecord.getValue('shipcountry');
                                var incoTerms = thisRecord.getValue('custbody_incoterms');
                                var orderType = customerDefaults.OrderType;
                                var incoterms = [
                                    '3',    //DAP
                                    '4',    //EXW
                                    '6'     //FCA
                                ];
                                //don't charge tax if the following conditions exist
                                //17 = Canada
                                if (orderType !== '1' && incoterms.indexOf(incoTerms) !== -1 && (shippingCountry === '17' || shippingCountry === 'CA')) {
                                    err = 14;
                                    var totalAmount = parseFloat(thisRecord.getValue('total'));
                                    var taxTotal = parseFloat(thisRecord.getValue('taxtotal'));
                                    var newTotal = parseFloat(totalAmount) - parseFloat(taxTotal);

                                    thisRecord.setValue('taxtotal', 0);
                                    thisRecord.setValue('taxamountoverride', 0);
                                    thisRecord.setValue('subtotal', newTotal.toFixed(2));
                                    thisRecord.setValue('total', newTotal.toFixed(2));
                                    thisRecord.setValue('custbody_ava_taxinclude', false);
                                    thisRecord.setValue('custpage_ava_deftax', '-Not Taxable-');
                                }

                                var lineCount = thisRecord.getLineCount('item');
                                err = 15;
                                for (var i = 0; i < lineCount; i++) {
                                    var lineTaxCode = thisRecord.getSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'taxcode',
                                        line: i
                                    });
                                    if (lineTaxCode === null || lineTaxCode === '') {
                                        if (shippingCountry === 'CA') {
                                            log.audit(funcName + ' shipping to ' + shippingCountry + ' for ' + customerDefaults.Customer, 'Updating line ' + i + ' taxcode ' + AVATAX_CANADA);
                                            thisRecord.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'taxcode',
                                                value: AVATAX_CANADA,
                                                line: i
                                            });
                                        }
                                        else {
                                            log.audit(funcName + ' ' + customerDefaults.Customer, 'Updating line ' + i + ' taxcode ' + customerDefaults.TaxCode);
                                            thisRecord.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'taxcode',
                                                value: customerDefaults.TaxCode,
                                                line: i
                                            });
                                            thisRecord.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'taxrate1',
                                                value: 0,
                                                line: i
                                            });
                                        }
                                    }
                                    else {
                                        if (shippingCountry === 'CA') {
                                            log.audit(funcName + ' shipping to ' + shippingCountry + ' for ' + customerDefaults.Customer, 'Updating line ' + i + ' override taxcode ' + AVATAX_CANADA);
                                            thisRecord.setSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'taxcode',
                                                value: AVATAX_CANADA,
                                                line: i
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //log.audit(funcName + ' Trace err=' + err);
            }
            catch (ex) {
                log.error(funcName + ' @' + err, ex)
            }
        }

        //REVIEW: OK
        /*----start of custom functions for Olaplex User event scripts-----*/
        function getCustomerDefaults(context) {
            const funcName = '@getCustomerDefaults';
            try {
                var thisRecord = context.newRecord;
                var customerId = thisRecord.getValue('entity');
                if (customerId != "") {
                    var customerData = getCustomerData(customerId);

                    var transactionClass = thisRecord.getValue('class');
                    var transactionLocation = thisRecord.getValue('location');
                    //log.audit('*******transactionLocation', transactionLocation);
                    if (transactionLocation === null) {
                        log.audit(runtime.executionContext, runtime.getCurrentUser() + ' transactionLocation is NULL');
                    }
                    var incoterms = thisRecord.getValue('custbody_incoterms');
                    var vatOverride = thisRecord.getValue('custbody_ava_taxoverride');
                    var emailAddress = thisRecord.getValue('custbody_ola_shipping_email');
                    //log.audit('emailAddress', emailAddress);
                    var customerVASCodes = thisRecord.getValue('custbody_ola_vas_activity_code');
                    var pickTicketSuffix = thisRecord.getValue('custbody_ola_pickticket_suffix');
                    //auto-populate the class and location fields on the cash sales/sales order forms
                    if (Object.keys(customerData).length > 0) {
                        //check first if there are values before updating
                        if (customerData.DefaultClass !== '' && transactionClass === '') {
                            thisRecord.setText('class', customerData.DefaultClassText);
                        }
                        if (customerData.DefaultLocation !== '' && (transactionLocation === '' || transactionLocation == null)) {
                            thisRecord.setValue('location', customerData.DefaultLocation);
                        }
                        if (thisRecord.getValue('tranid').indexOf('CS') === -1) {
                            if (customerData.IncoTerms !== '' && incoterms === '') {
                                thisRecord.setValue('custbody_incoterms', customerData.IncoTerms);
                            }
                            if (customerData.EmailAddress !== '' && emailAddress === '') {
                                thisRecord.setValue('custbody_ola_shipping_email', customerData.EmailAddress);
                            }
                        }
                        if (customerData.VATOverride) {
                            thisRecord.setValue('custbody_ava_taxoverride', true);
                        }
                        if (customerData.VASCodes.length > 0 && customerData.VASCodes != undefined) {
                            //VAS Activity Codes are multi-select separated by a delimiter
                            var vCodes = '';
                            //loop through the multi-select field
                            for (var i = 0; i < customerData.VASCodes.length; i++) {
                                var vCode = customerData.VASCodes[i];
                                vCodes += vCode + '\u0005';
                            }
                            //log.audit('VASCodes', vCodes);
                            //update the field with the delimited string values from the array
                            if (customerVASCodes === '') {
                                thisRecord.setValue('custbody_ola_vas_activity_code', vCodes);
                            }
                        }
                        if (pickTicketSuffix === '') {
                            thisRecord.setValue('custbody_ola_pickticket_suffix', customerData.OrderType);
                        }
                        if (customerData.DeptLookup == true) {
                            var storeGLN = thisRecord.getValue('custbody_sps_department');
                            if (storeGLN === '' || storeGLN === null) {
                                storeGLN = thisRecord.getValue('custbody_sps_bt_addresslocationnumber');
                            }
                            var addressId = appData.getAddressGLN(customerId, storeGLN);
                            thisRecord.setValue('custbody_ola_cust_department', addressId);
                        }
                        var carrier = thisRecord.getValue('custbody_ola_ship_freight_carrier');
                        if (carrier == '' && customerData.FreightCarrier !== '') {
                            thisRecord.setValue('custbody_ola_ship_freight_carrier', customerData.FreightCarrier);
                        }
                        //set this field based on the customer setting for Tax Inclusive Pricing
                        thisRecord.setValue('custbody_ava_taxinclude', customerData.TaxInclusivePricing);
                        thisRecord.setValue('custbody_ava_shippingtaxinclude', customerData.TaxInclusivePricing);
                    }
                }
            }
            catch (ex) {
                log.error(funcName, ex);
            }
            return customerData;
        }

        //get customer information by loading the record
        function getCustomerData(customerid) {
            const funcName = '@getCustomerData';
            try {
                var data = {};
                var rec = record.load({
                    type: 'customer',
                    id: customerid
                });
                if (rec) {
                    var itemPricingCount = rec.getLineCount({
                        sublistId: 'itempricing'
                    });
                    var itemPricing = [];
                    for (var i = 0; i < itemPricingCount; i++) {
                        var item = rec.getSublistValue({
                            sublistId: 'itempricing',
                            fieldId: 'item',
                            line: i
                        });
                        var price = rec.getSublistValue({
                            sublistId: 'itempricing',
                            fieldId: 'price',
                            line: i
                        });
                        itemPricing.push({
                            ItemID: item,
                            ItemPrice: price
                        });
                    }
                    data = {
                        CustomerID: customerid,
                        Customer: rec.getValue('entityid'),
                        DefaultClass: rec.getValue('custentity_ola_default_class'),
                        DefaultClassText: rec.getText('custentity_ola_default_class'),
                        DefaultLocation: rec.getValue('custentity_ola_default_fulfill_location'),
                        IncoTerms: rec.getValue('custentity_ola_incoterms'),
                        VASCodes: rec.getValue('custentity_ola_cust_vas_code'),
                        OrderType: rec.getValue('custentity_ola_cust_order_type'),
                        EmailAddress: rec.getText('email'),
                        ConfEmailAddress: rec.getText('custentity_add_if_email') || 'ediorders@olaplex.com',
                        VATOverride: rec.getValue('custentity_ola_vat_tax_override'),
                        EDICapable: rec.getValue('custentity_ola_edi_capable'),
                        AddressFileComplete: rec.getValue('custentity_ola_address_file'),
                        DeptLookup: rec.getValue('custentity_ola_cust_dept_lookup'),
                        PriceLevel: rec.getValue('pricelevel'),
                        FreightCarrier: rec.getValue('custentity_ola_def_freight_carrier'),
                        TaxCode: rec.getValue('taxitem'),
                        ItemPricing: itemPricing,
                        CustomerGLN: rec.getValue('custentity_ola_customer_gln'),
                        TaxInclusivePricing: rec.getValue('custentity_ola_tax_inclusive_pricing')
                    }
                }
                //log.audit(funcName + ' customer defaults', data);
                return data;
            }
            catch (ex) {
                log.error(funcName, ex);
            }
        }

        //using the customerid and the sales order address text created by SPS
        //compare addressText with address from the customer address book
        function getCustomerAddress(customerId, addressText) {
            const funcName = '@getCustomerAddress';
            try {
                var addressId = 0;
                if (customerId != '') {
                    var custObj = record.load({
                        type: record.Type.CUSTOMER,
                        id: customerId
                    })
                    var addressLineCount = custObj.getLineCount('addressbook');
                    if (addressLineCount > 0) {
                        //loop through address book and compare each one to the location address
                        //which should be in the address book for each vendor
                        for (var i = 0; i < addressLineCount; i++) {
                            custObj.selectLine({
                                sublistId: 'addressbook',
                                line: i
                            });
                            var customerAddressText = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'addressbookaddress_text',
                                line: i
                            });
                            //need to remove all extra hidden characters and convert to spaces
                            //and then replace all spaces with commas before comparing
                            if (customerAddressText.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, ",") === addressText.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, ",")) {
                                //log.audit('Address matched', addressText);
                                addressId = custObj.getCurrentSublistValue({
                                    sublistId: 'addressbook',
                                    fieldId: 'addressid',
                                    line: i
                                });
                                break;
                            }
                        }
                    }
                    //log.audit('addressId ' + addressId, addressText);
                }
            }
            catch (ex) {
                log.error(funcName, ex);
            }
            return addressId;
        }

        function addCustomerAddress(customerId, address) {
            const funcName = '@addCustomerAddress';
            try {
                var addressId = 0;
                var customer = record.load({
                    type: 'customer',
                    id: customerId,
                    isDynamic: true
                });
                customer.selectNewLine({
                    sublistId: 'addressbook'
                });
                var addrObj = customer.getCurrentSublistSubrecord({
                    sublistId: 'addressbook',
                    fieldId: 'addressbookaddress'
                });

                //log.audit('Country', address.Country);
                //set subrecord fields
                addrObj.setValue('country', address.Country); //Country must be set before setting the other address fields
                addrObj.setValue('attention', address.Customer);
                addrObj.setValue('addressee', address.Addressee);
                addrObj.setValue('addrphone', '');
                addrObj.setValue('addr1', address.Street);
                addrObj.setValue('addr2', address.Address2);
                addrObj.setValue('city', address.City);
                // if the address is not in U.S., Canada, or Australia, use
                // state instead of dropdownstate. For example,
                // subrecord.setFieldValue('state', 'BY');
                // for Bavaria, Germany
                if (address.Country == 'US' || address.Country == 'CA' || address.Country == 'AU') {
                    addrObj.setValue('dropdownstate', address.State);
                }
                else {
                    addrObj.setValue('state', address.State);
                }
                addrObj.setValue('zip', address.Zip);
                addrObj.setValue('label', address.Addressee != '' ? address.Addressee : address.Street);
                //commit line item
                customer.commitLine('addressbook');
                var addressLineId = customer.save(
                    { ignoreMandatoryFields: true }
                );
                //log.audit('addressLineId', addressLineId);
                //check if we saved the address record
                if (addressLineId > 0) {
                    //reload the customer record
                    var customer = record.load({
                        type: 'customer',
                        id: customerId,
                        isDynamic: true
                    });
                    var lineCount = customer.getLineCount('addressbook');
                    if (lineCount > 0) {
                        //get the address id of the last address record
                        addressId = customer.getSublistValue({
                            sublistId: 'addressbook',
                            fieldId: 'addressid',
                            line: lineCount - 1
                        });
                        //log.audit('addressId', addressId);
                    }
                }
            }
            catch (ex) {
                log.error(funcName, ex);
            }
            return addressId;
        }

        //REVIEW: OK
        function calculatePallets(i, thisRecord) {
            const funcName = '@PalletCalculator';
            try {
                var qty = thisRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantity',
                    line: i
                });
                var unitsPallet = thisRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ola_qty_per_pallet',
                    line: i
                });

                if (Number(unitsPallet) > 0) {
                    var palletsLine = qty / unitsPallet;
                    //log.audit('pallets line' + i, palletsLine);
                    thisRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ola_pallets_line',
                        value: palletsLine.toFixed(2),
                        line: i
                    });
                }
                else {
                    palletsLine = 0;
                }
            }
            catch (ex) {
                log.error(funcName, ex);
            }
            return palletsLine;
        }

        //REVIEW: OK
        function displayStatusDays(context) {
            var currentForm = context.form;
            var thisRecord = context.newRecord;

            var msgField = currentForm.addField({
                id: 'custpage_msg',
                type: ui.FieldType.INLINEHTML,
                label: 'Days Pending'
            });

            var today = appDate.getToday();
            var orderDate = thisRecord.getValue('trandate');
            var daysPending = getDaysBetweenDates(new Date(orderDate), new Date(today));
            //log.audit('daysPending ' + daysPending);
            if (daysPending != NaN) {
                //call the client side function to display the status
                var jsScript = "<script>jQuery(function($){ ";
                jsScript += "require(['SuiteScripts/Orders/OLA_CS_OrderEntry.js'], ";
                jsScript += "function(mod) { mod.initializeControlAttributes; mod.displayStatus('" + daysPending + "');});});</script>";
                msgField.defaultValue = jsScript;
            }

            if (thisRecord.getValue('custbody_ola_price_change_hold')) {
                var warningField = context.form.addField({
                    id: 'custpage_warning_field',
                    type: 'INLINEHTML',
                    label: 'Script'
                });
                var jsScript = "<script>jQuery(function($){ ";
                jsScript += "require(['SuiteScripts/Orders/OLA_CS_OrderEntry.js'], ";
                jsScript += "function(mod) { mod.displayPriceWarning();});});</script>";
                warningField.defaultValue = jsScript;
            }

            var ediStatus = thisRecord.getValue('custbody_ola_edi_processing_status');
            //log.audit(ediStatus);
            if (ediStatus.indexOf('Error') !== -1) {
                var ediField = context.form.addField({
                    id: 'custpage_edi_field',
                    type: 'INLINEHTML',
                    label: 'Script'
                });
                var jsScript = "<script>jQuery(function($){ ";
                jsScript += "require(['SuiteScripts/Orders/OLA_CS_OrderEntry.js'], ";
                jsScript += "function(mod) { mod.displayEDIStatus('" + ediStatus + "');});});</script>";
                ediField.defaultValue = jsScript;
            }
        }

        function getPaymentTerms(context) {
            /* payment terms to check 
                8 - PIA - Payment in Advance
                16 - Letter of Credit
                17 - 30% Prepayment, 70% LC
                13 - 50% PIA, 50% net 30
            */
            var paymentTerms = [
                '8', '13', '16', '17'
            ];
            var thisRecord = context.newRecord;
            var customerTerms = thisRecord.getValue('terms');
            var orderNumber = thisRecord.getValue('tranid');
            var orderStatus = thisRecord.getValue('orderstatus');

            //check if terms is in the array list and if status is Pending Approval
            if (paymentTerms.indexOf(customerTerms) != -1 && orderStatus == 'A') {
                //log.audit('customer terms ' + customerTerms + ' - ' + orderNumber + '->' + orderStatus);
                thisRecord.setValue('custbody_ola_order_pendinghold', true);
            }
        }

        //Exceptions - function will exit
        //Order Date before 7/1/2022
        //Customer has custom item pricing

        function validatePriceLevels(thisRecord, customerData) {
            const funcName = '@validatePriceLevels';
            try {
                //check if the transaction date is before 7/1/2022
                var orderDate = new Date(thisRecord.getValue('trandate'));
                var startDate = new Date('07/01/2022');
                startDate.setHours(0, 0, 0, 0);
                if (orderDate < startDate) {
                    //DO NOT PROCESS orders before 7/1/2022
                    //log.audit('Order Date before Start Date', 'Order Date: ' + orderDate + ' Start Date: ' + startDate);
                    return;
                }
                //check first if customer has custom item pricing
                //NOTE: first element is for Dummy Item
                //so we need to check for more than 1 element
                if (customerData !== undefined &&
                    customerData.hasOwnProperty('ItemPricing') &&
                    customerData.ItemPricing.length > 1) {
                    //status quo no need to do anything!
                    //log.audit('thisRecord is status quo', thisRecord);
                    log.audit('thisRecord status quo: EDI? ' + customerData.EDICapable);
                    return;
                }
                log.audit('thisRecord EDI? ' + customerData.EDICapable);
                var createdBy = thisRecord.getValue('recordcreatedby');
                var lineCount = thisRecord.getLineCount('item');
                var priceFailcount = 0;
                var discountItem = thisRecord.getValue('discountitem');

                // check order level parameters for mismatch

                if (discountItem !== '' && discountItem !== null) {
                    thisRecord.setValue('custbody_ola_price_mismatch_reasoncode', 5); //Discount
                    thisRecord.setValue('custbody_ola_price_mismatch_reason', runtime.getCurrentUser().name + ': Discount Applied');
                    priceFailcount++
                }
                // review lines mismatch validation

                for (var i = 0; i < lineCount; i++) {
                    var priceLevel = thisRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'price',
                        line: i
                    });
                    var itemPrice = thisRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'rate',
                        line: i
                    });
                    var customerPrice = thisRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_sps_purchaseprice',
                        line: i
                    });
                    //if not created by SPS Commerce the customerPrice will be blank
                    //set it to be the same as itemPrice
                    //so that it will pass the validation logic
                    if (createdBy !== SPS_COMMERCE) {
                        customerPrice = itemPrice;
                    }
                    //log.audit('******price check', priceLevel + ' ? ' + customerData.PriceLevel);
                    //if this is an EDI order ignore price level check
                    //if (customerData.EDICapable == false) {
                    if (createdBy !== SPS_COMMERCE) {
                        if (customerPrice + 'x' !== 'x' && (priceLevel !== customerData.PriceLevel ||
                            Number(itemPrice) !== Number(customerPrice))) {
                            thisRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ola_price_mismatch',
                                value: true,
                                line: i
                            });
                            priceFailcount++;

                            // thisRecord.setValue('custbody_ola_price_change_hold', true);
                            //thisRecord.setValue('custbody_ola_has_discrepancy', true);
                            //check if discount has been applied and automatically select the reason code
                            //for the price mismatch
                            // 6/16 removed line level set values, add pricefail count, to be evaluated at the end of the line leve evaluation
                        }
                        else {
                            thisRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ola_price_mismatch',
                                value: false,
                                line: i
                            });
                            //thisRecord.setValue('custbody_ola_price_change_hold', false);
                            //thisRecord.setValue('custbody_ola_has_discrepancy', false);
                        }

                        if (Number(itemPrice) !== Number(customerPrice)) {
                            //if the price is different, set the price to the customer price using the price level
                            //check if the customerPrice is not null or blank
                            if (customerPrice !== '' && customerPrice !== null) {
                                thisRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'price',
                                    value: -1,
                                    line: i
                                });
                                // thisRecord.setValue('custbody_ola_price_change_hold', true);
                                priceFailcount++;
                            }
                            else {
                                log.audit('priceLevel', priceLevel);
                                //if price level was set by user to custom, do not override
                                if (priceLevel === '-1') {
                                    //set the price change hold to true
                                    //thisRecord.setValue('custbody_ola_price_change_hold', true);
                                    thisRecord.setSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'custcol_ola_price_mismatch',
                                        value: true,
                                        line: i
                                    });
                                    priceFailcount++;
                                    return;
                                }
                                thisRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'price',
                                    value: customerData.PriceLevel,
                                    line: i
                                });
                            }
                        }
                    }
                    else {
                        //if this is an EDI order we can only rely on checking
                        //the inbound price (trading partner price) matches the item price on the 
                        //price level set for the EDI customer
                        log.audit(itemPrice + " trading partner price " + customerPrice);
                        ediPrice = parseFloat(customerPrice);
                        //log.audit(ediPrice);

                        soRate = parseFloat(itemPrice);
                        //log.audit(soRate);

                        if (ediPrice == soRate) {
                            thisRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ola_price_mismatch',
                                value: false,
                                line: i
                            });
                        }
                        if (ediPrice != soRate) {
                            //if the price is different, mark this order as having a price mismatch
                            thisRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ola_price_mismatch',
                                value: true,
                                line: i
                            });
                            priceFailcount++;
                        }
                    }
                }
                //log.audit(priceFailcount);
                if (priceFailcount > 0) {
                    thisRecord.setValue('custbody_ola_price_change_hold', true);
                }
                else {
                    thisRecord.setValue('custbody_ola_price_change_hold', false);
                }
            }
            catch (ex) {
                log.error(funcName, ex);
            }
        }

        //REVIEW: OK
        function initializeClient(context) {
            var thisRecord = context.newRecord;
            //log.audit(context.type);
            if (context.type !== context.UserEventType.CREATE) {
                var location = thisRecord.getValue('location');
                var customerId = thisRecord.getValue('entity');
                var customerName = thisRecord.getText('entity');
            }

            //log.audit(customerId + ' - ' + customerName);
            var itemSublist = context.form.getSublist('item');
            if (itemSublist !== null) {
                var btnLoadPriceLevels = itemSublist.addButton({
                    id: 'custpage_btn_load_pricelevels',
                    label: 'Load Price Levels',
                    functionName: 'loadPriceLevelPanel("' + customerId + '","' + customerName + '");'
                });
                var btnLoadCustomerAllocation = itemSublist.addButton({
                    id: 'custpage_btn_load_customer_allocation',
                    label: 'Load Customer Allocations',
                    functionName: 'loadCustomerAllocation("' + customerId + '","' + customerName + '","' + location + '");'
                });
            }
            context.form.clientScriptModulePath = 'SuiteScripts/Orders/OLA_CS_OrderEntry.js';
        }

        //REVIEW: OK
        function displayTransactionCurrency(context) {
            var thisRecord = context.newRecord;
            var currency = thisRecord.getValue('currency');

            var currencyFlags = [
                {
                    ID: '1',
                    Currency: 'USD',
                    URL: '<img src="/core/media/media.nl?id=393824&c=4003712&h=ea9109528c11a2766fbf" width="50px;"></img>'
                },
                {
                    ID: '2',
                    Currency: 'GBP',
                    URL: '<img src="/core/media/media.nl?id=393827&c=4003712&h=a440f3dbc09f8476eabc" width="50px;"></img>'
                },
                {
                    ID: '3',
                    Currency: 'CAD',
                    URL: '<img src="/core/media/media.nl?id=393928&c=4003712&h=f54c9b65f969fc59d741" width="50px;"></img>'
                },
                {
                    ID: '4',
                    Currency: 'EUR',
                    URL: '<img src="/core/media/media.nl?id=393825&c=4003712&h=12c228c4c84989bd4966" width="50px;"></img>'
                },
                {
                    ID: '5',
                    Currency: 'HKD',
                    URL: '<img src="/core/media/media.nl?id=393826&c=4003712&h=fSe_2YDG4rM6YP2C8IQHT0-YHCGRZUpoiGNzn1KnZe10mb4r" width="50px;"></img>'
                },
                {
                    ID: '6',
                    Currency: 'AUD',
                    URL: '<img src="/core/media/media.nl?id=1202253&c=4003712&h=Obl6Yrnr2EmrxHJDsaKbh71U4YwaQp4TPjwK-DkIa2Aw4gxf" width="50px;"></img>'
                }
            ]
            var url = currencyFlags.find(x => x.ID === currency).URL;
            thisRecord.setValue('custbody_ola_country_flag', url);
        }

        function initializeForm(context) {
            var thisRecord = context.newRecord;
            if (thisRecord.getValue('custbody_ola_has_discrepancy')) {
                var warningField = context.form.addField({
                    id: 'custpage_warning_field',
                    type: 'INLINEHTML',
                    label: 'Script'
                });
                var jsScript = "<script>jQuery(function($){ ";
                jsScript += "require(['SuiteScripts/Orders/OLA_CS_OrderEntry.js'], ";
                jsScript += "function(mod) { mod.displayPriceWarning();});});</script>";
                warningField.defaultValue = jsScript;
            }
        }

        //REVIEW: Client can be called once in main
        function initializePopup(context) {
            var scriptTag = context.form.addField({
                id: 'custpage_script',
                type: 'INLINEHTML',
                label: 'Script'
            });
            var popupConfig = getPopupConfig();
            if (popupConfig) {
                //create the html to load the scripts and css to the page
                var scriptHTML = '<link href="' + popupConfig.ConfigStyle + '" rel="stylesheet">';
                scriptHTML += '<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>';
                scriptHTML += '<script src="' + popupConfig.ConfigCode + '"></script>';
                //assign the value to the control to inject the code
                scriptTag.defaultValue = scriptHTML;
            }
            if (context.form.clientScriptModulePath === '') {
                context.form.clientScriptModulePath = 'SuiteScripts/Orders/OLA_CS_OrderEntry.js';
            }
        }

        function getPopupConfig() {
            var funcName = '@getPopupConfig';
            try {
                var currentUser = runtime.getCurrentUser().name;
                var rec = record.load({
                    type: 'customrecord_ola_popup_config',
                    id: 1
                });
                if (rec) {
                    var retCfg = {
                        ConfigProcessor: rec.getValue('custrecord_popup_cfg_sl_url'),
                        ConfigCode: rec.getValue('custrecord_popup_cfg_code_url'),
                        ConfigStyle: rec.getValue('custrecord_popup_cfg_stylesheet_url')
                    }
                }
                else {
                    log.audit(funcName, 'Popup Config record not loading correctly for ' + currentUser);
                    var retCfg = {
                        ConfigProcessor: "/app/site/hosting/scriptlet.nl?script=360&deploy=1",
                        ConfigCode: "/core/media/media.nl?id=401524&c=4003712&h=14671f4cc1d8ddc9b636&_xt=.js",
                        ConfigStyle: "/core/media/media.nl?id=401548&c=4003712&h=59eb8445917ce7045c96&_xt=.css"
                    }
                }
                return retCfg;
            }
            catch (ex) {
                log.error(funcName, ex);
            }
        }

        function getToday() {
            var today = new Date();
            var month = today.getMonth() + 1;
            var year = today.getFullYear();
            var day = today.getDate();
            return currentDate = month + '/' + day + '/' + year;
        }

        function getDaysBetweenDates(d0, d1) {
            var msPerDay = 8.64e7;
            // Copy dates so don't mess them up
            var x0 = new Date(d0);
            var x1 = new Date(d1);
            // Set to noon - avoid DST errors
            x0.setHours(12, 0, 0);
            x1.setHours(12, 0, 0);
            // Round to remove daylight saving errors
            return Math.round((x1 - x0) / msPerDay);
        }

        /*----address handling functions----*/
        function getCustomerAddresses(customerId) {
            const funcName = '@getCustomerAddresses';
            try {
                if (customerId != '') {
                    var custObj = record.load({
                        type: record.Type.CUSTOMER,
                        id: customerId,
                        isDynamic: true
                    });
                    var addressLineCount = custObj.getLineCount('addressbook');
                    var customerAddresses = [];
                    if (addressLineCount > 0) {
                        for (var i = 0; i < addressLineCount; i++) {
                            custObj.selectLine({
                                sublistId: 'addressbook',
                                line: i
                            });
                            var customerAddressId = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'addressid'
                            });
                            var customerAddressLabel = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'label'
                            });
                            var customerAddressText = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'addrtext_initialvalue'
                            });
                            var customerAddressee = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'addressee_initialvalue'
                            });
                            var customerAddressCountry = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'country_initialvalue'
                            });
                            var customerAddressCity = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'city_initialvalue'
                            });
                            var customerAddress1 = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'addr1_initialvalue'
                            });
                            var customerAddress2 = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'addr2_initialvalue'
                            });
                            var customerZip = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'zip_initialvalue'
                            });
                            var addressbookaddress = custObj.getCurrentSublistValue({
                                sublistId: 'addressbook',
                                fieldId: 'addressbookaddress'
                            });
                            var customerAddress = {
                                Street: customerAddress1,
                                Address2: customerAddress2,
                                City: customerAddressCity,
                                Zip: customerZip,
                                Country: customerAddressCountry,
                                Label: customerAddressLabel,
                                Addressee: customerAddressee,
                                Address: customerAddressText,
                                AddressId: customerAddressId,
                                AddressBookId: addressbookaddress,
                            };
                            customerAddresses.push(customerAddress);
                        }
                    }
                }
            }
            catch (ex) {
                log.error(funcName, ex);
            }
            return customerAddresses;
        }

        function getOrderAddress(thisRecord) {
            var orderAddress = [];
            var addressSubRecord = thisRecord.getSubrecord({ fieldId: 'shippingaddress' });
            var country = addressSubRecord.getValue({
                fieldId: 'country'
            });
            var city = addressSubRecord.getValue({
                fieldId: 'city'
            });
            var address = addressSubRecord.getValue({
                fieldId: 'addr1'
            });
            var address2 = addressSubRecord.getValue({
                fieldId: 'addr2'
            });
            var state = addressSubRecord.getValue({
                fieldId: 'state'
            });
            var zip = addressSubRecord.getValue({
                fieldId: 'zip'
            });
            var addressee = addressSubRecord.getValue({
                fieldId: 'addressee'
            });
            var addressText = thisRecord.getValue('shippingaddress_text');
            if (zip.indexOf('-') != -1) {
                var zipSplits = zip.split('-');
                if (zipSplits.length > 0) {
                    var orderShipZip = zipSplits[0];
                }
            }
            else {
                var orderShipZip = zip;
            }
            orderAddress.push({
                Addressee: addressee,
                Street: address,
                Address2: address2,
                City: city,
                State: state,
                Zip: orderShipZip,
                Country: country,
                Address: addressText
            });
            return orderAddress;
        }

        function compareAddresses(customerAddresses, orderAddress) {
            const funcName = '@compareAddresses';
            try {
                //log.audit('customerAddresses', customerAddresses);
                //log.audit('orderAddress', orderAddress);
                var addressesToCompare = [];
                //loop through customerAddresses and compare with orderAddress
                for (var i = 0; i < customerAddresses.length; i++) {
                    var customerAddress = customerAddresses[i];
                    //country must match first
                    if (customerAddress.Country.toUpperCase() == orderAddress[0].Country.toUpperCase()) {
                        var cityScore = getScore(customerAddress.City, orderAddress[0].City);
                        //reset global score comparison
                        addressScore = 0;
                        //and then zip must match next
                        if (customerAddress.Zip.indexOf('-') != -1) {
                            var splitZip = customerAddress.Zip.split('-');
                            //for US zip codes we just want the first 5 digits
                            if (splitZip[0].length == 5) {
                                var addressZip = splitZip[0].replace(/ /g, '');
                            }
                            else {
                                //this is for non-US zip codes which might have dashes
                                var addressZip = customerAddress.Zip.replace(/ /g, '');
                            }
                        }
                        else {
                            var addressZip = customerAddress.Zip.replace(/ /g, '');
                        }
                        //log.audit(addressZip + ' ? ' + orderAddress[0].Zip.replace(/ /g, ''));

                        if (addressZip == orderAddress[0].Zip.replace(/ /g, '')) {
                            var customerAddressCompare = customerAddress.Street.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "") +
                                customerAddress.City.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "");

                            var orderAddressCompare = orderAddress[0].Street.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "") +
                                orderAddress[0].City.replace(/[\r\n]+/g, ' ').trim().replace(/[ ]+/g, "");

                            var cityStreetScore = getScore(customerAddressCompare.toUpperCase(), orderAddressCompare.toUpperCase());
                            //get length of orderaddressCompare
                            if (orderAddressCompare.length > customerAddressCompare.length) {
                                var expectedScore = orderAddressCompare.length;
                            }
                            else {
                                var expectedScore = customerAddressCompare.length;
                            }

                            //get the percentage of matching characters
                            if (cityStreetScore == 0) {
                                var percentageMatch = 1;
                            }
                            else {
                                if (Number(expectedScore) > Number(cityStreetScore)) {
                                    var percentageMatch = (Number(expectedScore) - Number(cityStreetScore)) / Number(expectedScore);
                                    //log.audit('Percentage Match ' + percentageMatch, (expectedScore - cityStreetScore) + '/' + expectedScore);
                                }
                                else {
                                    var percentageMatch = Number(expectedScore) / Number(cityStreetScore);
                                    //log.audit('Percentage Match ' + percentageMatch, expectedScore + '/' + cityStreetScore);
                                }
                            }

                            //log.audit('After Zip check->citystreetscore: ' + cityStreetScore);
                            //log.audit('customerAddressCompare', customerAddressCompare);
                            //log.audit('orderAddressCompare', orderAddressCompare);

                            //log.audit('halfscore: ' + expectedScore / 2);
                            //cityStreetScore = 0 means it's a perfect match
                            //percentageMatch must be greater than 50%
                            if ((cityStreetScore <= Number(expectedScore) / 2)
                                || (Number(percentageMatch) >= .50 && Number(percentageMatch <= 1))) {
                                //log.audit('Passed Country and Zip test', customerAddress.Country + ' ' + customerAddress.Zip);
                                //reset global score comparison
                                addressScore = 0;
                                //get a weighted score for the street
                                var score = getScore(customerAddress.Street, orderAddress[0].Street);
                                //log.audit('score', score);
                                var nearestMatches = getNearestMatches(score, customerAddress, orderAddress[0]);
                                nearestMatches.PercentageMatch = percentageMatch * 100;
                                addressesToCompare.push(nearestMatches);
                                addressScore = 0;
                                break;
                            }
                        }
                    }
                }
            }
            catch (ex) {
                log.error(funcName, ex);
                log.error('customerAddressCompare Error', customerAddressCompare);
                log.error('orderAddressCompare Error', orderAddressCompare);
            }
            return addressesToCompare;
        }

        function getNearestMatches(score, customerStreetAddress, orderStreetAddress) {
            var useThisAddress = '';
            var matchWith = '';
            if (addressScore == 0) {
                //seed it first
                addressScore = score;
            }
            if (score <= addressScore) {
                //log.audit(score + ' ? ' + addressScore, orderStreetAddress.Address);
                useThisAddress = customerStreetAddress.Address;
                matchWith = orderStreetAddress.Address;
            }
            return retObj = {
                UseAddressId: customerStreetAddress.AddressId,
                UseThisAddress: useThisAddress,
                UseToMatch: matchWith
            };
        }

        function getScore(s1, s2) {
            s1 = s1.toLowerCase();
            s2 = s2.toLowerCase();
            //log.audit('getScore', s1 + ' ? ' + s2);
            var costs = new Array();
            for (var i = 0; i <= s1.length; i++) {
                var lastValue = i;
                for (var j = 0; j <= s2.length; j++) {
                    if (i == 0)
                        costs[j] = j;
                    else {
                        if (j > 0) {
                            var newValue = costs[j - 1];
                            if (s1.charAt(i - 1) != s2.charAt(j - 1))
                                newValue = Math.min(Math.min(newValue, lastValue),
                                    costs[j]) + 1;
                            costs[j - 1] = lastValue;
                            lastValue = newValue;
                        }
                    }
                }
                if (i > 0)
                    costs[s2.length] = lastValue;
            }
            return costs[s2.length];
        }

        function sendNotification(htmldata, subject) {
            var funcName = 'sendNotification';
            try {
                if (htmldata.length > 0) {
                    email.send({
                        author: 320470, //support@olaplex.com
                        recipients: 8097340, //['ericb@olaplex.com'],
                        //bcc: ['ericb@olaplex.com'],
                        subject: subject,
                        body: htmldata
                    });
                }
            }
            catch (ex) {
                log.error(funcName, ex);
            }
        }
        /*-----helper functions-----*/
        function updateShipToRate(thisRecord) {
            try {
                //need to capture the exchange rate that applies to shipto country 
                //for invoicing requirements related to VAT
                //var forexRate = thisRecord.getValue('exchangerate');
                var shipCountry = thisRecord.getValue('shipcountry');
                var invoiceDate = thisRecord.getValue('trandate');
                var exchangeRate = getExchangeRate(shipCountry, invoiceDate);
                //log.audit('ShipTo Exchange Rate = ' + exchangeRate + ' for ' + thisRecord.getValue('tranid'));
                thisRecord.setValue('custbody_ola_shipto_exchangerate', exchangeRate);
            }
            catch (ex) {
                log.error(funcName, ex);
            }
        }
        //reference for list of currencies
        //https://4003712.app.netsuite.com/app/common/multicurrency/currencylist.nl
        function getExchangeRate(shipcountry, thisdate) {
            const funcName = '@getExchangeRate';
            try {
                var rate = 1;   //default for USD
                var currencySymbol = 'USD';
                switch (shipcountry) {
                    case 'GB':
                        currencySymbol = 'GBP';
                        break;
                    case 'AU':
                        currencySymbol = 'AUD';
                        break;
                    case 'HK':
                        currencySymbol = 'HKD';
                        break;
                    case 'US':
                        currencySymbol = 'USD';
                        break;
                    case 'CA':
                        currencySymbol = 'CAD';
                        break;
                    default:
                        currencySymbol = 'EUR';
                }
                rate = currency.exchangeRate({
                    source: currencySymbol,
                    target: 'USD',
                    date: new Date(thisdate)
                });
                log.audit('Ship Country: ' + shipcountry + ' currency: ' + currencySymbol, 'Exchange Rate: ' + rate);
            }
            catch (ex) {
                log.error(funcName, ex);
            }
            return rate;
        }
        function isNullOrEmpty(sData) {
            return ((sData === '' || sData == null || sData == undefined) || (Array.isArray(sData) && sData.length == 0) || (typeof sData === 'object' && (function (o) {
                for (var i in o)
                    return false;
                return true;
            })(sData)));
        }

        //REVIEW: OK but could we prevent looping in before load?
        function displayQtyCasePackMessage(context) {
            const thisRecord = context.newRecord;
            let showMessage = false;
            let message2show = '';
            const lineCount = thisRecord.getLineCount('item');
            for (let i = 0; i < lineCount; i++) {
                const qty = thisRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantity',
                    line: i
                });
                const item = thisRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item_display',
                    line: i
                });
                const casepack = thisRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ola_casepack_size',
                    line: i
                });
                const modulus = Number(casepack) > 0 ? qty % casepack : 0;
                if (modulus != 0) {
                    message2show += ' / Line: ' + (i + 1) + ' Item: ' + item + ' Qty: ' + qty + ' Pack Size: ' + casepack;
                    showMessage = true;
                }
            }
            if (showMessage) {
                context.form.addPageInitMessage({ type: message.Type.WARNING, message: `WARNING! Requested item quantity must be in case pack quantity ${message2show}`, duration: 50000 });
            }
        }
        return {
            beforeLoad: beforeLoad,
            beforeSubmit: beforeSubmit,
            afterSubmit: afterSubmit
        };

    });