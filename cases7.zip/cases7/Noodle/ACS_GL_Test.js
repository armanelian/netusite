/**
 * @NApiVersion 2.x
 * @NScriptType customglplugin
 *
 * ACS CASE 6081824
 *
 */
define(/**
 * @return {{customizeGlImpact: ((function({standardLines: Object, transactionRecord: Object, customLines: Object}): boolean)|*)}}
 */
    function entry() {
        /**
         * @param context {{standardLines: object, transactionRecord: object, customLines: object}}
         * @return {boolean}
         */
        function afterSubmitTrigger(context) {
            log.debug("START", "START");
            const customLines = context.customLines;

            //FIRST - debit 1080
            const firstLine = customLines.addNewLine();
            firstLine.accountId =context.standardLines.getLine({ index: 1 }).accountId;
            firstLine.debitAmount = 100;
            // firstLine.entityId = context.standardLines.getLine({ index: 1 }).entityId;
            firstLine.locationId = context.standardLines.getLine({ index: 1 }).locationId;
            firstLine.memo = context.standardLines.getLine({ index: 1 }).memo;

            //SECOND - credit 2130
            const secondLine = customLines.addNewLine();
            secondLine.accountId = context.standardLines.getLine({ index: 0 }).accountId;
            secondLine.creditAmount = 100;
            // secondLine.entityId = context.standardLines.getLine({ index: 0 }).entityId;
            secondLine.locationId = context.standardLines.getLine({ index: 0 }).locationId;
            secondLine.memo = context.standardLines.getLine({ index: 0 }).memo;
            log.debug("END", "END");

            return true;
        }

        return {
            customizeGlImpact: afterSubmitTrigger,
        };
    });
