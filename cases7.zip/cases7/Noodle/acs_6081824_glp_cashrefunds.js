/**
 * @NApiVersion 2.x
 * @NScriptType customglplugin
 *
 * ACS CASE 6081824
 *
 * Background (use case)
 * GCP integrates return transactions from their store POS system. When the transaction tender is split between
 * cash and gift cards they have to manually create Journal Entries to reclass the transactions.
 *
 * Logic
 * The script will evaluate the GL Posting on the Cash Refund and
 *  - if there is an entry in the Gift Card Amount custom field (custbody_gift_card_amount)
 *  - this amount will be used in the additional GL Lines:
 *    - the first line will Debit 1080 for the Gift Card Amount
 *    - the second line will Credit 2130 for the Gift Card Amount
 *
 * Samples:
 * SB1
 *  - CR100004749
 *
 * Flow:
 * https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/section_3989534344.html#bridgehead_4088962791
 *
 * Sample:
 * https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/article_8102434206.html
 *
 * Utilities:
 * https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/section_4224037854.html#bridgehead_4098102006
 */
define(/**
 * @return {{customizeGlImpact: ((function({standardLines: Object, transactionRecord: Object, customLines: Object}): boolean)|*)}}
 */
function entry() {
  /**
   * @param context {{standardLines: object, transactionRecord: object, customLines: object}}
   * @return {boolean}
   */
  function afterSubmitTrigger(context) {
    const INPUTS = {
      defaults: {
        credit: {
          id: 369,
          name: 'Gift Cards Outstanding',
          number: 2130,
        },
        debit: {
          id: 996,
          name: 'Gift Card Redemptions Clearing',
          number: 1080,
        },
        location: {
          id: 203,
          name: 'Work World - California : WW - North : 010 - Fairfield',
        },
        subsidiary: {
          id: 2,
          name: 'GCP WW Acquisition LLC : GCP WW Holdco LLC',
        },
      },
      context: {
        firstAccount: context.standardLines.getLine({ index: 0 }).accountId,
        secondAccount: context.standardLines.getLine({ index: 1 }).accountId,
        giftCardAmount: Number(context.transactionRecord.getValue({ fieldId: 'custbody_gift_card_amount' })), //Decimal number
        memo: String(context.transactionRecord.getValue({ fieldId: 'memo' })),
        entity: Number(context.transactionRecord.getValue({ fieldId: 'entity' })),
      },
    };

    log.debug({ title: 'INPUTS', details: JSON.stringify(INPUTS) });
    if (!INPUTS.context.giftCardAmount) return false;

    //https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/section_97094831021.html#bridgehead_34094920764
    const customLines = context.customLines;

    //FIRST - debit 1080
    const firstLine = customLines.addNewLine();
    firstLine.accountId = INPUTS.defaults.debit.id;
    firstLine.debitAmount = INPUTS.context.giftCardAmount;
    firstLine.entityId = INPUTS.context.entity;
    firstLine.locationId = INPUTS.defaults.location.id;
    firstLine.memo = INPUTS.context.memo;

    //SECOND - credit 2130
    const secondLine = customLines.addNewLine();
    secondLine.accountId = INPUTS.defaults.credit.id;
    secondLine.creditAmount = INPUTS.context.giftCardAmount;
    secondLine.entityId = INPUTS.context.entity;
    secondLine.locationId = INPUTS.defaults.location.id;
    secondLine.memo = INPUTS.context.memo;

    return true;
  }

  return {
    customizeGlImpact: afterSubmitTrigger,
  };
});
