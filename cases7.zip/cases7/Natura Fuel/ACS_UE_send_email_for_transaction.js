/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       08/04/2025      Elian Arman         Case #6269115
 * 
 */
define(['N/render', 'N/email', 'N/search', 'N/runtime'],

    (render, email, search, runtime) => {

        const afterSubmit = (scriptContext) => {
            const logTitle = 'afterSubmit';
            try {
                if (scriptContext.type != scriptContext.userEventType.CREATE && scriptContext.type != scriptContext.userEventType.COPY) return

                let newRec = scriptContext.newRecord;
                let recType = newRec.type;
                let user = runtime.getCurrentUser().id;
                let emailTo;
                let customer;
                let typeForSubject;
                if (recType == 'invoice') {
                    typeForSubject = 'Invoice';
                    customer = newRec.getValue('entity');
                } else if (recType == 'customerpayment') {
                    typeForSubject = 'Payment';
                    customer = newRec.getValue('customer');
                }

                emailToSearch = search.lookupFields({
                    type: search.Type.CUSTOMER,
                    id: customer,
                    columns: ['email', 'custentity_atlas_customer_invoice_email', 'custentity_2663_email_address_notif']
                });

                if (recType == 'invoice') {
                    emailTo = emailToSearch.custentity_atlas_customer_invoice_email;
                } else {
                    emailTo = emailToSearch.custentity_2663_email_address_notif;
                }
                if (!emailTo) emailTo = emailToSearch.email;

                if (emailTo) {
                    let tranId = search.lookupFields({
                        type: recType,
                        id: newRec.id,
                        columns: 'tranid'
                    }).tranid;

                    const pdfFile = render.transaction({
                        entityId: newRec.id,
                        printMode: render.PrintMode.PDF,
                        type: recType
                    });

                    email.send({
                        author: user,
                        recipients: [emailTo],
                        subject: '[External] : Corpotool, LLC: ' + typeForSubject + ' #' + tranId,
                        body: 'Please find attached the ' + typeForSubject + ' #' + tranId + '.',
                        attachments: [pdfFile],
                        relatedRecords: {
                            transactionId: newRec.id
                        }
                    });
                }


            } catch (error) {
                log.error(logTitle, error);
            }
        }

        return { afterSubmit }

    });