/** Version    Date              Author              Remarks
 *  1.00       21 Jan 2025      Paula Alvarez       Case 6737666, Initial Commit
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * @NScriptName ACS | MR | Update Faire Available Qty
 */
define(['N/search'],
    
    (search) => {

        const getInputData = (inputContext) => {
                try{
                        const searchID = runtime.getCurrentScript().getParameter({name:'custscript_acs_search'})
                        return search.load({type: 'item', id: searchID})
                } catch (e) {
                        log.error('Get Input data Error', e)
                }

        }

        const map = (mapContext) => {
                try {
                        const result = JSON.parse(mapContext.value);

                        log.debug('result', result)

                        const itemId = result.values.internalid?.value;
                        if (!itemId) return;

                        log.debug('itemId', itemId)

                        let faireQty = result.values['formulanumeric'] || 0;

                        log.debug('faireQty', faireQty)

                        faireQty = Number(faireQty) || 0;

                        log.debug('fqty afyter num', faireQty)

                        mapContext.write({
                                key: itemId,
                                value: faireQty
                        });

                } catch (e) {
                        log.error('map error', {
                                error: e,
                                context: mapContext.value
                        });
                }

        }

        const reduce = (reduceContext) => {
                try {
                        const itemId = reduceContext.key;

                        log.debug('itemId', itemId)

                        let faireQty = reduceContext.values[0];

                        log.debug('faireQty', faireQty)

                        faireQty = Number(faireQty) || 0;

                        log.debug('fqty afyter num', faireQty)

                        record.submitFields({
                                type: record.Type.INVENTORY_ITEM,
                                id: itemId,
                                values: {
                                        custitem_acs_faire_available_qty: faireQty
                                },
                                options: {
                                        enableSourcing: false,
                                        ignoreMandatoryFields: true
                                }
                        });

                        log.audit('Item updated', {
                                itemId,
                                availLessFaire: faireQty
                        });

                } catch (e) {
                        log.error('reduce error', {
                                itemId: reduceContext.key,
                                error: e
                        });
                }

        }

        const summarize = (summaryContext) => {

        }

        return {getInputData, map, reduce, summarize}

    });
