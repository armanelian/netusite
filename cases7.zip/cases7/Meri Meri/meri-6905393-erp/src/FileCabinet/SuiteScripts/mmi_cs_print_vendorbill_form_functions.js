/**
 * Version    Date          Author              Remarks
 * 1.00       4/22/2025      Martin Chocho       Initial commit: case 6282554
 * @NApiVersion 2.1
 * @NModuleScope Public
 * @NScriptType ClientScript
 */
define(["N/record", "N/search", "N/runtime", "N/currentRecord", "N/url"],
    (record, search, runtime, currentRecord, url) => {
        var exports = {};

        /**
         * pageInit event handler; executed when the page completes loading or when the form is reset.
         *
         * @gov XXX
         *
         * @param {Object} context
         * @param {string} context.mode - The access mode of the current record.
         * @param {CurrentRecord} context.currentRecord - The record in context
         */
        function pageInit(context) {
            // TODO
        }

        function printVendorBill() {
            try {
                let scriptId = "customscript_sl_print_vb_form_page";
                let deploymentId = "customdeploy_sl_print_vb_form_page";

                let suiteletUrl = url.resolveScript({
                    scriptId: scriptId,
                    deploymentId: deploymentId,
                    returnExternalUrl: false,
                    params: {
                        recordId: currentRecord.get().id
                    }
                });
                //
                // let response = https.post({
                //         url: suiteletUrl,
                //         body: JSON.stringify(data),
                //         headers: {
                //                 "Content-Type": "application/json"
                //         }
                // });
                // let pdfUrl = response.body;
                // window.open(pdfUrl);
                window.open(suiteletUrl, "_blank");
            } catch (e) {
                log.error(e.name, e.stack);
            }
        }


        exports.pageInit = pageInit;
        exports.printVendorBill = printVendorBill;
        return exports;
    });
