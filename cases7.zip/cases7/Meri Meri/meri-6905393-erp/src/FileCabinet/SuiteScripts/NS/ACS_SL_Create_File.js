/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope Public
 *
 * Version    Date          Author        Remarks
 * 1.00       16/08/23      Pedro Trecca  Initial Commit
 *
 */

define([
    'N/runtime',
    'N/record',
    'N/log',
], function (
    nRuntime,
    nRecord,
    nLog
) {
    'use strict';

    const validate = (fileObject) => {
        let isValid = {
            valid: true
        };
        if (!fileObject) {
            isValid = {
                valid: false,
                name: 'ERR_FILE_NOT_PRESENT',
                message: 'No file uploaded'
            };
        }

        // 10 MB File Restriction
        if (fileObject.size >= 10000000) {
            isValid = {
                valid: false,
                name: 'ERR_FILE_SIZE_NOT_ALLOWED',
                message: 'File Size Not Allowed'
            };
        }

        /*   if (fileObject.fileType !== 'CSV') {
               isValid = {
                   valid: false,
                   name: 'ERR_FILE_TYPE_NOT_SUPPORTED',
                   message: 'File Type Not Supported'
               };
           }*/
        return isValid;
    };

    const uploadFile = (context) => {
        const folderId = nRuntime.getCurrentScript().getParameter({
            name: 'custscript_acs_upload_file_folderId'
        });
        let fileId;
        let result = {};
        let fileObject;
        let fileValidation;
        try {
            fileObject = context.request.files['file'];
            fileValidation = validate(fileObject);
            if (fileValidation.valid) {
                fileObject.folder = folderId; //folder internal ID
                fileId = fileObject.save();
                nRecord.attach({
                    record: {
                        type: 'file',
                        id: fileId
                    },
                    to: {
            
                        type: 'customer',
                        id: nRuntime.getCurrentUser().id
                    }
                });
                result = {
                    success: true
                }
            } else {
                result = {
                    error: true,
                    errorName: fileValidation.name,
                    errorMessage: fileValidation.message,
                }
            }
        } catch (error) {
            nLog.error('Unexpected Error', error);
            result = {
                error: true,
                errorName: 'ERR_UNEXPECTED_ERROR',
                errorMessage: 'An Error Ocurred while uploading the file'
            }
        }
        context.response.write({
            output: JSON.stringify(result)
        });
    }

    return {
        onRequest: uploadFile
    };
});
