/** Version    Date              Author              Remarks
 *  1.00       21 Jan 2025      Paula Alvarez       Case 6737666, Initial Commit
 * 
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * @NScriptName ACS | MR | Update Faire Available Qty
 * 
 */
define(['N/search', 'N/runtime', 'N/record'],

        (search, runtime, record) => {

                const getInputData = (inputContext) => {
                        try {
                                const searchID = runtime.getCurrentScript().getParameter({ name: 'custscript_acs_search' })

                                return search.load({ type: 'item', id: searchID })
                        } catch (e) {
                                log.error('Get Input data Error', e)
                        }

                }

                const map = (mapContext) => {
                        try {
                                const result = JSON.parse(mapContext.value);
                                const contextValues = result.values;
                                const itemId = contextValues["GROUP(internalid)"].value;

                                if (!itemId) return;

                                let faireQty = contextValues["GROUP(formulanumeric)"] || 0;
                                faireQty = Number(faireQty) || 0;

                                mapContext.write({
                                        key: itemId,
                                        value: faireQty
                                });

                        } catch (e) {
                                log.error('map error', {
                                        error: e,
                                        context: mapContext.value
                                });
                        }

                }

                const reduce = (reduceContext) => {
                        const itemId = reduceContext.key;
                        try {

                                let faireQty = reduceContext.values[0];
                                faireQty = Number(faireQty) || 0;

                                record.submitFields({
                                        type: record.Type.INVENTORY_ITEM,
                                        id: itemId,
                                        values: {
                                                'custitem_acs_faire_available_qty': faireQty
                                        }
                                });

                                log.audit('Item updated', {
                                        itemId,
                                        availLessFaire: faireQty
                                });

                        } catch (e) {
                                log.error('reduce error', "Item id: " + itemId + " - Error: " + e);
                        }

                }

                const summarize = (summaryContext) => {

                }

                return { getInputData, map, reduce, summarize }

        });
