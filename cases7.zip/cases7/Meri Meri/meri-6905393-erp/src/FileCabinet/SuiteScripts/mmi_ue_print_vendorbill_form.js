/**
 * Version    Date          Author              Remarks
 * 1.00       4/22/2025      Martin Chocho       Initial commit: case 6282554
 * @NApiVersion 2.1
 * @NModuleScope Public
 * @NScriptType UserEventScript
 */
define(["N/record", "N/search", "N/runtime"],
    (record, search, runtime) => {
        var exports = {};

        /**
         * beforeLoad event handler; executes whenever a read operation occurs on a record, and prior
         * to returning the record or page.
         *
         * @gov XXX
         *
         * @param {Object} context
         * @param {Record} context.newRecord - The new record being loaded
         * @param {UserEventType} context.type - The action type that triggered this event
         * @param {Form} context.form - The current UI form
         */
        function beforeLoad(context) {
            try{
                let form = context.form;
                form.addButton({
                    id: "custpage_print_vendor_bill",
                    label: "Print",
                    functionName: `printVendorBill`
                });

                form.clientScriptModulePath = "./" + runtime.getCurrentScript().getParameter("custscript_acs_cs_print_vb_functions");
            } catch (e) {
                log.error(e.name, e.stack);
            }
        }


        exports.beforeLoad = beforeLoad;
        return exports;
    });
