/**
 * Version    Date          Author              Remarks
 * 1.00       4/22/2025      Martin Chocho       Initial commit: case 6282554
 * @NApiVersion 2.1
 * @NModuleScope Public
 * @NScriptType Suitelet
 */
define(["N/record", "N/search", "N/runtime", 'N/https', "N/render", "N/file"],
    (record, search, runtime, https, render, file) => {
        var exports = {};

        /**
         * onRequest event handler
         *
         * @gov XXX
         *
         * @param {Object} context
         * @param {ServerRequest} context.request - The incoming request object
         * @param {ServerResponse} context.response - The outgoing response object
         */
        function onRequest(context) {
            log.audit({title: `${context.request.method} request received`});

            const eventRouter = {
                [https.Method.GET]: onGet,
            };
            try {
                (eventRouter[context.request.method])(context);
            } catch (e) {
                log.error({context: context, error: e});
            }

            log.audit({title: "Request complete."});
        }

        /**
         * Event handler for HTTP GET request
         *
         * @gov XXX
         *
         * @param {Object} context
         * @param {ServerRequest} context.request - The incoming request object
         * @param {ServerResponse} context.response - The outgoing response object
         */
        function onGet(context) {
            var request = context.request;
            var response = context.response;

            var recordId = request.parameters.recordId;

            if (!recordId) {
                response.write('Missing recordId or recordType parameter.');
                return;
            }

            try {
                const templateFileId = runtime.getCurrentScript().getParameter({ name: "custscript_pdf_template_file_id" });
                log.debug('templateFileId', templateFileId);
                if (!templateFileId) {
                    response.write("Missing script parameter: custscript_pdf_template_file_id");
                    return;
                }
                var rec = record.load({
                    type: record.Type.VENDOR_BILL,
                    id: recordId
                });

                const renderer = render.create();
                renderer.addRecord({
                    templateName: "record",
                    record: rec
                });
                renderer.setTemplateById(templateFileId);
                var pdfFile = renderer.renderAsPdf();
                pdfFile.name = `${recordId}_${rec.getValue('transactionnumber')}_${rec.getValue('tranid')}.pdf`;

                response.writeFile({
                    file: pdfFile,
                    isInline: true
                });

            } catch (e) {
                log.error(e.name, e.stack);
                response.write('Error rendering PDF: ' + e.stack);
            }
        }

        /**
         * Event handler for HTTP POST request
         *
         * @gov XXX
         *
         * @param {Object} context
         * @param {ServerRequest} context.request - The incoming request object
         * @param {ServerResponse} context.response - The outgoing response object
         */
        function onPost(context) {
            // TODO
        }

        exports.onRequest = onRequest;
        return exports;
    });
