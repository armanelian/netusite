/**
 * Version          Date          Author               Remarks
 * 1.0              2nd Feb 2023     Sravan Teja       Initial commit
 * 2.0              21th Aug 2025    Elian Arman       Including credit memos case #6453182
 **/

/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/record', 'N/search'],
    /**
     * @param{record} record
     */

    function (record, search) {

        function beforeLoad(scriptContext) {
            try {

                if (scriptContext.type = !scriptContext.UserEventType.CREATE && scriptContext.type != scriptContext.UserEventType.COPY && scriptContext.type != scriptContext.UserEventType.EDIT) return;
                let objRec = scriptContext.newRecord;
                let createdFrom = objRec.getValue('createdfrom');

                if (createdFrom === null || createdFrom === "") {
                    return;
                }
                let lineCount = objRec.getLineCount('item');

                // Making search on the transaction and pulling the previosuly created invoice data.
                let transactionSearchObj = search.create({
                    type: "transaction",
                    settings: [{ "name": "consolidationtype", "value": "ACCTTYPE" }],
                    filters:
                        [
                            ["mainline", "is", "F"],
                            "AND",
                            ["cogs", "is", "F"],
                            "AND",
                            ["taxline", "is", "F"],
                            "AND",
                            ["shipping", "is", "F"],
                            "AND",
                            [[["createdfrom.internalidnumber", "equalto", createdFrom], "AND", ["type", "anyof", "CustInvc"]], "OR", [["createdfrom.createdfrom", "anyof", createdFrom], "AND", ["type", "anyof", "CustCred"]]]
                        ],
                    columns:
                        [
                            search.createColumn({
                                name: "quantity",
                                summary: "SUM",
                                label: "Quantity"
                            }),
                            search.createColumn({
                                name: "custcol_line_id",
                                summary: "GROUP",
                                label: "Line ID"
                            })
                        ]
                });

                let results = executeSearch(transactionSearchObj);

                let itemObj = {};
                for (let i = 0; i < results.length; i++) {
                    itemObj[results[i].getValue({
                        name: "custcol_line_id",
                        summary: "GROUP",
                        label: "Line ID"
                    })] = results[i].getValue({
                        name: "quantity",
                        summary: "SUM",
                        label: "Quantity"
                    })
                }

                for (let i = 0; i < lineCount; i++) {
                    let lineId = objRec.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_line_id',
                        line: i
                    })
                    objRec.setSublistValue('item', 'custcol_ht_previously_invoiced', i, itemObj[lineId]);
                }


            } catch (error) {
                log.error('Error', error);
            }
        }

        //Function will execute a search, retrieve all results, and return the results in an array
        let executeSearch = function (srch) {
            let results = [];

            let pagedData = srch.runPaged({
                pageSize: 1000
            });
            pagedData.pageRanges.forEach(function (pageRange) {
                let page = pagedData.fetch({
                    index: pageRange.index
                });
                page.data.forEach(function (result) {
                    results.push(result);
                });
            });

            return results;
        };


        return { beforeLoad: beforeLoad }

    });