/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       08/21/2025      Elian Arman         Case #6453182
 * 
 */
define(['N/search', 'N/record'],

    (search, record) => {

        const afterSubmit = (scriptContext) => {
            try {

                if (scriptContext.type != scriptContext.UserEventType.CREATE && scriptContext.type != scriptContext.UserEventType.COPY && scriptContext.type != scriptContext.UserEventType.EDIT && scriptContext.type != scriptContext.UserEventType.DELETE) return;
                let objRec = scriptContext.newRecord;

                let createdFrom = objRec.getValue('createdfrom');

                if (objRec.type == "creditmemo") {
                    createdFrom = search.lookupFields({
                        type: record.Type.INVOICE,
                        id: createdFrom,
                        columns: ["createdfrom"]
                    }).createdfrom[0].value;
                }

                if (createdFrom === null || createdFrom === "") return;

                let transactionSearchObj = search.create({
                    type: "transaction",
                    settings: [{ "name": "consolidationtype", "value": "ACCTTYPE" }],
                    filters:
                        [
                            ["mainline", "is", "F"],
                            "AND",
                            ["cogs", "is", "F"],
                            "AND",
                            ["taxline", "is", "F"],
                            "AND",
                            ["shipping", "is", "F"],
                            "AND",
                            [[["createdfrom.internalidnumber", "equalto", createdFrom], "AND", ["type", "anyof", "CustInvc"]], "OR", [["createdfrom.createdfrom", "anyof", createdFrom], "AND", ["type", "anyof", "CustCred"]]]
                        ],
                    columns:
                        [
                            search.createColumn({
                                name: "quantity",
                                summary: "SUM",
                                label: "Quantity"
                            }),
                            search.createColumn({
                                name: "custcol_line_id",
                                summary: "GROUP",
                                label: "Line ID"
                            })
                        ]
                });

                let results = executeSearch(transactionSearchObj);

                let recSalesOrder = record.load({
                    type: record.Type.SALES_ORDER,
                    id: createdFrom
                })
                let lineCount = recSalesOrder.getLineCount('item');

                let itemObj = {};
                for (let i = 0; i < results.length; i++) {
                    itemObj[results[i].getValue({
                        name: "custcol_line_id",
                        summary: "GROUP",
                        label: "Line ID"
                    })] = results[i].getValue({
                        name: "quantity",
                        summary: "SUM",
                        label: "Quantity"
                    })
                }

                for (let i = 0; i < lineCount; i++) {
                    let invoicedQuantity = 0;
                    let lineId = recSalesOrder.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_line_id',
                        line: i
                    });

                    if (itemObj[lineId]) invoicedQuantity = itemObj[lineId];
                    recSalesOrder.setSublistValue('item', 'custcol_acs_invoiced', i, invoicedQuantity);
                }

                let idSaved = recSalesOrder.save();

                log.audit('Sales order saved', 'SO ID: ' + idSaved);

            } catch (error) {
                log.error('Error', error);
            }

        }

        //Function will execute a search, retrieve all results, and return the results in an array
        let executeSearch = function (srch) {
            let results = [];

            let pagedData = srch.runPaged({
                pageSize: 1000
            });
            pagedData.pageRanges.forEach(function (pageRange) {
                let page = pagedData.fetch({
                    index: pageRange.index
                });
                page.data.forEach(function (result) {
                    results.push(result);
                });
            });

            return results;
        };

        return { afterSubmit }

    });
