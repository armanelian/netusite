/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       04/14/2025      Elian Arman         Case #6115991
 * 
 */
define(['N/search', 'N/record', 'N/runtime'],

    (search, record, runtime) => {

        const getInputData = (inputContext) => {
            const logTitle = 'getInputData';
            try {
                let recType = runtime.getCurrentScript().getParameter('custscript_record_type');
                let transactions = search.create({
                    type: "transaction",
                    filters:
                        [
                            ["type", "anyof", recType],
                            "AND",
                            ["accountingperiod.closed", "is", "F"]
                        ],
                    columns: []
                });

                return transactions;

            } catch (error) {
                log.error(logTitle, error);
            }
        }

        const reduce = (reduceContext) => {
            const logTitle = 'reduce';
            try {
                const contextValues = JSON.parse(reduceContext.values[0]);

                let recordId = contextValues.id;
                let type = contextValues.recordType;
                log.audit('Processing record', 'TYPE: ' + type + ' - ID: ' + recordId);
                
                let rec = record.load({
                    type: type,
                    id: recordId
                });

                if (type == record.Type.INVOICE || type == record.Type.CREDIT_MEMO) {
                    let lineCount = rec.getLineCount("item");

                    for (let i = 0; i < lineCount; i++) {
                        let itemType = rec.getSublistValue({
                            sublistId: "item",
                            fieldId: "itemtype",
                            line: i
                        });

                        if (itemType == "Subtotal" || itemType == "Discount" || itemType == "Description") {
                            log.audit('Modify Subtotal or Discount line', 'TYPE: ' + type + ' - LINE TYPE: ' + itemType + ' - ID: ' + recordId + ' - Line: ' + i);

                            rec.setSublistValue({
                                sublistId: "item",
                                fieldId: "quantity",
                                line: i,
                                value: ""
                            });
                        }
                    }
                }

                let recIdSaved = rec.save({
                    ignoreMandatoryFields: true
                });

                log.audit('Record Saved', 'TYPE: ' + type + ' - ID: ' + recIdSaved);

            } catch (error) {
                log.error(logTitle, error);
            }
        }


        const summarize = (summaryContext) => {

        }

        return { getInputData, reduce, summarize }

    });
