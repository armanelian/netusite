/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       11/17/2025      Elian Arman         Case #
 * 
 */
define(['N/ui/serverWidget', 'N/search', 'N/record'],

    (serverWidget, search, record) => {

        const beforeLoad = (scriptContext) => {

            try {

                const { newRecord, type, form, UserEventType } = scriptContext;
                if (type === UserEventType.CREATE) {


                    let createdFrom = newRecord.getValue('createdfrom');
                    
                    let createdFromFields = search.lookupFields({
                        type: search.Type.TRANSACTION,
                        id: createdFrom,
                        columns: ['recordtype']
                    });

                    //if created from is an invoice
                    if (createdFromFields.recordtype == 'invoice') {

                        let countLines = newRecord.getLineCount('item');

                        for (let i = 0; i < countLines; i++) {
                            newRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_invoice_line',
                                line: i,
                                value: i
                            })
                        }

                    }

                }

                let sublist = form.getSublist('item')
                let colInvoiceLine = sublist.getField({
                    id: 'custcol_invoice_line'
                });

                colInvoiceLine.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                });

            } catch (e) {
                log.error({
                    title: 'ERROR | beforeLoad',
                    details: e
                });
            }


        }

        const afterSubmit = (scriptContext) => {
            try {

                const { newRecord, type, UserEventType } = scriptContext;

                if (type === UserEventType.CREATE) {
                    let createdFrom = newRecord.getValue('createdfrom');

                    let createdFromFields = search.lookupFields({
                        type: search.Type.TRANSACTION,
                        id: createdFrom,
                        columns: ['recordtype']
                    });

                    if (createdFromFields.recordtype == 'invoice') {

                        let invoiceRec = record.load({
                            type: record.Type.INVOICE,
                            id: createdFrom
                        });

                        let countLines = newRecord.getLineCount('item');

                        for (let i = 0; i < countLines; i++) {
                            let creditMemoQty = newRecord.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: i
                            });
                            if(creditMemoQty != 0){

                                let invoiceLine = newRecord.getSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'custcol_invoice_line',
                                    line: i
                                });
    
                                let previouslyInvoiced = invoiceRec.getSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'custcol_ht_previously_invoiced',
                                    line: i
                                });
        
                                invoiceRec.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'custcol_ht_previously_invoiced',
                                    line: invoiceLine,
                                    value: parseInt(previouslyInvoiced) + parseInt(creditMemoQty)
                                });
                            }

                        }

                        let invoiceId = invoiceRec.save();

                        log.audit('Invoice updated', 'ID: ' + invoiceId);
                    }

                }


            } catch (e) {
                log.error({
                    title: 'ERROR | afterSubmit',
                    details: e
                });
            }
        }

        return { beforeLoad, beforeSubmit, afterSubmit }

    });
