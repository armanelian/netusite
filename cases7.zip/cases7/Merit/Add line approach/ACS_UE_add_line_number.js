/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       11/17/2025      Elian Arman         Case #
 * 
 */
define(['N/record', 'N/search'],

    (record, search) => {
        const beforeSubmit = (scriptContext) => {
            try {

                const { newRecord, type } = scriptContext;

                if (type != scriptContext.UserEventType.CREATE && type != scriptContext.UserEventType.COPY && type != scriptContext.UserEventType.EDIT) return;

                let linesLength = newRecord.getLineCount('item');

                log.debug('linesLength', linesLength)
                if (newRecord.type == record.Type.SALES_ORDER) {
                    log.debug('sales order', 'sales order')
                    if (type == scriptContext.UserEventType.CREATE || type == scriptContext.UserEventType.COPY) {
                        for (let i = 0; i < linesLength; i++) {

                            newRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_line_id',
                                line: i,
                                value: i
                            });
                        }
                    } else {

                        let maxLine = -1;

                        for (let i = 0; i < linesLength; i++) {

                            let curentLineNum = parseInt(newRecord.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_line_id',
                                line: i
                            }));

                            log.debug('curentLineNum', curentLineNum);
                            if (curentLineNum && curentLineNum > parseInt(maxLine)) {
                                log.debug('curentLineNum > maxLine', curentLineNum > maxLine);

                                maxLine = curentLineNum;
                            }

                        }

                        log.debug('maxLine', maxLine);

                        let lastLineID = parseInt(maxLine) + 1;
                        for (let i = 0; i < linesLength; i++) {

                            let curentLineNum = newRecord.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_line_id',
                                line: i
                            });

                            if (!curentLineNum) {

                                newRecord.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: 'custcol_line_id',
                                    line: i,
                                    value: lastLineID
                                });

                                lastLineID++
                            }

                        }

                    }
                }


                if (newRecord.type == record.Type.INVOICE) {
                    log.debug('invoice', 'invoice')

                    let createdFrom = newRecord.getValue('createdfrom');

                    // if (newRecord.Type == record.Type.CREDIT_MEMO) {
                    //     createdFrom = search.lookupFields({
                    //         type: search.Type.TRANSACTION,
                    //         id: createdFrom,
                    //         columns: ['createdfrom']
                    //     }).createdfrom[0].value;
                    // }

                    let objLine = {};
                    search.create({
                        type: "salesorder",
                        settings: [{ "name": "consolidationtype", "value": "ACCTTYPE" }],
                        filters:
                            [
                                ["type", "anyof", "SalesOrd"],
                                "AND",
                                ["internalidnumber", "equalto", createdFrom]
                            ],
                        columns:
                            ["line", "custcol_line_id"]
                    }).run().each(function (result) {
                        let soLine = result.getValue('line');
                        let soLineCustom = result.getValue("custcol_line_id");

                        objLine[soLine] = soLineCustom;

                        return true;
                    });
                    log.debug('objLine', objLine)

                    for (let i = 0; i < linesLength; i++) {
                        

                        let orderline = newRecord.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'orderline',
                            line: i
                        });
                        log.debug('orderline', orderline);

                        let curentLineNum = newRecord.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_line_id',
                            line: i
                        });

                        if (!curentLineNum) {
                            log.debug('objLine[orderline]', objLine[orderline]);

                            newRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_line_id',
                                line: i,
                                value: objLine[orderline]
                            });
                        }
                    }
                }
            } catch (error) {
                log.error('beforeSubmit', error);

            }




        }


        return { beforeSubmit }

    });
