/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/search'],

    function (search) {

        function beforeLoad(scriptContext) {
            try {

                if (scriptContext.type === scriptContext.UserEventType.CREATE) {
                    let objRec = scriptContext.newRecord;
                    let createdFrom = objRec.getValue('createdfrom');

                    if (createdFrom === null || createdFrom === "") {
                        return;
                    }
                    let lineCount = objRec.getLineCount('item');

                    // Making search on the transaction and pulling the previosuly created invoice data.
                    let transactionSearchObj = search.create({
                        type: "transaction",
                        settings: [{ "name": "consolidationtype", "value": "ACCTTYPE" }],
                        filters:
                            [
                                ["mainline", "is", "F"],
                                "AND",
                                ["cogs", "is", "F"],
                                "AND",
                                ["taxline", "is", "F"],
                                "AND",
                                ["shipping", "is", "F"],
                                "AND",
                                [[["createdfrom.internalidnumber", "equalto", createdFrom], "AND", ["type", "anyof", "CustInvc"]], "OR", [["createdfrom.createdfrom", "anyof", createdFrom], "AND", ["type", "anyof", "CustCred"]]]
                            ],
                        columns:
                            [
                                search.createColumn({
                                    name: "quantity",
                                    summary: "SUM",
                                    label: "Quantity"
                                }),
                                search.createColumn({
                                    name: "line",
                                    summary: "GROUP",
                                    label: "Line ID"
                                })
                            ]
                    });

                    let results = executeSearch(transactionSearchObj);

                    let itemObj = {};
                    for (let i = 0; i < results.length; i++) {
                        itemObj[results[i].getValue({
                            name: "line",
                            summary: "GROUP",
                            label: "Line ID"
                        }) - 1] = results[i].getValue({
                            name: "quantity",
                            summary: "SUM",
                            label: "Quantity"
                        })
                    }

                    for (let i = 0; i < lineCount; i++) {
                        objRec.setSublistValue('item', 'custcol_ht_previously_invoiced', i, itemObj[i]);
                    }

                }
            } catch (error) {
                log.error('Error', error);
            }
        }

        //Function will execute a search, retrieve all results, and return the results in an array
        let executeSearch = function (srch) {
            let results = [];

            let pagedData = srch.runPaged({
                pageSize: 1000
            });
            pagedData.pageRanges.forEach(function (pageRange) {
                let page = pagedData.fetch({
                    index: pageRange.index
                });
                page.data.forEach(function (result) {
                    results.push(result);
                });
            });

            return results;
        };


        return { beforeLoad: beforeLoad }

    });