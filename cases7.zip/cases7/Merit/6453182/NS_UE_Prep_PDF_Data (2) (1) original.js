/**
 * Copyright (c) 2020, Oracle and/or its affiliates.
 *
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ('Confidential Information'). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 *
 *
 * Version          Date          Author               Remarks
 * 1.0              2nd Feb 2023     Sravan Teja       Initial commit
 **/

/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/record', 'N/runtime', 'N/search', 'N/ui/serverWidget'],
    /**
     * @param{record} record
     */

    function (record, runtime, search, serverWidget) {
        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} form
         * @param {Form} scriptContext.form - Form
         * @param {Record} scriptContext.newRecord - New record
         * @param {ServerRequest} scriptContext.request - Request
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        function beforeLoad(scriptContext) {
            try {
                log.debug('scriptContext', scriptContext);
                log.debug('Context Type', scriptContext.type);
                log.debug('Execution Context', runtime.executionContext);

                if (scriptContext.type === scriptContext.UserEventType.CREATE && scriptContext.type === scriptContext.UserEventType.EDIT) {
                    var objRec = scriptContext.newRecord;
                    var createdFrom = objRec.getValue('createdfrom');
                    log.debug('createdFrom', createdFrom);
                    if(createdFrom === null || createdFrom === ""){
                        return;
                    }
                    var lineCount = objRec.getLineCount('item');
                    var items = [];
                    for (var i = 0; i < lineCount; i++) {
                        items.push(objRec.getSublistValue('item', 'item', i));
                    }

                    // Making search on the transaction and pulling the previosuly created invoice data.
                    var invoiceSearchObj = search.create({
                        type: "invoice",
                        settings: [{ "name": "consolidationtype", "value": "ACCTTYPE" }],
                        filters:
                            [
                                ["type", "anyof", "CustInvc"],
                                "AND",
                                ["item", "anyof", items],
                                "AND",
                                ["mainline", "is", "F"],
                                "AND",
                                ["cogs", "is", "F"],
                                "AND",
                                ["taxline", "is", "F"],
                                "AND",
                                ["shipping", "is", "F"],
                                "AND",
                                ["createdfrom", "anyof", createdFrom]
                            ],
                        columns:
                            [
                                search.createColumn({
                                    name: "item",
                                    summary: "GROUP",
                                    label: "Item"
                                }),
                                search.createColumn({
                                    name: "quantity",
                                    summary: "SUM",
                                    label: "Quantity"
                                }),
                                search.createColumn({
                                    name: "amount",
                                    summary: "SUM",
                                    label: "Amount"
                                })
                            ]
                    });

                    var results = executeSearch(invoiceSearchObj);
                    log.debug('results', results);
                    var itemObj = {};
                    for (var i = 0; i < results.length; i++) {
                        itemObj[results[i].getValue({
                            name: "item",
                            summary: "GROUP",
                            label: "Item"
                        })] = results[i].getValue({
                            name: "quantity",
                            summary: "SUM",
                            label: "Quantity"
                        })
                    }
                    log.debug('itemObj', itemObj);
                    for (var i = 0; i < lineCount; i++) {
                        var item = objRec.getSublistValue('item', 'item', i);
                        log.debug('item', item);
                        objRec.setSublistValue('item', 'custcol_ht_previously_invoiced', i, itemObj[item]);
                    }

                }
            } catch (error) {
                log.error('Error', error);
            }
        }

        //Function will execute a search, retrieve all results, and return the results in an array
        var executeSearch = function (srch) {
            var results = [];

            var pagedData = srch.runPaged({
                pageSize: 1000
            });
            pagedData.pageRanges.forEach(function (pageRange) {
                var page = pagedData.fetch({
                    index: pageRange.index
                });
                page.data.forEach(function (result) {
                    results.push(result);
                });
            });

            return results;
        };


        return { beforeLoad: beforeLoad }

    });