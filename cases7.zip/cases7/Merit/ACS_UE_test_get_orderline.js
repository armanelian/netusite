/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * 
 *  Version    Date            Author              Remarks
 *  1.00       08/11/2025      Elian Arman         Case #
 * 
 */
define([],

    () => {

        const beforeLoad = (scriptContext) => {

            try {

                const { newRecord } = scriptContext;
                let countLines = newRecord.getLineCount('item');

                for (let i = 0; i < countLines; i++) {
                    let orderline = newRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'orderline',
                        line: i
                    });

                    log.debug('beforeLoad', orderline);
                }

            } catch (e) {
                log.error({
                    title: 'ERROR | beforeLoad',
                    details: e
                });
            }


        }
        const afterSubmit = (scriptContext) => {
            try {

                const { newRecord } = scriptContext;
                let countLines = newRecord.getLineCount('item');

                for (let i = 0; i < countLines; i++) {
                    let orderline = newRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'orderline',
                        line: i
                    });

                    log.debug('afterSubmit', orderline);
                }

            } catch (e) {
                log.error({
                    title: 'ERROR | beforeLoad',
                    details: e
                });
            }
        }

        const beforeSubmit = (scriptContext) => {
            try {

                const { newRecord } = scriptContext;
                let countLines = newRecord.getLineCount('item');

                for (let i = 0; i < countLines; i++) {
                    let orderline = newRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'orderline',
                        line: i
                    });

                    log.debug('beforeSubmit', orderline);
                }

            } catch (e) {
                log.error({
                    title: 'ERROR | beforeLoad',
                    details: e
                });
            }
        }


        return { beforeLoad, beforeSubmit, afterSubmit }

    });
