/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/ui/serverWidget', 'N/runtime'],
    (serverWidget, runtime) => {
        
        const beforeLoad = (scriptContext) => {
            var logTitle = "beforeLoad";
            try {

                if (scriptContext.type == "edit" || scriptContext.type == "create" || scriptContext.type == "copy") {

                    var form = scriptContext.form;

                    //Conects to the acs_clientScript_buttonToAddressesSuitelet,js script
                    form.clientScriptFileId = runtime.getCurrentScript().getParameter('custscript_shipbtn_clienscriptid');

                    var shippingField = form.addField({
                        id: 'custpage_selectshipaddress',
                        label: 'Select ship address',
                        type: serverWidget.FieldType.INLINEHTML,
                        container: 'shipping'
                    });


                    var rType = scriptContext.newRecord.type;

                    if(rType == "salesorder"){

                        form.insertField({
                            field: shippingField,
                            nextfield: 'shipcarrier'
                        });
                        
                    }else{
                        form.insertField({
                            field: shippingField,
                            nextfield: 'shipaddress'
                        });
                        
                        
                    }

                    //Sets the onclick with a function(onShippingButtonClick), the function is on a client script(acs_clientScript_buttonToAddressesSuitelet.js) 
                    shippingField.defaultValue = `<button onclick="var  rConfig =  JSON.parse( '{}' ) ; rConfig['context'] = '/SuiteScripts/acs_clientScript_buttonToAddressesSuitelet'; var entryPointRequire = require.config(rConfig); entryPointRequire(['/SuiteScripts/acs_clientScript_buttonToAddressesSuitelet'], function(mod){ try{    if (!!window)    {        var origScriptIdForLogging = window.NLScriptIdForLogging;        var origDeploymentIdForLogging = window.NLDeploymentIdForLogging;        window.NLScriptIdForLogging = 'customscript_uebuttontosuitelet';        window.NLDeploymentIdForLogging = 'customdeploy_uebuttontosuitelet';    }mod.onShippingButtonClick();}finally{    if (!!window)    {        window.NLScriptIdForLogging = origScriptIdForLogging;        window.NLDeploymentIdForLogging = origDeploymentIdForLogging;    }} }); return false;">Search Shipping Address</button>`;
                    

                
                }

            } catch (ex) {
                log.error(logTitle, ex);
            }
        }

        return { beforeLoad}

    });
