/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/url', 'N/currentRecord'], function (url, currentRecord) {

        function onShippingButtonClick() {

            var logTitle = 'onShippingButtonClick';

            try {

                var rec = currentRecord.get()
                var entityId = rec.getValue('entity');

            
                if(!!entityId){

                    //ReturnExternalUrl must be true fir the url to be internal
                    var suiteletUrl = url.resolveScript({
                        scriptId: 'customscript_showcustomeraddresses',
                        deploymentId: 'customdeploy_showcustomeraddresses',
                        params: {
                            entity: entityId
                        },
                        returnExternalUrl: false
                    });

                    var params = "width=1000,height=800,scrollbars=yes,resizable=yes,top=100,left=100";

                    //Opens the suitelet acs_suitelet_showCustomerAddresses.js with the customer ID as parameter
                    window.open(suiteletUrl, "popupWindow", params);
                }
                else{
                    alert("You don't have a customer.")
                }


            } catch (error) {
                console.log(logTitle, error);
            }

        }

        function saveRecord(scriptContext) {

            return true;
        }


        return {
            saveRecord: saveRecord,
            onShippingButtonClick: onShippingButtonClick
        };

    });
