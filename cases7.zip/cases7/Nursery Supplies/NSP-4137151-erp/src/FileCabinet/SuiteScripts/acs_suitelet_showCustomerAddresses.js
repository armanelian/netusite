/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/ui/serverWidget', 'N/search', 'N/runtime'],

    (serverWidget, search, runtime) => {

        const onRequest = (scriptContext) => {

            var logName = 'onRequest';
            try {

                var entity;

                //When GET method gets entity from url params
                if (scriptContext.request.method == "GET") {
                    entity = scriptContext.request.parameters.entity;
                }


                var mainForm = serverWidget.createForm({
                    title: 'Customer Addresses'
                });

                //Submit button to fill the select on the record
                mainForm.addButton({ id: 'custpage_submitbutton', label: 'Submit', functionName: 'fillShippingSelect' });

                //Conects to a cliens script()
                mainForm.clientScriptFileId = runtime.getCurrentScript().getParameter('custscript_shipbtn_clientid');

                var searchField = mainForm.addField({
                    id: 'custpage_search',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Search: '
                });

                //A hidden field to obtain the entity after a post request
                var hiddenEntity = mainForm.addField({
                    id: 'custpage_hiddenentity',
                    type: serverWidget.FieldType.TEXT,
                    label: 'hidden'
                }).updateDisplayType(
                    {
                        displayType: serverWidget.FieldDisplayType.HIDDEN
                    }
                );

                var searchFilters = [];

                if (scriptContext.request.method == 'POST') {

                    var searchValue = scriptContext.request.parameters.custpage_search;

                    //When post method gets the entity from a hidden field
                    entity = scriptContext.request.parameters.custpage_hiddenentity;


                    if (searchValue) {
                        searchField.defaultValue = searchValue;

                        searchFilters.push([
                            ["address", search.Operator.CONTAINS, searchValue],
                            "or",
                            ["addresslabel", search.Operator.CONTAINS, searchValue]
                        ], 'and')
                    }

                }

                //sets hidden field with the entity
                hiddenEntity.defaultValue = entity;


                mainForm.addSubmitButton('Search');

                searchFilters.push(['internalid', search.Operator.ANYOF, entity])


                var addressesSearch = search.load('customsearch_acs_customeraddresses');

                //Adds filters to the already created search
                var addressesSearchAux = [];
                addressesSearchAux.push(searchFilters);
                addressesSearch.filterExpression = addressesSearchAux;


                var addList = mainForm.addSublist({
                    id: 'custpage_addresssublist',
                    label: 'Customer Addresses',
                    type: serverWidget.SublistType.LIST
                });


                addList.addField({
                    id: 'custpage_checkbox',
                    label: 'Select',
                    type: serverWidget.FieldType.RADIO
                });

                addList.addField({
                    id: 'custpage_addressid',
                    label: 'ID',
                    type: serverWidget.FieldType.TEXT
                });


                addList.addField({
                    id: 'custpage_address',
                    label: 'Address',
                    type: serverWidget.FieldType.TEXT
                });

                addList.addField({
                    id: 'custpage_addresslabel',
                    label: 'Label',
                    type: serverWidget.FieldType.TEXT
                });


                addList.addField({
                    id: 'custpage_address1',
                    label: 'Address 1',
                    type: serverWidget.FieldType.TEXT
                });

                addList.addField({
                    id: 'custpage_address2',
                    label: 'Address 2',
                    type: serverWidget.FieldType.TEXT
                });

                addList.addField({
                    id: 'custpage_phone',
                    label: 'Phone',
                    type: serverWidget.FieldType.TEXT
                });


                addList.addField({
                    id: 'custpage_country',
                    label: 'Country',
                    type: serverWidget.FieldType.TEXT
                });

                addList.addField({
                    id: 'custpage_state',
                    label: 'State',
                    type: serverWidget.FieldType.TEXT
                });

                addList.addField({
                    id: 'custpage_zipcode',
                    label: 'Zip',
                    type: serverWidget.FieldType.TEXT
                });

                var lineCount = 0;
                addressesSearch.run().each(function (result) {

                    addList.setSublistValue({
                        id: 'custpage_addressid',
                        line: lineCount,
                        value: result.getValue('addressinternalid') ? result.getValue('addressinternalid') : ' '
                    });

                    addList.setSublistValue({
                        id: 'custpage_address',
                        line: lineCount,
                        value: result.getValue('address') ? result.getValue('address') : ' '
                    });

                    addList.setSublistValue({
                        id: 'custpage_addresslabel',
                        line: lineCount,
                        value: result.getValue('addresslabel') ? result.getValue('addresslabel') : ' '
                    });

                    addList.setSublistValue({
                        id: 'custpage_address1',
                        line: lineCount,
                        value: result.getValue('address1') ? result.getValue('address1') : ' '
                    });

                    addList.setSublistValue({
                        id: 'custpage_address2',
                        line: lineCount,
                        value: result.getValue('address2') ? result.getValue('address2') : ' '
                    });

                    addList.setSublistValue({
                        id: 'custpage_phone',
                        line: lineCount,
                        value: result.getValue('phone') ? result.getValue('phone') : ' '
                    });


                    addList.setSublistValue({
                        id: 'custpage_country',
                        line: lineCount,
                        value: result.getValue('country') ? result.getValue('country') : ' '
                    });

                    addList.setSublistValue({
                        id: 'custpage_state',
                        line: lineCount,
                        value: result.getValue('statedisplayname') ? result.getValue('statedisplayname') : ' '
                    });

                    addList.setSublistValue({
                        id: 'custpage_zipcode',
                        line: lineCount,
                        value: result.getValue('zipcode') ? result.getValue('zipcode') : ' '
                    });


                    lineCount++
                    return true;

                })

                scriptContext.response.writePage(mainForm);
            }
            catch (error) {
                log.error(logName, error)
            }


        }

        return { onRequest }

    });
