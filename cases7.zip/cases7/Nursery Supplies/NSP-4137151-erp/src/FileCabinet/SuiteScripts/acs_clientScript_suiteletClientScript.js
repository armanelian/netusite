/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define([],

function() {

    function fieldChanged(scriptContext) {

        return true;
    }

    var addressId;
    
    function sublistChanged(scriptContext) {
        var logTitle = "SublistChanged"
        try{
            if(scriptContext.sublistId == 'custpage_addresssublist'){
                var cRec = scriptContext.currentRecord;
                var index = cRec.getCurrentSublistIndex({
                    sublistId: 'custpage_addresssublist'
                });
                addressId = cRec.getSublistValue({
                    sublistId: 'custpage_addresssublist',
                    fieldId: 'custpage_addressid',
                    line: index
                })
            }
        }
        catch(error){
            log.error(logTitle, error)
        }


        return true;
    }

    function fillShippingSelect(scriptContext){
        var logTitle = "fillShippingSelect"
        try{
            if(!!addressId){
                
                //Window.opener works on the original window that opened the current window
                window.opener.require(['N/currentRecord'], function (currentRecord) {
                    var currentRec = currentRecord.get();
                    
                    currentRec.setValue('shipaddresslist', addressId);
                })

                window.close();
            }else{
                alert("You need to select a value.");
            }
        }catch(error){
            log.error(logTitle, error)
        }

    }

    return {
        fieldChanged: fieldChanged,
        fillShippingSelect: fillShippingSelect,
        sublistChanged: sublistChanged

        
    };
    
});
